package com.xmlcalabash.datamodel

import com.xmlcalabash.namespace.NsCx

class AtomicEmptyStepInstruction(parent: XProcInstruction, name: String? = null): AtomicStepInstruction(parent, NsCx.empty, name) {
}