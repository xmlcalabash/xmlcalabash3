package com.xmlcalabash.datamodel

import com.xmlcalabash.xprocparser.StepConfiguration

// The standard step library. There should only be one instance in any given pipeline configuration

class StandardLibraryInstruction(stepConfig: StepConfiguration): LibraryInstruction(stepConfig, StepContainerImpl()) {
    private var analyzed = false

    override fun staticAnalysis(context: InstructionStaticContext) {
        // All steps import the standard library, avoid doing static analysis on it more than once
        if (!analyzed) {
            analyzed = true
            super.staticAnalysis(context)
        }
    }
}