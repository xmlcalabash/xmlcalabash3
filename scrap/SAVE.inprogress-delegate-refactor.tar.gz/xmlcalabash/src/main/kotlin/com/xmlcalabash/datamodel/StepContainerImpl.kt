package com.xmlcalabash.datamodel

import com.xmlcalabash.xprocparser.StepConfiguration
import net.sf.saxon.s9api.QName

class StepContainerImpl(): StepContainerInterface {
    internal val imported = mutableListOf<StepContainerInterface>()
    internal val exports = mutableMapOf<QName, DeclareStepInstruction>()

    override fun getImported(): List<StepContainerInterface> {
        return imported
    }

    override fun getExports(): Map<QName, DeclareStepInstruction> {
        return exports
    }

    override fun directlyExported(visited: MutableSet<StepContainerInterface>) {
        throw UnsupportedOperationException("The directlyExported method must be overridden")
    }

    override fun visibleInside(visited: MutableSet<StepContainerInterface>) {
        throw UnsupportedOperationException("The visibleInside method must be overridden")
    }

    override fun resolveImportsAndExports() {
        // Work out what's directly exported by each container
        directlyExported(mutableSetOf())
        visibleInside(mutableSetOf())
    }

    override fun traverse(stepConfig: StepConfiguration, visited: Set<StepContainerInterface>, import: StepContainerInterface) {
        if (visited.contains(import)) {
            return
        }

        for ((name, decl) in import.getExports()) {
            stepConfig.addVisibleStep(name, decl)
        }

        for (child in getImported()) {
            traverse(stepConfig,visited + import, child)
        }
    }

    override fun addImportLibrary(stepConfig: StepConfiguration, container: StepContainerInterface) {
        stepConfig.pipelineConfig.importedContainers.add(container)
        imported.add(container)
    }
}