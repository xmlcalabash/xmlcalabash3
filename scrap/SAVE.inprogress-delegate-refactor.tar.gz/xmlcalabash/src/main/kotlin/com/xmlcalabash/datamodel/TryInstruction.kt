package com.xmlcalabash.datamodel

import com.xmlcalabash.exceptions.XProcError
import com.xmlcalabash.namespace.NsCx
import com.xmlcalabash.namespace.NsP
import com.xmlcalabash.xprocparser.StepConfiguration
import net.sf.saxon.s9api.QName

class TryInstruction(parent: XProcInstruction, stepConfig: StepConfiguration, name: String?): CompoundContainer(parent, stepConfig, NsP.`try`, name) {
    override val contentModel = emptyMap<QName,Char>() // Not used by this instruction!
    private var group: GroupInstruction? = null

    override fun withInput(port: String?): WithInputInstruction {
        throw XProcError.xsInvalidElement(instructionType).exception()
    }

    override fun output(port: String?): OutputInstruction {
        if (children.filterIsInstance<GroupInstruction>().isNotEmpty()) {
            throw XProcError.xsInvalidElement(NsP.output).exception()
        }
        return super.output(port)
    }

    override fun forEach(name: String?): ForEachInstruction {
        group = group ?: group("!trygroup${stepConfig.pipelineConfig.nextId}")
        return group!!.forEach(name)
    }

    override fun viewport(name: String?): ViewportInstruction {
        group = group ?: group("!trygroup${stepConfig.pipelineConfig.nextId}")
        return group!!.viewport(name)
    }

    override fun choose(name: String?): ChooseInstruction {
        group = group ?: group("!trygroup${stepConfig.pipelineConfig.nextId}")
        return group!!.choose(name)
    }

    override fun ifInstruction(name: String?): IfInstruction {
        group = group ?: group("!trygroup${stepConfig.pipelineConfig.nextId}")
        return group!!.ifInstruction(name)
    }

    override fun group(name: String?): GroupInstruction {
        group = group ?: group("!trygroup${stepConfig.pipelineConfig.nextId}")
        return group!!.group(name)
    }

    override fun tryInstruction(name: String?): TryInstruction {
        group = group ?: group("!trygroup${stepConfig.pipelineConfig.nextId}")
        return group!!.tryInstruction(name)
    }

    override fun atomicStep(type: QName, name: String?): AtomicStepInstruction {
        group = group ?: group("!trygroup${stepConfig.pipelineConfig.nextId}")
        return group!!.atomicStep(type, name)
    }

    fun catch(name: String?): CatchInstruction {
        if (group == null || children.filterIsInstance<FinallyInstruction>().isNotEmpty()) {
            throw XProcError.xsInvalidElement(NsP.catch).exception()
        }
        val catch = CatchInstruction(this, stepConfig.newInstance(), name)
        _children.add(catch)
        return catch
    }

    fun finally(name: String?): FinallyInstruction {
        if (group == null || children.filterIsInstance<FinallyInstruction>().isNotEmpty()) {
            throw XProcError.xsInvalidElement(NsP.finally).exception()
        }
        val finally = FinallyInstruction(this, stepConfig.newInstance(), name)
        _children.add(finally)
        return finally
    }
}