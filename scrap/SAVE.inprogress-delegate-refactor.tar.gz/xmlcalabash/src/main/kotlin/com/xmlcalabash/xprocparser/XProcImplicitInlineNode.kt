package com.xmlcalabash.xprocparser

import net.sf.saxon.s9api.Axis
import net.sf.saxon.s9api.XdmNode

class XProcImplicitInlineNode(parser: PipelineParser, stepConfig: StepConfiguration, node: XdmNode): XProcInlineNode(parser, stepConfig, node) {
    override fun content(): List<XdmNode> {
        return listOf(xml)
    }

    override fun resolveDisplay(indent: String): String {
        return "${indent}(implicit inline)"
    }
}