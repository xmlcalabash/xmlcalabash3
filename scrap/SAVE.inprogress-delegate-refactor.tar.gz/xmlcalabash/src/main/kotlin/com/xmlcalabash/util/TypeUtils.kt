package com.xmlcalabash.util

import com.xmlcalabash.exceptions.XProcError
import com.xmlcalabash.namespace.Ns
import com.xmlcalabash.namespace.NsXs
import com.xmlcalabash.xprocparser.StepConfiguration
import net.sf.saxon.event.ReceiverOption
import net.sf.saxon.ma.arrays.ArrayItemType
import net.sf.saxon.ma.map.MapItem
import net.sf.saxon.ma.map.MapType
import net.sf.saxon.om.AttributeInfo
import net.sf.saxon.om.FingerprintedQName
import net.sf.saxon.om.NamespaceMap
import net.sf.saxon.om.NamespaceUri
import net.sf.saxon.s9api.*
import net.sf.saxon.type.BuiltInAtomicType
import net.sf.saxon.value.*
import net.sf.saxon.value.SequenceType

class TypeUtils(val processor: Processor, val inscopeNamespaces: Map<String,NamespaceUri>) {

    fun with(ns: Map<String, NamespaceUri>): TypeUtils {
        val utils = TypeUtils(processor, ns)
        utils._itemTypeFactory = _itemTypeFactory
        return utils
    }

    var _itemTypeFactory: ItemTypeFactory? = null
    val itemTypeFactory: ItemTypeFactory
        get() {
            if (_itemTypeFactory == null) {
                _itemTypeFactory = ItemTypeFactory(processor)
            }
            return _itemTypeFactory!!
        }

    companion object {
        fun attributeInfo(name: QName, value: String, location: Location? = null): AttributeInfo {
            return AttributeInfo(fqName(name), BuiltInAtomicType.UNTYPED_ATOMIC, value, location, ReceiverOption.NONE)
        }

        fun namespaceMap(
            ns: Map<String, NamespaceUri>,
            prefix: String? = null,
            namespace: NamespaceUri = NamespaceUri.NULL
        ): NamespaceMap {
            val fullMap = if (prefix == null || (ns.containsKey(prefix) && ns[prefix] == namespace)) {
                ns
            } else {
                val mns = mutableMapOf<String, NamespaceUri>()
                if (ns.containsKey(prefix)) {
                    var count = 1
                    var pfx = "_${count++}"
                    while (ns.containsKey(pfx)) {
                        pfx = "_${count++}"
                    }
                    mns.put(pfx, namespace)
                } else {
                    mns.put(prefix, namespace)
                }
                mns
            }

            var map = NamespaceMap.emptyMap()
            for ((pfx, uri) in fullMap) {
                map = map.put(pfx, uri)
            }

            return map
        }

        fun stringMap(ns: Map<String, NamespaceUri>): Map<String, String> {
            val mns = mutableMapOf<String, String>()
            for ((pfx, uri) in ns) {
                mns.put(pfx, uri.toString())
            }
            return mns
        }

        fun asXdmMap(inputMap: Map<QName, XdmValue>): XdmMap {
            var map = XdmMap()
            for ((key, value) in inputMap) {
                map = map.put(XdmAtomicValue(key), value)
            }
            return map
        }

        fun asMap(inputMap: XdmMap): Map<QName, XdmValue> {
            val map = mutableMapOf<QName, XdmValue>()
            for (key in inputMap.keySet()) {
                val value = inputMap.get(key)
                val qvalue = key.underlyingValue
                val qkey = if (qvalue is QNameValue) {
                    QName(qvalue.prefix, qvalue.namespaceURI.toString(), qvalue.localName)
                } else {
                    throw RuntimeException("Expected map of QName keys")
                }
                map.put(qkey, value)
            }
            return map
        }

        fun forceQNameKeys(inputMap: MapItem, context: StepConfiguration): XdmMap {
            var map = XdmMap()
            for (pair in inputMap.keyValuePairs()) {
                when (pair.key.itemType) {
                    BuiltInAtomicType.STRING -> {
                        val qname = context.parseQName(pair.key.stringValue)
                        map = map.put(XdmAtomicValue(qname), XdmValue.wrap(pair.value))
                    }

                    BuiltInAtomicType.QNAME -> {
                        val qvalue = pair.key as QNameValue
                        val key = QName(qvalue.prefix, qvalue.namespaceURI.toString(), qvalue.localName)
                        map = map.put(XdmAtomicValue(key), XdmValue.wrap(pair.value))
                    }

                    else -> {
                        throw RuntimeException("key isn't string or qname?")
                    }
                }
            }
            return map
        }

        fun forceQNameKeys(inputMap: XdmMap, context: StepConfiguration): XdmMap {
            var map = XdmMap()
            for (key in inputMap.keySet()) {
                val value = inputMap.get(key)
                val mapkey = when (key.underlyingValue.itemType) {
                    BuiltInAtomicType.STRING -> context.parseQName(key.stringValue)
                    BuiltInAtomicType.QNAME -> {
                        val qvalue = key.underlyingValue as QNameValue
                        QName(qvalue.prefix, qvalue.namespaceURI.toString(), qvalue.localName)
                    }

                    else -> throw RuntimeException("key isn't string or qname?")
                }

                if (mapkey == Ns.serialization) {
                    if (value is XdmMap) {
                        map = map.put(XdmAtomicValue(mapkey), forceQNameKeys(value, context))
                    } else {
                        throw XProcError.xdInvalidSerialization().exception()
                    }
                } else {
                    map = map.put(XdmAtomicValue(mapkey), value)
                }
            }
            return map
        }

        fun fqName(name: QName): FingerprintedQName = FingerprintedQName(name.prefix, name.namespaceUri, name.localName)
    }

    fun parseQName(text: String, defaultNamespace: NamespaceUri = NamespaceUri.NULL): QName {
        return parseQName(text, inscopeNamespaces, defaultNamespace)
    }

    fun parseQName(text: String, inscopeNamespaces: Map<String, NamespaceUri>, defaultNamespace: NamespaceUri = NamespaceUri.NULL): QName {
        if (text.startsWith("Q{")) {
            val pos = text.indexOf("}")
            if (pos < 0) {
                throw RuntimeException("BANG") // XProcError.xdInvalidQName(text).exception()
            }
            return QName(NamespaceUri.of(text.substring(2, pos)), parseNCName(text.substring(pos+1)))
        }

        val pos = text.indexOf(":")
        if (pos < 0) {
            return QName(defaultNamespace, parseNCName(text))
        }

        val prefix = parseNCName(text.substring(0, pos))
        if (inscopeNamespaces.containsKey(prefix)) {
            parseNCName(text.substring(pos+1)) // check that the local name is an NCName
            return QName(inscopeNamespaces[prefix], text)
        } else {
            throw RuntimeException("BANG") // XProcError.xdInvalidPrefix(text, prefix).exception()
        }
    }

    fun parseNCName(name: String): String {
        val value = castAtomicAs(XdmAtomicValue(name), ItemType.NCNAME, mapOf())
        return value.stringValue
    }

    fun parseBoolean(bool: String): Boolean {
        val value = castAtomicAs(XdmAtomicValue(bool), ItemType.BOOLEAN, mapOf())
        return value.booleanValue
    }

    fun castAtomicAs(value: XdmAtomicValue, seqType: net.sf.saxon.s9api.SequenceType?, inscopeNamespaces: Map<String, NamespaceUri>): XdmAtomicValue {
        if (seqType == null) {
            return value
        }
        return castAtomicAs(value, seqType.itemType, inscopeNamespaces)
    }

    fun castAtomicAs(value: XdmAtomicValue, xsdtype: ItemType, inscopeNamespaces: Map<String, NamespaceUri>): XdmAtomicValue {
        if (xsdtype == ItemType.UNTYPED_ATOMIC || xsdtype == ItemType.STRING || xsdtype == ItemType.ANY_ITEM) {
            return value
        }

        if (xsdtype == ItemType.QNAME) {
            val qname = when (value.primitiveTypeName) {
                NsXs.string, NsXs.untypedAtomic -> XdmAtomicValue(parseQName(value.stringValue))
                NsXs.QName -> value
                else -> throw RuntimeException("BANG") // XProcError.xdBadType(value.stringValue, xsdtype).exception()
            }
            return qname
        }

        try {
            return XdmAtomicValue(value.stringValue, xsdtype)
        } catch (ex: Exception) {
            when (ex) {
                is SaxonApiException -> {
                    if (ex.message!!.contains("Invalid URI")) {
                        throw RuntimeException("BANG") // XProcError.xdInvalidUri(value.stringValue).exception()
                    }
                    throw RuntimeException("BANG") // XProcError.xdBadType(value.stringValue, xsdtype).exception()

                }
                else -> throw ex
            }
        }
    }

    fun parseAsType(value: String, type: net.sf.saxon.s9api.SequenceType): XdmValue {
        val code = type.itemType.underlyingItemType.basicAlphaCode

        val compiler = processor.newXPathCompiler()
        for ((prefix, uri) in inscopeNamespaces) {
            compiler.declareNamespace(prefix, uri.toString())
        }
        val exec = compiler.compile(value)
        val selector = exec.load()
        val result = selector.evaluate()
        return validateAsType(result, type.underlyingSequenceType)
    }

    fun validateAsType(value: XdmValue, type: SequenceType): XdmValue {
        if (type.primaryType is ArrayItemType) {
            return validateAsArray(value as XdmArray, type)
        }
        if (type.primaryType is MapType) {
            return validateAsMap(value as XdmMap, type)
        }

        val values = mutableListOf<XdmValue>()
        val code = type.primaryType.basicAlphaCode
        for (item in value) {
            val itemValue = checkSimpleType(item, code)
            values.add(itemValue)
        }

        if (values.size == 1) {
            return values[0]
        }

        var newValue: XdmValue = XdmEmptySequence.getInstance()
        for (item in values) {
            newValue = newValue.append(item)
        }
        return newValue
    }

    private fun validateAsArray(value: XdmArray, type: SequenceType): XdmValue {
        val memberType = (type.primaryType as ArrayItemType).memberType
        val memberList = mutableListOf<XdmValue>()
        for (index in 0..< value.arrayLength()) {
            val member = value[index]
            memberList.add(validateAsType(member, memberType!!))
        }
        return XdmArray(memberList.toTypedArray())
    }

    private fun validateAsMap(value: XdmMap, type: SequenceType): XdmValue {
        val keyType = (type.primaryType as MapType).keyType
        val valueType = (type.primaryType as MapType).valueType
        var newValue = XdmMap()
        for (key in value.keySet()) {
            val mvalue = value.get(key)
            val keyValue = checkSimpleType(key, keyType.basicAlphaCode)
            val memberValue = validateAsType(mvalue, valueType)
            newValue = newValue.put(keyValue as XdmAtomicValue, memberValue)
        }
        return newValue
    }

    private fun checkSimpleType(value: XdmValue, code: String): XdmValue {
        if (value !is XdmAtomicValue) {
            return value
        }

        var typeName = NsXs.anyAtomicType

        when (code) {
            "", "A" -> return value
            "AB" -> {
                if (value.underlyingValue is BooleanValue) {
                    return value
                }
                typeName = NsXs.boolean
            }

            "AS" -> {
                if (value.underlyingValue is StringValue) {
                    return value
                }
                typeName = NsXs.string
            }
            "ASN" -> {
                typeName = NsXs.normalizedString
            }
            "ASNT" -> {
                typeName = NsXs.token
            }
            "ASNTL" -> {
                typeName = NsXs.language
            }
            "ASNTK" -> {
                typeName = NsXs.NMTOKEN
            }
            "ASNTN" -> {
                typeName = NsXs.name
            }
            "ASNTNC" -> {
                typeName = NsXs.NCName
            }
            "ASNTNCI" -> {
                typeName = NsXs.ID
            }
            "ASNTNCE" -> {
                typeName = NsXs.ENTITY
            }
            "ASNTNCR" -> {
                typeName = NsXs.IDREF
            }
            "AQ" -> {
                if (value.underlyingValue is QNameValue) {
                    return value
                }
                return XdmAtomicValue(parseQName(value.stringValue))
            }

            "AU" -> {
                if (value.underlyingValue is AnyURIValue) {
                    return value
                }
                typeName = NsXs.anyURI
            }

            "AA" -> {
                if (value.underlyingValue is DateValue) {
                    return value
                }
                typeName = NsXs.date
            }

            "AM" -> {
                if (value.underlyingValue is DateTimeValue) {
                    return value
                }
                typeName = NsXs.dateTime
            }

            "AMP" -> {
                if (value.underlyingValue is DateTimeValue) {
                    return value
                }
                typeName = NsXs.dateTimeStamp
            }

            "AT" -> {
                if (value.underlyingValue is TimeValue) {
                    return value
                }
                typeName = NsXs.time
            }

            "AR" -> {
                if (value.underlyingValue is DurationValue) {
                    return value
                }
                typeName = NsXs.duration
            }

            "ARD" -> {
                if (value.underlyingValue is DayTimeDurationValue) {
                    return value
                }
                typeName = NsXs.dayTimeDuration
            }

            "ARY" -> {
                if (value.underlyingValue is YearMonthDurationValue) {
                    return value
                }
                typeName = NsXs.yearMonthDuration
            }

            "AG" -> {
                if (value.underlyingValue is GYearValue) {
                    return value
                }
                typeName = NsXs.gYear
            }

            "AH" -> {
                if (value.underlyingValue is GYearMonthValue) {
                    return value
                }
                typeName = NsXs.gYearMonth
            }

            "AI" -> {
                if (value.underlyingValue is GMonthValue) {
                    return value
                }
                typeName = NsXs.gMonth
            }

            "AJ" -> {
                if (value.underlyingValue is GMonthDayValue) {
                    return value
                }
                typeName = NsXs.gMonthDay
            }

            "AK" -> {
                if (value.underlyingValue is GDayValue) {
                    return value
                }
                typeName = NsXs.gDay
            }

            "AD" -> {
                if (value.underlyingValue is DecimalValue) {
                    return value
                }
                typeName = NsXs.decimal
            }

            "ADI" -> {
                if (value.underlyingValue is Int64Value) {
                    return value
                }
                typeName = NsXs.decimal
            }

            "ADIN" -> {
                val uvalue = value.underlyingValue
                if (uvalue is Int64Value && uvalue.longValue() <= 0) {
                    return value
                }
                typeName = NsXs.nonPositiveInteger
            }

            "ADINN" -> {
                val uvalue = value.underlyingValue
                if (uvalue is Int64Value && uvalue.longValue() < 0) {
                    return value
                }
                typeName = NsXs.negativeInteger
            }

            "ADIP" -> {
                val uvalue = value.underlyingValue
                if (uvalue is Int64Value && uvalue.longValue() >= 0) {
                    return value
                }
                typeName = NsXs.nonNegativeInteger
            }

            "ADIPP" -> {
                val uvalue = value.underlyingValue
                if (uvalue is Int64Value && uvalue.longValue() > 0) {
                    return value
                }
                typeName = NsXs.positiveInteger
            }

            "ADIPL" -> {
                val uvalue = value.underlyingValue
                if (uvalue is Int64Value && uvalue.longValue() >= 0) {
                    return value
                }
                typeName = NsXs.unsignedLong
            }

            "ADIPLI" -> {
                val uvalue = value.underlyingValue
                if (uvalue is Int64Value && uvalue.longValue() >= 0 && uvalue.longValue() < 65536) {
                    return value
                }
                typeName = NsXs.unsignedInt
            }

            "ADIPLIS" -> {
                val uvalue = value.underlyingValue
                if (uvalue is Int64Value && uvalue.longValue() >= 0 && uvalue.longValue() < 32768) {
                    return value
                }
                typeName = NsXs.unsignedShort
            }

            "ADIPLISB" -> {
                val uvalue = value.underlyingValue
                if (uvalue is Int64Value && uvalue.longValue() >= 0 && uvalue.longValue() < 256) {
                    return value
                }
                typeName = NsXs.unsignedByte
            }

            "ADIL" -> {
                val uvalue = value.underlyingValue
                if (uvalue is Int64Value) {
                    return value
                }
                typeName = NsXs.long
            }

            "ADILI" -> {
                val uvalue = value.underlyingValue
                if (uvalue is Int64Value && uvalue.longValue() >= -65536 && uvalue.longValue() < 65536) {
                    return value
                }
                typeName = NsXs.int
            }

            "ADILIS" -> {
                val uvalue = value.underlyingValue
                if (uvalue is Int64Value && uvalue.longValue() >= -32768 && uvalue.longValue() < 32768) {
                    return value
                }
                typeName = NsXs.short
            }

            "ADILISB" -> {
                val uvalue = value.underlyingValue
                if (uvalue is Int64Value && uvalue.longValue() >= -128 && uvalue.longValue() < 128) {
                    return value
                }
                typeName = NsXs.byte
            }

            "AO" -> {
                val uvalue = value.underlyingValue
                if (uvalue is DoubleValue) {
                    return value
                }
                typeName = NsXs.double
            }

            "AF" -> {
                val uvalue = value.underlyingValue
                if (uvalue is FloatValue) {
                    return value
                }
                typeName = NsXs.float
            }

            "A2" -> {
                val uvalue = value.underlyingValue
                if (uvalue is Base64BinaryValue) {
                    return value
                }
                typeName = NsXs.base64Binary
            }

            "AX" -> {
                val uvalue = value.underlyingValue
                if (uvalue is HexBinaryValue) {
                    return value
                }
                typeName = NsXs.hexBinary
            }

            "AZ" -> {
                typeName = NsXs.untypedAtomic
            }
        }

        val itemType = itemTypeFactory.getAtomicType(typeName)
        return XdmAtomicValue(value.toString(), itemType)
    }

    fun checkType(
        varName: QName?,
        value: XdmValue,
        sequenceType: net.sf.saxon.s9api.SequenceType?,
        values: List<XdmAtomicValue>
    ): XdmValue {
        var newValue = value
        if (sequenceType != null) {
            val code = sequenceType.itemType.underlyingItemType.basicAlphaCode

            if (value === XdmEmptySequence.getInstance()) {
                if (sequenceType.occurrenceIndicator == OccurrenceIndicator.ZERO
                    || sequenceType.occurrenceIndicator == OccurrenceIndicator.ZERO_OR_ONE
                    || sequenceType.occurrenceIndicator == OccurrenceIndicator.ZERO_OR_MORE) {
                    return value
                }
                if (code == "AB") {
                    return XdmAtomicValue(false)
                }
                if (varName == null) {
                    throw RuntimeException("BANG") // XProcError.xdBadType(value.underlyingValue.stringValue, sequenceType.underlyingSequenceType.toString()).exception()
                } else {
                    throw RuntimeException("BANG") // XProcError.xdBadType(varName, value.toString(), sequenceType.underlyingSequenceType.toString()).exception()
                }
            }

            // We've got a bit of a hack here. If the input is a string, but the type is a
            // map or array, attempt to parse the string. For simple atomic values, like strings
            // or numbers, we don't have to do this
            newValue = if (value.underlyingValue is StringValue && (code == "FA" || code == "FM")) {
                parseAsType(value.underlyingValue.stringValue, sequenceType)
            } else {
                validateAsType(value, sequenceType.underlyingSequenceType)
            }
        }

        if (values.isNotEmpty()) {
            for (item in newValue) {
                checkType(item, values)
            }
        }

        return newValue
    }

    private fun checkType(value: XdmValue, values: List<XdmAtomicValue>) {
        val compiler = processor.newXPathCompiler()
        for ((prefix, uri) in inscopeNamespaces) {
            compiler.declareNamespace(prefix, uri.toString())
        }
        compiler.declareVariable(QName("a"))
        compiler.declareVariable(QName("b"))
        val selector = compiler.compile("\$a eq \$b").load()
        selector.setVariable(QName("a"), value)
        for (alt in values) {
            selector.setVariable(QName("b"), alt)
            if (selector.effectiveBooleanValue()) {
                return
            }
        }
        throw RuntimeException("BANG") // XProcError.xdValueNotAllowed(value, values).exception()
    }
}