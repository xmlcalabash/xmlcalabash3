package com.xmlcalabash.graph

class Head(val parent: CompoundNode): Node(parent.step) {
    override fun addEdges() {
        // nop
    }

    override fun toString(): String {
        return "Head(${parent})"
    }
}