package com.xmlcalabash.datamodel

import com.xmlcalabash.namespace.NsP
import com.xmlcalabash.xprocparser.StepConfiguration

class ForEachInstruction(parent: XProcInstruction, stepConfig: StepConfiguration, name: String?): CompoundContainer(parent, stepConfig, NsP.forEach, name) {
    override val contentModel = anySteps + mapOf(NsP.withInput to '1', NsP.output to '*')
}