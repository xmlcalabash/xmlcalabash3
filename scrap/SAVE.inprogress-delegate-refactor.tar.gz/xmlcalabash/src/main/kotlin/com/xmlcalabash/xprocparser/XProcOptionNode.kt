package com.xmlcalabash.xprocparser

import net.sf.saxon.s9api.QName
import net.sf.saxon.s9api.XdmNode
import net.sf.saxon.s9api.XdmValue

class XProcOptionNode(parser: PipelineParser, stepConfig: StepConfiguration, node: XdmNode, val name: QName, val select: String): XProcNode(parser, stepConfig, node) {
    internal var _staticValue: XdmValue? = null
    val staticValue: XdmValue?
        get() = _staticValue

    override fun resolveDisplay(indent: String): String {
        if (staticValue == null) {
            return "${indent}${nodeName} \$${name}"
        } else {
            return "${indent}${nodeName} \$${name} = ${staticValue}"
        }
    }
}