package com.xmlcalabash.datamodel

import com.xmlcalabash.exceptions.XProcError
import com.xmlcalabash.namespace.Ns
import com.xmlcalabash.namespace.NsP

class InputInstruction(parent: XProcInstruction): PortBindingContainer(parent, NsP.input) {
    constructor(parent: XProcInstruction, port: String, primary: Boolean?, sequence: Boolean?) : this(parent) {
        this.port = port
        this.primary = primary
        this.sequence = sequence
    }

    override fun elaborate() {
        if (pipe != null) {
            reportError(XProcError.xsAttributeForbidden(Ns.pipe))
        }
        for (child in children.filterIsInstance<PipeInstruction>()) {
            reportError(XProcError.xsInvalidElement(NsP.pipe))
        }

        super.elaborate()
    }

    override fun staticAnalysis(context: InstructionStaticContext) {
        super.staticAnalysis(context)

        for (child in children) {
            child.staticAnalysis(context.copy())
        }
    }

    // ============================================================

    override fun pipe(): PipeInstruction {
        throw XProcError.xsInvalidElement(NsP.pipe).exception()
    }
}