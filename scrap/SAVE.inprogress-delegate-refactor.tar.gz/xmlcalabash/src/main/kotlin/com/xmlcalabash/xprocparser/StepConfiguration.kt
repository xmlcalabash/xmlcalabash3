package com.xmlcalabash.xprocparser

import com.xmlcalabash.config.ExecutionContext
import com.xmlcalabash.config.PipelineConfiguration
import com.xmlcalabash.config.SaxonConfiguration
import com.xmlcalabash.datamodel.*
import com.xmlcalabash.datamodel.Location
import com.xmlcalabash.exceptions.XProcError
import com.xmlcalabash.exceptions.XProcException
import com.xmlcalabash.namespace.NsP
import com.xmlcalabash.namespace.NsXml
import com.xmlcalabash.datamodel.MediaType
import com.xmlcalabash.util.TypeUtils
import net.sf.saxon.expr.parser.XPathParser
import net.sf.saxon.lib.ExtensionFunctionDefinition
import net.sf.saxon.ma.map.MapItem
import net.sf.saxon.om.NamespaceUri
import net.sf.saxon.s9api.*
import net.sf.saxon.sxpath.IndependentContext
import java.net.URI

class StepConfiguration private constructor(val pipelineConfig: PipelineConfiguration, val saxonConfig: SaxonConfiguration): ExecutionContext by pipelineConfig {
    private var _baseUri: URI? = pipelineConfig.baseUri
    private var _location: Location = Location.NULL
    private var _stepName: String? = null
    private var _inscopeNamespaces = mutableMapOf<String, NamespaceUri>()
    private var _inscopeStepNames = mutableMapOf<String, NamedInstruction>()
    private var _inscopeStepTypes = mutableMapOf<QName, DeclareStepInstruction>()
    private var _inscopeFunctions = mutableSetOf<(PipelineConfiguration) -> ExtensionFunctionDefinition>()
    private var _typeUtils: TypeUtils? = null

    internal var drp: PortBindingContainer? = null

    companion object {
        fun getInstance(config: PipelineConfiguration, saxonConfig: SaxonConfiguration? = null): StepConfiguration {
            val stepConfig = StepConfiguration(config, saxonConfig ?: config.xprocConfiguration.saxonConfiguration().newConfiguration())
            return stepConfig
        }
    }

    fun newInstance(newSaxonContext: Boolean = true): StepConfiguration {
        val saxonConfig = if (newSaxonContext) {
            saxonConfig.newConfiguration()
        } else {
            saxonConfig
        }

        val stepConfig = StepConfiguration(pipelineConfig, saxonConfig)
        stepConfig._baseUri = _baseUri
        stepConfig._location = _location
        stepConfig._inscopeStepNames.putAll(_inscopeStepNames)
        stepConfig._inscopeStepTypes.putAll(_inscopeStepTypes)
        stepConfig._inscopeFunctions.addAll(_inscopeFunctions)
        stepConfig._inscopeNamespaces.putAll(_inscopeNamespaces)

        for (function in _inscopeFunctions) {
            stepConfig.processor.registerExtensionFunction(function(pipelineConfig))
        }

        return stepConfig
    }

    fun newInstance(node: XdmNode, newSaxonContext: Boolean = true): StepConfiguration {
        val saxonConfig = if (newSaxonContext) {
            saxonConfig.newConfiguration()
        } else {
            saxonConfig
        }

        val stepConfig = StepConfiguration(pipelineConfig, saxonConfig)
        try {
            stepConfig._baseUri = node.baseURI
            stepConfig._location = Location(node)
        } catch (ex: IllegalStateException) {
            val uri = node.getAttributeValue(NsXml.base) ?: ""
            // This error is insidious, don't try to report it, just throw it
            throw RuntimeException("invalid uri")
            //throw XProcError.xdInvalidUri(uri).exception()
        }

        stepConfig._inscopeStepNames.putAll(_inscopeStepNames)
        stepConfig._inscopeStepTypes.putAll(_inscopeStepTypes)
        stepConfig._inscopeFunctions.addAll(_inscopeFunctions)

        for (ns in node.axisIterator(Axis.NAMESPACE)) {
            if (node.nodeName.localName != "xml") {
                if (ns.nodeName == null) {
                    stepConfig._inscopeNamespaces[""] = NamespaceUri.of(ns.stringValue)
                } else {
                    stepConfig._inscopeNamespaces[ns.nodeName.localName] = NamespaceUri.of(ns.stringValue)
                }
            }
        }

        for (function in _inscopeFunctions) {
            stepConfig.processor.registerExtensionFunction(function(pipelineConfig))
        }

        return stepConfig
    }

    val processor = saxonConfig.processor
    var baseUri: URI?
        get() = _baseUri
        internal set(value) {
            _baseUri = value
        }

    var location: Location
        get() = _location
        internal set(value) {
            _location = value
        }

    var stepName: String
        get() {
            return _stepName!!
        }
        internal set(value) {
            _stepName = value
        }

    val hasErrors: Boolean
        get() = pipelineConfig.hasErrors
    val errors: List<XProcError>
        get() = pipelineConfig.errors

    fun reportError(error: XProcError) {
        pipelineConfig.reportError(error)
    }

    val inscopeNamespaces: Map<String, NamespaceUri>
        get() = _inscopeNamespaces

    var inscopeStepNames: Map<String, NamedInstruction>
        get() = _inscopeStepNames
        internal set(value) {
            _inscopeStepNames.clear()
            _inscopeStepNames.putAll(value)
        }

    var inscopeStepTypes: Map<QName, DeclareStepInstruction>
        get() = _inscopeStepTypes
        internal set(value) {
            _inscopeStepTypes.clear()
            _inscopeStepTypes.putAll(value)
        }

    val inscopeFunctions: Set<(PipelineConfiguration) -> ExtensionFunctionDefinition>
        get() = _inscopeFunctions

    fun addVisibleStep(name: QName, decl: DeclareStepInstruction) {
        val current = _inscopeStepTypes[name]
        if (current != null && current !== decl) {
            reportError(XProcError.xsDuplicateStepType(name))
        }
        _inscopeStepTypes[name] = decl
    }

    fun stepDeclaration(name: QName): DeclareStepInstruction? {
        val local = _inscopeStepTypes[name]
        if (local == null) {
            return pipelineConfig.standardLibrary.exports[name]
        }
        return local
    }

    fun stepAvailable(name: QName): Boolean {
        return stepDeclaration(name) != null
    }

    /*
    fun reportError(error: XProcError) {
        pipelineConfig.reportError(error)
    }
     */

    fun with(baseUri: URI): StepConfiguration {
        val context = newInstance(false)
        context._baseUri = baseUri
        return context
    }

    fun with(prefix: String, uri: NamespaceUri): StepConfiguration {
        val context = newInstance(false)
        context._inscopeNamespaces[prefix] = uri
        return context
    }

    fun with(inscopeNamespaces: Map<String, NamespaceUri>): StepConfiguration {
        val context = newInstance(false)
        context._inscopeNamespaces.clear()
        context._inscopeNamespaces.putAll(inscopeNamespaces)
        return context
    }

    fun at(location: Location): StepConfiguration {
        val context = newInstance(false)
        context._location = location
        return context
    }

    fun of(node: XdmNode): StepConfiguration {
        val context = newInstance(false)
        try {
            context._baseUri = node.baseURI
            context._location = Location(node)
        } catch (ex: IllegalStateException) {
            val uri = node.getAttributeValue(NsXml.base) ?: ""
            // This error is insidious, don't try to report it, just throw it
            throw RuntimeException("invalid uri")
            //throw XProcError.xdInvalidUri(uri).exception()
        }

        context._inscopeNamespaces.clear()
        for (ns in node.axisIterator(Axis.NAMESPACE)) {
            if (node.nodeName.localName != "xml") {
                if (ns.nodeName == null) {
                    context._inscopeNamespaces[""] = NamespaceUri.of(ns.stringValue)
                } else {
                    context._inscopeNamespaces[ns.nodeName.localName] = NamespaceUri.of(ns.stringValue)
                }
            }
        }
        return context
    }

    fun resolve(href: String): URI {
        if (_baseUri == null) {
            return URI(href)
        }
        return baseUri!!.resolve(href)
    }

    protected val typeUtils: TypeUtils
        get() {
            if (_typeUtils == null) {
                _typeUtils = TypeUtils(processor, inscopeNamespaces)
            }
            return _typeUtils!!
        }

    fun newXPathCompiler(): XPathCompiler {
        val compiler = processor.newXPathCompiler()
        for ((prefix, value) in inscopeNamespaces) {
            compiler.declareNamespace(prefix, value.toString())
        }
        return compiler
    }

    fun parseNCName(name: String): String {
        return typeUtils.parseNCName(name)
    }

    fun parseQName(name: String, defaultNamespace: NamespaceUri = NamespaceUri.NULL): QName {
        return typeUtils.parseQName(name, defaultNamespace)
    }

    fun parseQName(
        text: String,
        inscopeNamespaces: Map<String, NamespaceUri>,
        defaultNamespace: NamespaceUri = NamespaceUri.NULL
    ): QName {
        return typeUtils.parseQName(text, inscopeNamespaces, defaultNamespace)
    }

    fun parseBoolean(bool: String): Boolean {
        return typeUtils.parseBoolean(bool)
    }

    fun parseVisibility(visible: String): Visibility {
        when (visible) {
            "private" -> return Visibility.PRIVATE
            "public" -> return Visibility.PUBLIC
            else -> throw XProcError.xsValueDoesNotSatisfyType(visible, "Visibility").exception()
        }
    }

    fun parseContentTypes(text: String): MutableList<MediaType> {
        try {
            val alist = ArrayList<MediaType>()
            for (mt in MediaType.parseList(text)) {
                alist.add(mt)
            }
            return alist
        } catch (ex: XProcException) {
            throw ex.error.asStatic().exception()
        }
    }

    fun parseExcludeInlinePrefixes(prefixes: String): Set<NamespaceUri> {
        if (prefixes.trim() == "") {
            reportError(XProcError.xsInvalidExcludePrefix())
            return setOf()
        }

        val uriSet = mutableSetOf<NamespaceUri>()
        uriSet.add(NsP.namespace)
        for (token in prefixes.split("\\s+".toRegex())) {
            when (token) {
                "#all" -> {
                    for ((_, uri) in inscopeNamespaces) {
                        uriSet.add(uri)
                    }
                }
                "#default" -> {
                    if (inscopeNamespaces[""] == null) {
                        reportError(XProcError.xsNoDefaultNamespace())
                    } else {
                        uriSet.add(inscopeNamespaces[""]!!)
                    }
                }
                else -> {
                    val uri = inscopeNamespaces[token]
                    if (uri == null) {
                        reportError(XProcError.xsInvalidExcludePrefix(token))
                    } else {
                        uriSet.add(uri)
                    }
                }
            }
        }

        return uriSet
    }

    fun parseValues(text: String): List<XdmAtomicValue> {
        val values = mutableListOf<XdmAtomicValue>()
        val compiler = newXPathCompiler()
        val selector = compiler.compile(text).load()
        //selector.resourceResolver = context.pipelineConfig.documentManager
        for (value in selector.evaluate().iterator()) {
            when (value) {
                is XdmAtomicValue -> values.add(value)
                else -> reportError(XProcError.xsInvalidValues(value.toString()))
            }
        }

        return values
    }

    fun forceQNameKeys(map: MapItem): XdmMap {
        return TypeUtils.forceQNameKeys(map, this)
    }

    fun forceQNameKeys(map: XdmMap): XdmMap {
        return TypeUtils.forceQNameKeys(map, this)
    }

    fun asMap(map: XdmMap): Map<QName, XdmValue> {
        return TypeUtils.asMap(forceQNameKeys(map))
    }

    fun checkType(
        varName: QName?,
        value: XdmValue,
        sequenceType: SequenceType?,
        values: List<XdmAtomicValue>
    ): XdmValue {
        return typeUtils.checkType(varName, value, sequenceType, values)
    }

    fun castAtomicAs(value: XdmAtomicValue, seqType: SequenceType?, inscopeNamespaces: Map<String, NamespaceUri>): XdmAtomicValue {
        return typeUtils.castAtomicAs(value, seqType, inscopeNamespaces)
    }

    fun castAtomicAs(value: XdmAtomicValue, xsdtype: ItemType, inscopeNamespaces: Map<String, NamespaceUri>): XdmAtomicValue {
        return typeUtils.castAtomicAs(value, xsdtype, inscopeNamespaces)
    }

    fun parseSequenceType(asExpr: String): SequenceType {
        val config = processor.getUnderlyingConfiguration()
        val icontext = IndependentContext(config)
        icontext.clearAllNamespaces() // We get no defaults
        for ((prefix, uri) in inscopeNamespaces) {
            icontext.declareNamespace(prefix, uri)
        }
        icontext.setXPathLanguageLevel(31)
        val parser = XPathParser(icontext)
        val st = parser.parseSequenceType(asExpr, icontext)
        return SequenceType.fromUnderlyingSequenceType(processor, st)
    }


}