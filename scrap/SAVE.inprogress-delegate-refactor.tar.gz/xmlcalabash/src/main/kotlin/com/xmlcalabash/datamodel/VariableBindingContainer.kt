package com.xmlcalabash.datamodel

import com.xmlcalabash.exceptions.XProcError
import com.xmlcalabash.namespace.Ns
import com.xmlcalabash.xprocparser.StepConfiguration
import net.sf.saxon.s9api.QName
import net.sf.saxon.s9api.SaxonApiException
import net.sf.saxon.s9api.SequenceType
import net.sf.saxon.s9api.XdmAtomicValue
import net.sf.saxon.s9api.XdmValue
import java.net.URI

open class VariableBindingContainer(parent: XProcInstruction, val name: QName, instructionType: QName): BindingContainer(parent, instructionType) {
    var asType: SequenceType? = null
        set(value) {
            checkOpen()
            field = value
        }

    open var select: XProcExpression? = null
        set(value) {
            checkOpen()
            field = value
        }

    var collection: Boolean? = null
        set(value) {
            checkOpen()
            field = value
        }

    var href: XProcExpression? = null
        set(value) {
            checkOpen()
            if (value == null) {
                field = null
            } else {
                field = value.cast(stepConfig.parseSequenceType("xs:anyURI"))
            }
        }

    var pipe: String? = null
        set(value) {
            checkOpen()
            field = value
        }

    /*
    var withInput: WithInputInstruction? = null
    var alwaysDynamic = false
    protected var _static = false
    val isStatic: Boolean
        get() = _static
        */

    private var _staticValue: XdmValue? = null
    var staticValue: XdmValue?
        get() = _staticValue
        set(value) {
            checkOpen()
            _staticValue = value
        }
    internal var _withOutput: WithOutputInstruction? = null
    val withOutput: WithOutputInstruction?
        get() = _withOutput

    override fun elaborate() {
        asType = asType ?: stepConfig.parseSequenceType("item()*")

        if (href != null && children.isNotEmpty()) {
            reportError(XProcError.xsHrefAndChildren())
        }

        if (pipe != null && children.isNotEmpty()) {
            reportError(XProcError.xsPipeAndChildren())
        }

        if (href != null && pipe != null) {
            reportError(XProcError.xsHrefAndPipe())
        }

        href?.let { promoteHref(it) }
        href = null

        pipe?.let { promotePipe(it) }
        pipe = null

        super.elaborate()
    }

    override fun staticAnalysis(context: InstructionStaticContext) {
        if (this is OptionInstruction) {
            optionStaticAnalysis(context)
        } else {
            variableStaticAnalysis(context)
        }
        super.staticAnalysis(context)
    }

    private fun optionStaticAnalysis(context: InstructionStaticContext) {
    }

    private fun variableStaticAnalysis(context: InstructionStaticContext) {
        val expr = select!!

        // The expression can be resolved statically if it doesn't refer to a collection,
        // doesn't have any bindings, and can be resolved statically.
        if (collection != true && children.isEmpty()) {
            _staticValue = expr.computeStaticValue(context)
        }
    }

/*
override fun staticAnalysis(context: InstructionStaticContext) {
    if (select == null) {
        reportError(XProcError.xsMissingRequiredAttribute(Ns.select))
        return
    }

    val code = if (asType != null) {
        asType!!.underlyingSequenceType.primaryType.basicAlphaCode
    } else {
        ""
    }

    val staticBindings = mutableMapOf<QName, XdmValue>()

    // If this is a static option with a value provided at compile time,
    // staticValue will already have a value. Otherwise, we might
    // calculate it.
    if (staticValue == null) {
        for ((name, value) in context.inscopeVariables) {
            if (value.staticValue != null) {
                staticBindings[name] = value.staticValue!!
                select!!.setStaticBinding(name, value.staticValue!!)
            }
        }

        if (!alwaysDynamic && select!!.canBeResolvedStatically()) {
            _staticValue = select!!.evaluate()
        }
    } else {
        if (asType != null || values.isNotEmpty()) {
            _staticValue = stepConfig.checkType(null, staticValue!!, asType, values)
        }
    }

    if (staticValue == null) {
        for (name in select!!.variableRefs) {
            if (!staticBindings.containsKey(name)) {
                val wi = WithInputInstruction(stepConfig)
                wi.port = "Q{${name.namespaceUri}}${name.localName}"
                _children.add(wi)
                val exprBuilder = context.inscopeVariables[name]!!
                val rport = exprBuilder.primaryOutput()
                val pipe = wi.addPipe(PipeInstruction(stepConfig, ))
                pipe.readablePort = rport
            }
        }

        var source: IOBuilder? = null
        for (child in children) {
            if (child is IOBuilder && child.port == "source") {
                source = child
            }
        }

        if (expression!!.contextRef && source == null) {
            val wi = WithInputBuilder(this, context)
            wi.port = "source"
            wi.sequence = true
            wi.primary = true
            children.add(wi)
        }

        val wo = WithOutputBuilder(this, context)
        wo.port = "!result"
        wo.sequence = false
        wo.primary = true
        children.add(wo)
    }

    super.staticAnalysis(staticContext)

    if (collection == true && withInput != null) {
        withInput!!.sequence = true
    }

}
 */

fun primaryOutput(): WithOutputInstruction {
    for (child in children) {
        if (child is WithOutputInstruction) {
            return child
        }
    }
    throw XProcError.xiImpossible("expression has no output").exception()
}

    /*
private fun getOrCreateWithInput(): WithInputInstruction {
    if (withInput == null) {
        val wi = WithInputInstruction(this)
        wi.port = "source"
        _children.add(wi)
        withInput = wi
    }
    return withInput!!
}

     */


    override fun toString(): String {
        return "${instructionType}/${id} ${name}"
    }
}