package com.xmlcalabash.datamodel

import com.xmlcalabash.exceptions.XProcError
import com.xmlcalabash.namespace.NsCx
import com.xmlcalabash.namespace.NsP
import com.xmlcalabash.xprocparser.StepConfiguration
import net.sf.saxon.s9api.QName

abstract class CompoundContainer(parent: XProcInstruction?, stepConfig: StepConfiguration, instructionType: QName, name: String? = null): XProcStepInstruction(parent, stepConfig, instructionType, name) {
    val anySteps = mapOf(
        NsP.forEach  to '*',
        NsP.viewport to '*',
        NsP.choose to '*',
        NsP.`if` to '*',
        NsP.group to '*',
        NsP.`try` to '*',
        NsCx.atomicStep to '*'
    )

    abstract val contentModel: Map<QName, Char>

    private fun addInstruction(instruction: XProcInstruction, type: QName = instruction.instructionType) {
        when (contentModel[type]) {
            null, '0' -> instruction.reportError(XProcError.xsInvalidElement(type))
            '?', '1' -> {
                if (children.filterIsInstance<WithInputInstruction>().isNotEmpty()) {
                    instruction.reportError(XProcError.xsInvalidElement(type))
                } else {
                    _children.add(instruction)
                }
            }
            '*' -> {
                _children.add(instruction)
            }
            else -> throw XProcError.xiImpossible("Invalid content model character for {$type}: ${contentModel[type]}").exception()
        }
    }

    open fun withInput(port: String? = null): WithInputInstruction {
        val withInput = WithInputInstruction(this)
        port?.let { withInput.port = port }
        _children.add(withInput)
        return withInput
    }

    open fun output(port: String? = null): OutputInstruction {
        val output = OutputInstruction(this)
        port?.let { output.port = port }
        _children.add(output)
        return output
    }

    open fun variable(name: QName): VariableInstruction {
        val variable = VariableInstruction(this, name)
        _children.add(variable)
        return variable
    }

    open fun forEach(name: String?): ForEachInstruction {
        val forEach = ForEachInstruction(this, stepConfig.newInstance(), name)
        _children.add(forEach)
        return forEach
    }

    open fun viewport(name: String?): ViewportInstruction {
        val viewport = ViewportInstruction(this, stepConfig.newInstance(), name)
        _children.add(viewport)
        return viewport
    }

    open fun choose(name: String?): ChooseInstruction {
        val choose = ChooseInstruction(this, stepConfig.newInstance(), name);
        _children.add(choose)
        return choose
    }

    open fun ifInstruction(name: String?): IfInstruction {
        val ifi = IfInstruction(this, stepConfig.newInstance(), name)
        _children.add(ifi)
        return ifi
    }

    open fun group(name: String?): GroupInstruction {
        val group = GroupInstruction(this, stepConfig.newInstance(), name)
        _children.add(group)
        return group
    }

    open fun tryInstruction(name: String?): TryInstruction {
        val tryi = TryInstruction(this, stepConfig.newInstance(), name)
        _children.add(tryi)
        return tryi
    }

    open fun atomicStep(type: QName, name: String?): AtomicStepInstruction {
        val atomic = AtomicStepInstruction(this, type, name)
        _children.add(atomic)
        return atomic
    }
}