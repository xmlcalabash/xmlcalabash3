package com.xmlcalabash.xprocparser

import com.xmlcalabash.namespace.NsXml
import com.xmlcalabash.util.NodeLocation
import com.xmlcalabash.util.SaxonTreeBuilder
import com.xmlcalabash.util.TypeUtils
import com.xmlcalabash.util.ValueUtils
import net.sf.saxon.om.*
import net.sf.saxon.s9api.Axis
import net.sf.saxon.s9api.XdmNode
import net.sf.saxon.s9api.XdmNodeKind
import net.sf.saxon.type.Untyped
import java.net.URI

open class XProcInlineNode(parser: PipelineParser, stepConfig: StepConfiguration, node: XdmNode): XProcNode(parser, stepConfig, node) {
    fun inlineXml(): XdmNode {
        val builder = SaxonTreeBuilder(stepConfig)
        builder.startDocument(xml.baseURI)
        for (node in content()) {
            filterXml(builder, node, xml.baseURI)
        }
        builder.endDocument()
        return builder.result
    }

    protected open fun content(): List<XdmNode> {
        val nodes = mutableListOf<XdmNode>()
        for (child in xml.axisIterator(Axis.CHILD)) {
            nodes.add(child)
        }
        return nodes
    }

   override fun processChildren() {
        return // There's no pipeline children in an inline
    }

    private fun filterXml(builder: SaxonTreeBuilder, node: XdmNode, baseUri: URI?) {
        when (node.nodeKind) {
            XdmNodeKind.DOCUMENT -> {
                for (child in node.axisIterator(Axis.CHILD)) {
                    filterXml(builder, child, baseUri)
                }
            }
            XdmNodeKind.ELEMENT -> {
                val includeNS = mutableMapOf<String, NamespaceUri>()
                var nsMap = NamespaceMap.emptyMap()
                for ((prefix, uri) in ValueUtils.inscopeNamespaces(node)) {
                    if (!excludeNamespaceUris.contains(uri)) {
                        includeNS[prefix] = uri
                        nsMap = nsMap.put(prefix, uri)
                    }
                }
                var adjBaseUri = baseUri
                var attMap: AttributeMap = EmptyAttributeMap.getInstance()
                for (attr in node.axisIterator(Axis.ATTRIBUTE)) {
                    val aloc = NodeLocation(node)
                    if (attr.nodeName.namespaceUri == NamespaceUri.NULL) {
                        // Why do I have to recreate this?
                        attMap = attMap.put(TypeUtils.attributeInfo(attr.nodeName, attr.stringValue, aloc))
                    } else {
                        if (!includeNS.containsKey(attr.nodeName.prefix)) {
                            nsMap = nsMap.put(attr.nodeName.prefix, attr.nodeName.namespaceUri)
                            includeNS[attr.nodeName.prefix] = attr.nodeName.namespaceUri
                        }
                        attMap = attMap.put(TypeUtils.attributeInfo(attr.nodeName, attr.stringValue, aloc))
                    }
                    if (attr.nodeName == NsXml.base) {
                        if (adjBaseUri == null) {
                            adjBaseUri = URI(attr.stringValue)
                        } else {
                            adjBaseUri = adjBaseUri.resolve(attr.stringValue)
                        }
                    }
                }

                val elemName = FingerprintedQName(node.nodeName.prefix, node.nodeName.namespaceUri, node.nodeName.localName)
                builder.addStartElement(elemName, attMap, Untyped.getInstance(), nsMap, adjBaseUri)
                for (child in node.axisIterator(Axis.CHILD)) {
                    filterXml(builder, child, adjBaseUri)
                }
                builder.addEndElement()
            }
            else -> builder.addSubtree(node)
        }
    }
}