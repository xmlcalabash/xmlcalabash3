package com.xmlcalabash.graph

class Edge(val from: Node, val outputPort: String, val to: Node, val inputPort: String) {
    override fun toString(): String {
        return "${from}.${outputPort} -> ${to}.${inputPort}"
    }
}