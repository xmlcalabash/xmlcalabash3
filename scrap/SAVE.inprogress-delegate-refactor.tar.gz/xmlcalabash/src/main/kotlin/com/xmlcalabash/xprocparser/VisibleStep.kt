package com.xmlcalabash.xprocparser

class VisibleStep(val step: XProcDeclareStepNode) {
    var conditional = step.useWhenExpression != null
}