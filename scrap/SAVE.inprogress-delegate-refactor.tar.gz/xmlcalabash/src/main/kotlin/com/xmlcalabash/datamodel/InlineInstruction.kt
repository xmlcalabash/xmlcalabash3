package com.xmlcalabash.datamodel

import com.xmlcalabash.exceptions.XProcError
import com.xmlcalabash.namespace.NsP
import com.xmlcalabash.util.ValueTemplateFilter
import com.xmlcalabash.util.ValueTemplateFilterNone
import com.xmlcalabash.util.ValueTemplateFilterXml
import net.sf.saxon.s9api.QName
import net.sf.saxon.s9api.XdmMap
import net.sf.saxon.s9api.XdmNode
import net.sf.saxon.s9api.XdmValue

class InlineInstruction(parent: XProcInstruction, xmlDocument: XdmNode): ConnectionInstruction(parent, NsP.inline) {
    var xml: XdmNode = xmlDocument
        set(value) {
            checkOpen()
            field = value
        }

    var contentType: MediaType? = null
        set(value) {
            checkOpen()
            field = value
        }

    private var _documentProperties: XProcExpression? = null
    var documentProperties: XProcExpression
        get() = _documentProperties!!
        set(value) {
            checkOpen()
            _documentProperties = value.cast(parent!!.stepConfig.parseSequenceType("map(xs:QName,item()*)"))
        }

    var encoding: String? = null
        set(value) {
            checkOpen()
            field = value
        }

    private lateinit var _valueTemplateFilter: ValueTemplateFilter
    val valueTemplateFilter: ValueTemplateFilter
        get() = _valueTemplateFilter

    init {
        var p: XProcInstruction? = parent
        while (expandText == null && p != null) {
            if (p.expandText != null) {
                expandText = p.expandText
            }
            p = p.parent
        }
        expandText = expandText ?: true
    }

    override fun elaborate() {
        if (_documentProperties == null) {
            _documentProperties = XProcExpression.constant(parent!!.stepConfig, XdmMap(), parent!!.stepConfig.parseSequenceType("map(xs:QName,item()*)"))
        }

        super.elaborate()
    }

    override fun staticAnalysis(context: InstructionStaticContext) {
        val isRunPipeline = false // = parent != null && parent!!.parent is RunBuilder

        // Force inlines to have unique URIs because document-uri(). Bleh.
        val uri = xml.baseURI?.toString() ?: ""
        stepConfig.baseUri = stepConfig.pipelineConfig.uniqueUri(uri)

        if (contentType == null) {
            contentType = MediaType.XML
        }

        if (encoding != null && encoding != "base64") {
            reportError(XProcError.xsUnsupportedEncoding(encoding!!))
        }

        _valueTemplateFilter = if (encoding == null && !isRunPipeline) {
            ValueTemplateFilterXml(stepConfig, xml, stepConfig.baseUri!!)
        } else {
            ValueTemplateFilterNone(stepConfig, xml, stepConfig.baseUri!!)
        }

        val staticBindings = mutableMapOf<QName, XdmValue>()
        for ((name, value) in context.inscopeVariables) {
            /*
            if (value.staticValue != null) {
                staticBindings[name] = value.staticValue!!
            }
             */
        }

        xml = _valueTemplateFilter.expandStaticValueTemplates(expandText!!, staticBindings)

        var usesContext = _valueTemplateFilter.usesContext()
        val variables = mutableSetOf<QName>()
        variables.addAll(_valueTemplateFilter.usesVariables())

        if (usesContext) {
            val wi = WithInputInstruction(this)
            wi.port = "source"
            _children.add(wi)
            wi.pipe()
        }

        for (name in variables) {
            if (!staticBindings.containsKey(name)) {
                val eqname = "Q{${name.namespaceUri}}${name.localName}"
                val wi = WithInputInstruction(this)
                wi.port = eqname
                val pipe = wi.pipe()
                val vbuilder = context.inscopeVariables[name]!!
                pipe.setReadablePort(vbuilder.primaryOutput())
                _children.add(wi)
            }
        }

        super.staticAnalysis(context)
    }

    override fun promoteToStep(step: XProcInstruction): List<AtomicStepInstruction> {
        TODO("Not yet implemented")
    }

    internal fun replacementInlineStep(parent: DeclareStepInstruction, context: InstructionStaticContext): AtomicStepInstruction {
        val inlineStep = AtomicInlineStepInstruction(parent, valueTemplateFilter, "!inline_${stepConfig.pipelineConfig.nextId}")
        inlineStep.contentType = contentType
        inlineStep.encoding = encoding
        //inlineStep.depends ...

        var sourceBinding: WithInputInstruction? = null
        for (child in children.filterIsInstance<WithInputInstruction>()) {
            if (child.port == "source") {
                sourceBinding = child
            }
        }


        // Make sure the inline source is bound if the DRP is not null.
        if (sourceBinding == null && context.drp != null) {
            val wi = inlineStep.withInput()
            wi.port = "source"
            val pipe = wi.pipe()
            pipe.setReadablePort(context.drp!!)
            wi.staticAnalysis(context)
        }

        for (child in children) {
            inlineStep._children.add(child)
        }

        inlineStep.staticAnalysis(context)
        //inlineStep.stepDepends(staticContext)

        val output = inlineStep.primaryOutput()!!
        output.sequence = false
        if (inlineStep.contentType == null) {
            output.contentTypes = MediaType.XML_OR_HTML
        } else {
            output.contentTypes = listOf(inlineStep.contentType!!)
        }

        return inlineStep
    }
}