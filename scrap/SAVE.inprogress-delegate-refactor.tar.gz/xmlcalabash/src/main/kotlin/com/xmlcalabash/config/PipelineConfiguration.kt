package com.xmlcalabash.config

import com.xmlcalabash.datamodel.LibraryInstruction
import com.xmlcalabash.datamodel.StandardLibrary
import com.xmlcalabash.datamodel.StepContainer
import com.xmlcalabash.datamodel.StepContainerInterface
import com.xmlcalabash.documents.XProcDocument
import com.xmlcalabash.exceptions.XProcError
import com.xmlcalabash.runtime.XProcExecutionContext
import com.xmlcalabash.spi.AtomicStepManager
import com.xmlcalabash.spi.AtomicStepServiceProvider
import com.xmlcalabash.spi.DocumentResolverServiceProvider
import com.xmlcalabash.util.UriUtils
import com.xmlcalabash.xprocparser.PipelineParser
import com.xmlcalabash.xprocparser.StepConfiguration
import com.xmlcalabash.xprocparser.XProcLibraryNode
import net.sf.saxon.s9api.QName
import net.sf.saxon.s9api.XdmValue
import org.xml.sax.InputSource
import java.net.URI
import java.util.*
import javax.activation.MimetypesFileTypeMap

class PipelineConfiguration private constructor(val xprocConfiguration: XProcConfiguration): ExecutionContext {
    companion object {
        fun getInstance(xproc: XProcConfiguration): PipelineConfiguration {
            val config = PipelineConfiguration(xproc)
            config.initialize()
            return config
        }
    }

    private var _id = 0L
    private var _dependsId = 0L
    private val _staticOptions = mutableMapOf<QName, XdmValue>()
    private val uniqueUris = mutableMapOf<String, Int>()
    private val executables = mutableMapOf<Long, XProcExecutionContext>()

    val episode = "E-${UUID.randomUUID()}"

    private var _standardLibrary: LibraryInstruction? = null
    val standardLibrary: LibraryInstruction
        get() = _standardLibrary!!
    internal val importedContainers = mutableSetOf<StepContainerInterface>()

    //val errors: List<XProcError> = _errors
    val staticOptions: Map<QName, XdmValue> = _staticOptions

    internal val stepManagers = mutableListOf<AtomicStepManager>()

    //private var _errorExplanation: ErrorExplanation = DefaultErrorExplanation()
    private var _mimeTypes = MimetypesFileTypeMap()
    //private var _documentManager: DocumentManager = xprocConfiguration.documentManager()
    // private var _messageReporter = DefaultMessageReporter(Verbosity.NORMAL)
    private var _proxies = mutableMapOf<String, String>()

    val baseUri = UriUtils.cwdAsUri()
    var debug: Boolean = false
    /*
    val errorExplanation: ErrorExplanation
        get() = _errorExplanation
     */
    val mimeTypes: MimetypesFileTypeMap
        get() = _mimeTypes
    /*
    val documentManager: DocumentManager
        get() = _documentManager
    val messageReporter: MessageReporter
        get() = _messageReporter
     */
    val proxies: Map<String,String>
        get() = _proxies

    private val _errors = mutableListOf<XProcError>()
    val errors: List<XProcError>
        get() = _errors
    val hasErrors: Boolean
        get() {
            return _errors.isNotEmpty()
        }
    fun reportError(error: XProcError) {
        _errors.add(error)
    }

    private fun initialize() {
        _standardLibrary = StandardLibrary.getInstance(StepConfiguration.getInstance(this))
        _standardLibrary!!.validate()

        for (provider in AtomicStepServiceProvider.providers()) {
            stepManagers.add(provider.create(this))
        }

        /*
        for (provider in DocumentResolverServiceProvider.providers()) {
            provider.create().configure(documentManager)
        }
         */
    }

    internal val nextId: Long
        get() {
            synchronized(this) {
                return ++_id
            }
        }

    internal val nextDependsId: Long
        get() {
            synchronized(this) {
                return ++_dependsId
            }
        }

    internal fun uniqueUri(base: String): URI {
        synchronized(this) {
            val count = uniqueUris[base] ?: 0
            uniqueUris[base] = count + 1
            if (count == 0 && base != "") {
                return URI(base)
            }
            return URI("${base}?uniqueid=${count}")
        }
    }

    fun staticOption(name: QName, value: XdmValue) {
        _staticOptions[name] = value
    }

    override fun getExecutionContext(): XProcExecutionContext? {
        //println("Get ${this}: ${executables[Thread.currentThread().id]} for ${Thread.currentThread().id}")

        return executables[Thread.currentThread().id]
    }

    override fun setExecutionContext(dynamicContext: XProcExecutionContext) {
        //println("Set ${this}: ${dynamicContext} for ${Thread.currentThread().id}")

        executables[Thread.currentThread().id] = dynamicContext
    }

    override fun releaseExecutionContext() {
        //println("Free ${this}: ${executables[Thread.currentThread().id]} for ${Thread.currentThread().id}")

        executables.remove(Thread.currentThread().id)
    }

    override fun addProperties(doc: XProcDocument?) {
        if (doc == null) {
            return
        }
        executables[Thread.currentThread().id]!!.addProperties(doc)
    }

    override fun removeProperties(doc: XProcDocument?) {
        if (doc == null) {
            return
        }
        executables[Thread.currentThread().id]!!.removeProperties(doc)
    }
}