package com.xmlcalabash.datamodel

import com.xmlcalabash.namespace.NsCx

class AtomicExpressionStepInstruction(parent: XProcInstruction, val expression: XProcExpression, name: String? = null): AtomicStepInstruction(parent, NsCx.expression, name) {
}