package com.xmlcalabash.xprocparser

import com.xmlcalabash.config.PipelineConfiguration
import com.xmlcalabash.datamodel.*
import com.xmlcalabash.exceptions.XProcError
import com.xmlcalabash.exceptions.XProcException
import com.xmlcalabash.namespace.Ns
import com.xmlcalabash.namespace.NsP
import com.xmlcalabash.datamodel.MediaType
import com.xmlcalabash.graph.Graph
import com.xmlcalabash.util.S9Api
import com.xmlcalabash.util.UriUtils
import com.xmlcalabash.util.ValueTemplateParser
import net.sf.saxon.om.NamespaceUri
import net.sf.saxon.s9api.*
import org.xml.sax.InputSource
import java.io.File
import java.io.FileReader
import java.lang.IllegalArgumentException
import java.net.URI
import javax.xml.transform.sax.SAXSource

class PipelineParser internal constructor(val configuration: PipelineConfiguration) {
    lateinit var standardLibrary: XProcLibraryNode
    internal val importedContainers = mutableMapOf<URI,StepContainerInterface>()
    internal val containerMap = mutableMapOf<StepContainerInterface,StepContainerInterface>()
    internal val importMap = mutableMapOf<StepContainerInterface,MutableList<URI>>()

    fun parseLibrary(filename: String): LibraryInstruction {
        val library = parse(filename)
        if (library is LibraryInstruction) {
            return library
        }
        throw IllegalArgumentException("Not a p:library: $filename")
    }

    fun parseLibrary(source: InputSource): LibraryInstruction {
        val library = parse(source)
        if (library is LibraryInstruction) {
            return library
        }
        throw IllegalArgumentException("Not a p:library")
    }

    fun parsePipeline(filename: String): DeclareStepInstruction {
        val pipeline = parse(filename)
        if (pipeline is DeclareStepInstruction) {
            return pipeline
        }
        throw IllegalArgumentException("Not a p:declare-step: $filename")
    }

    fun parsePipeline(source: InputSource): DeclareStepInstruction {
        val pipeline = parse(source)
        if (pipeline is DeclareStepInstruction) {
            return pipeline
        }
        throw IllegalArgumentException("Not a p:declare-step")
    }

    private fun parse(filename: String): XProcInstruction {
        val source = InputSource(FileReader(File(filename)))
        source.systemId = UriUtils.cwdAsUri().resolve(filename).toString()
        return parse(source)
    }

    private fun parse(source: InputSource): XProcInstruction {
        val processor = configuration.xprocConfiguration.saxonConfiguration().processor
        val builder = processor.newDocumentBuilder()
        builder.isLineNumbering = true
        val destination = XdmDestination()
        builder.parse(SAXSource(source), destination)
        val doc = destination.xdmNode
        val root = S9Api.documentElement(doc)

        when (root.nodeName) {
            NsP.declareStep -> return parseFromDeclareStep(root)
            NsP.library -> return parseFromLibrary(root)
            else -> throw IllegalArgumentException("Not a valid root element: ${root.nodeName}")
        }
    }

    private fun parseFromLibrary(root: XdmNode): LibraryInstruction {
        val stepConfig = StepConfiguration.getInstance(configuration).newInstance(root)
        val container = XProcLibraryNode(this, stepConfig, root)

        standardLibrary = parseStandardLibrary()

        container.loadPipeline()
        container.resolveStaticStructure()

        val pipeline = build(container)
        containerMap[container] = pipeline
        for (import in importedContainers.values) {
            containerMap[import] = build(import)
        }
        for (lib in containerMap.values) {
            addImports(lib)
        }

        pipeline.validate()

        if (pipeline is DeclareStepInstruction) {
            val graph = Graph.build(pipeline)
            println(graph)
        }

        return pipeline

    }


    private fun parseFromDeclareStep(root: XdmNode): DeclareStepInstruction {
        val stepConfig = StepConfiguration.getInstance(configuration).newInstance(root)
        val container: XProcStepContainer = when (root.nodeName) {
            NsP.declareStep -> XProcDeclareStepNode(this, stepConfig, root)
            NsP.library -> XProcLibraryNode(this, stepConfig, root)
            else -> throw RuntimeException("Invalid root: ${root.nodeName}")
        }

        standardLibrary = parseStandardLibrary()

        container.loadPipeline()
        container.resolveStaticStructure()
        //container.compileApis()

        val pipeline = build(container)
        containerMap[container] = pipeline
        for (import in importedContainers.values) {
            containerMap[import] = build(import)
        }
        for (lib in containerMap.values) {
            addImports(lib)
        }

        pipeline.validate()

        if (pipeline is DeclareStepInstruction) {
            val graph = Graph.build(pipeline)
            println(graph)
        }

        return pipeline

    }

    private fun addImports(container: StepContainer) {
        for (uri in importMap[container]!!) {
            val import = importedContainers[uri]!!
            container.addImportLibrary(containerMap[import]!!)
        }
        for (decl in container.children.filterIsInstance<StepContainer>()) {
            addImports(decl)
        }
    }

    fun parseStandardLibrary(): XProcLibraryNode {
        val processor = configuration.xprocConfiguration.saxonConfiguration().processor
        val builder = processor.newDocumentBuilder()
        builder.isLineNumbering = true
        val destination = XdmDestination()

        val baseURI = URI("classpath:/com/xmlcalabash/library.xpl")
        val stream = PipelineParser::class.java.getResourceAsStream("/com/xmlcalabash/library.xpl")
            ?: throw IllegalArgumentException("Failed to load standard step library from classpath")

        val source = InputSource(stream)
        source.systemId = "https://xmlcalabash.com/library/library.xpl"

        builder.parse(SAXSource(source), destination)
        val doc = destination.xdmNode
        val root = S9Api.documentElement(doc)

        val stepConfig = StepConfiguration.getInstance(configuration).newInstance(root)
        val container = XProcLibraryNode(this, stepConfig, root)

        container.loadPipeline()
        container.resolveStaticStructure()

        for (child in containerSteps(container)) {
            if (child.stepType != null && child.attributes[Ns.visibility] != "private") {
                container.exports[child.stepType!!] = VisibleStep(child)
            }
        }

        //container.compileApis()
        return container
    }

    internal fun containerSteps(container: XProcStepContainer): List<XProcDeclareStepNode> {
        return if (container.nodeName == NsP.declareStep) {
            listOf(container as XProcDeclareStepNode)
        } else {
            container.children.filterIsInstance<XProcDeclareStepNode>()
        }
    }

    internal fun resolveImports() {
        // Work out what's directly exported by each container
        for (container in importedContainers.values) {
            container.exports.clear()

            for (child in containerSteps(container)) {
                if (child.stepType != null && child.attributes[Ns.visibility] != "private") {
                    container.exports[child.stepType!!] = VisibleStep(child)
                }
            }
        }

        // Work out what's visible in each container: the steps in this container plus the union
        // of all the exports of containers that are imported (recursively) into this container
        for (container in importedContainers.values) {
            val visible = traverse(container, setOf())
            for (child in containerSteps(container)) {
                if (child.stepType != null) {
                    val current = visible[child.stepType!!]
                    if (current == null || current.conditional) {
                        visible[child.stepType!!] = VisibleStep(child)
                    }
                }
            }
            container.visible.clear()
            container.visible.putAll(visible)
        }

        for (container in importedContainers.values) {
            container.computeInscopeStepTypes(mapOf())
        }
    }

    private fun traverse(container: XProcStepContainer, visited: Set<XProcStepContainer>): MutableMap<QName,VisibleStep> {
        val visible = mutableMapOf<QName, VisibleStep>()
        if (container in visited) {
            return visible
        }

        visible.putAll(container.exports)

        for (child in container.children.filterIsInstance<XProcImportNode>()) {
            if (child.href in importedContainers) {
                val conditionalImport = child.useWhenExpression != null
                val additions = traverse(importedContainers[child.href!!]!!, visited + container)
                for ((name, value) in additions) {
                    val current = visible[name]
                    if (current == null || current.conditional) {
                        value.conditional = value.conditional || conditionalImport
                        visible[name] = value
                    }
                }
            }
        }

        return visible
    }

    private fun build(container: XProcStepContainer): StepContainerInterface {
        val decl = parseContainer(container)
        return decl
    }

    private fun buildLibrary(node: XProcLibraryNode): LibraryInstruction {
        val lib = LibraryInstruction(node.stepConfig)
        val stepConfig = lib.stepConfig
        importMap[lib] = mutableListOf()

        val attributeMapping = mapOf<QName, (String) -> Unit>(
            Ns.psviRequired to { value: String -> lib.psviRequired = stepConfig.parseBoolean(value) },
            Ns.xpathVersion to { value: String -> lib.xpathVersion = value.toDouble() },
            Ns.excludeInlinePrefixes to { value: String -> stepConfig.parseExcludeInlinePrefixes(value) },
            Ns.version to { value: String -> lib.version = value.toDouble() },
            Ns.expandText to { value: String -> lib.expandText = stepConfig.parseBoolean(value)}
        )

        processAttributes(node, lib, attributeMapping)

        for (child in node.children) {
            when (child.nodeName) {
                NsP.import -> {
                    // Libraries can be imported more than once, but in the data model,
                    // we want only one object for each library. Ignore them here, we'll patch
                    // them up later when we have the whole set. For now, just keep track
                    // of the imported URI.
                    importMap[lib]!!.add((child as XProcImportNode).href!!)
                }
                NsP.option -> {
                    parseOption(lib, child as XProcOptionNode)
                }
                NsP.declareStep -> lib.addDeclareStep(parseDeclareStep(child as XProcDeclareStepNode))
                else -> stepConfig.reportError(XProcError.xsInvalidElement(child.nodeName))
            }
        }

        return lib
    }

    private fun buildDeclareStep(node: XProcDeclareStepNode): DeclareStepInstruction {
        val name = node.attributes[Ns.name] ?: "!declstep_${node.stepConfig.pipelineConfig.nextId}"
        val decl = DeclareStepInstruction(null, node.stepConfig, name)
        return parseDeclareStep(node, decl)
    }

    private fun parseContainer(container: XProcStepContainer): StepContainerInterface {
        val decl = when (container) {
            is XProcDeclareStepNode -> buildDeclareStep(container)
            is XProcLibraryNode -> buildLibrary(container)
            else -> throw RuntimeException("Invalid container: ${container.nodeName}")
        }
        return decl
    }

    private fun parseDeclareStep(node: XProcDeclareStepNode): DeclareStepInstruction {
        val name = node.attributes[Ns.name] ?: "!declstep_${node.stepConfig.pipelineConfig.nextId}"
        return parseDeclareStep(node, DeclareStepInstruction(null, node.stepConfig, name))
    }

    private fun parseDeclareStep(node: XProcDeclareStepNode, decl: DeclareStepInstruction): DeclareStepInstruction {
        val stepConfig = decl.stepConfig
        importMap[decl] = mutableListOf()

        val attributeMapping = mapOf<QName, (String) -> Unit>(
            Ns.name to { _ -> },
            Ns.type to { value: String -> decl.type = stepConfig.parseQName(value) },
            Ns.psviRequired to { value: String -> decl.psviRequired = stepConfig.parseBoolean(value) },
            Ns.xpathVersion to { value: String -> decl.xpathVersion = value.toDouble() },
            Ns.excludeInlinePrefixes to { value: String -> stepConfig.parseExcludeInlinePrefixes(value) },
            Ns.version to { value: String -> decl.version = value.toDouble() },
            Ns.visibility to { value: String -> decl.visibility = stepConfig.parseVisibility(value) },
            Ns.expandText to { value: String -> decl.expandText = stepConfig.parseBoolean(value)}
        )

        processAttributes(node, decl, attributeMapping)

        for (child in node.children) {
            when (child.nodeName) {
                NsP.import -> {
                    // Libraries can be imported more than once, but in the data model,
                    // we want only one object for each library. Ignore them here, we'll patch
                    // them up later when we have the whole set. For now, just keep track
                    // of the imported URI.
                    importMap[decl]!!.add((child as XProcImportNode).href!!)
                }
                NsP.input -> {
                    val port = child.attributes[Ns.port]
                    if (port == null) {
                        stepConfig.reportError(XProcError.xsMissingRequiredAttribute(Ns.port))
                    } else {
                        var value = child.attributes[Ns.primary]
                        val primary = if (value != null) { stepConfig.parseBoolean(value) } else { null }
                        value = child.attributes[Ns.sequence]
                        val sequence = if (value != null) { stepConfig.parseBoolean(value) } else { null }
                        val input = decl.input(port, primary, sequence)
                        parseInput(input, child)
                    }
                }
                NsP.output -> {
                    val port = child.attributes[Ns.port]
                    if (port == null) {
                        stepConfig.reportError(XProcError.xsMissingRequiredAttribute(Ns.port))
                    } else {
                        var value = child.attributes[Ns.primary]
                        val primary = if (value != null) { stepConfig.parseBoolean(value) } else { null }
                        value = child.attributes[Ns.sequence]
                        val sequence = if (value != null) { stepConfig.parseBoolean(value) } else { null }
                        val output = decl.output(port, primary, sequence)
                        parseOutput(output, child)
                    }
                }
                NsP.option -> parseOption(decl, child)
                NsP.variable -> parseVariable(decl, child)
                NsP.declareStep -> {
                    val sdecl = decl.declareStep(child.attributes[Ns.name])
                    parseDeclareStep(child as XProcDeclareStepNode, sdecl)
                }
                NsP.forEach -> parseForEach(decl, child)
                else -> {
                    val adecl = node.visible[child.nodeName] ?: standardLibrary.visible[child.nodeName]
                    if (adecl == null) {
                        decl.stepConfig.reportError(XProcError.xsMissingStepDeclaration(child.nodeName))
                    }
                    parseAtomicStep(decl.atomicStep(child.nodeName, child.attributes[Ns.name]), adecl!!.step, child)
                }
            }
        }

        return decl
    }

    internal fun parseOption(decl: StepContainer, node: XProcNode) {
        try {
            val name = node.attributes[Ns.name]?.let { node.stepConfig.parseQName(it) }
            val staticOpt = node.attributes[Ns.static]?.let { node.stepConfig.parseBoolean(it) }

            if (name == null) {
                node.stepConfig.reportError(XProcError.xsMissingRequiredAttribute(Ns.name))
                return
            }

            val option = if (staticOpt == true) {
                decl.option(name, (node as XProcOptionNode).staticValue!!)
            } else {
                decl.option(name)
            }

            val stepConfig = option.stepConfig

            val attributeMapping = mapOf<QName, (String) -> Unit>(
                Ns.name to { _ -> }, // Already handled
                Ns.static to { _ -> }, // Already handled
                Ns.values to { value: String -> option.values = stepConfig.parseValues(value) },
                Ns.required to { value: String -> option.required = stepConfig.parseBoolean(value) },
                Ns.select to { value: String -> option.select = XProcExpression.select(stepConfig, value) },
                Ns.visibility to { value: String -> option.visibility = stepConfig.parseVisibility(value) },
                Ns.asType to { value: String -> option.asType = stepConfig.parseSequenceType(value) },
                Ns.expandText to { value: String -> option.expandText = stepConfig.parseBoolean(value)}
            )

            processAttributes(node, option, attributeMapping)
            forbidChildren(node, stepConfig)
        } catch (ex: Exception) {
            when (ex) {
                is XProcException -> node.stepConfig.reportError(ex.error)
                else -> throw ex
            }
        }
    }

    private fun parseWithOption(step: AtomicStepInstruction, node: XProcNode): WithOptionInstruction? {
        try {
            val name = node.attributes[Ns.name]?.let { node.stepConfig.parseQName(it) }

            if (name == null) {
                node.stepConfig.reportError(XProcError.xsMissingRequiredAttribute(Ns.name))
                return null
            }

            val option = step.withOption(name)
            val stepConfig = option.stepConfig

            val attributeMapping = mapOf<QName, (String) -> Unit>(
                Ns.name to { _ -> }, // Already handled
                Ns.select to { value: String -> option.select = XProcExpression.select(stepConfig, value) },
                Ns.expandText to { value: String -> option.expandText = stepConfig.parseBoolean(value)}
            )

            processAttributes(node, option, attributeMapping)
            parseBindingChildren(node, option, true)

            return option
        } catch (ex: Exception) {
            when (ex) {
                is XProcException -> node.stepConfig.reportError(ex.error)
                else -> throw ex
            }
            return null
        }
    }

    internal fun parseVariable(decl: DeclareStepInstruction, node: XProcNode) {
        try {
            val name = node.attributes[Ns.name]?.let { node.stepConfig.parseQName(it) }
            if (name == null) {
                node.stepConfig.reportError(XProcError.xsMissingRequiredAttribute(Ns.name))
                return
            }

            val variable = decl.variable(name)
            val stepConfig = variable.stepConfig

            val attributeMapping = mapOf<QName, (String) -> Unit>(
                Ns.name to { _ -> }, // Already handled
                Ns.expandText to { value: String -> variable.expandText = stepConfig.parseBoolean(value)},
                Ns.asType to { value: String -> variable.asType = stepConfig.parseSequenceType(value) },
                Ns.select to { value: String -> variable.select = XProcExpression.select(stepConfig, value) },
                Ns.collection to { value: String -> variable.collection = stepConfig.parseBoolean(value)},
                Ns.href to { value: String -> variable.href = XProcExpression.avt(stepConfig, value) },
                Ns.pipe to { value: String -> variable.pipe = value }
                )

            processAttributes(node, variable, attributeMapping)
            parseBindingChildren(node, variable, true)
        } catch (ex: Exception) {
            when (ex) {
                is XProcException -> node.stepConfig.reportError(ex.error)
                else -> throw ex
            }
        }
    }

    internal fun parseInput(input: InputInstruction, node: XProcNode): InputInstruction {
        val stepConfig = input.stepConfig

        val attributeMapping = mapOf<QName, (String) -> Unit>(
            Ns.port to { value: String -> input.port = stepConfig.parseNCName(value) },
            Ns.sequence to { value: String -> input.sequence = stepConfig.parseBoolean(value) },
            Ns.primary to { value: String -> input.primary = stepConfig.parseBoolean(value) },
            Ns.select to { value: String -> input.select = XProcExpression.select(stepConfig, value) },
            Ns.contentTypes to { value: String -> input.contentTypes = stepConfig.parseContentTypes(value) },
            Ns.href to { value: String -> input.href = XProcExpression.avt(stepConfig, value) },
            Ns.excludeInlinePrefixes to { value: String -> stepConfig.parseExcludeInlinePrefixes(value) },
            Ns.expandText to { value: String -> input.expandText = stepConfig.parseBoolean(value)}
        )

        processAttributes(node, input, attributeMapping)
        parseBindingChildren(node, input, false)

        return input
    }

    private fun parseWithInput(step: AtomicStepInstruction, node: XProcNode): WithInputInstruction {
        val withInput = step.withInput()
        val stepConfig = withInput.stepConfig

        val attributeMapping = mapOf<QName, (String) -> Unit>(
            Ns.port to { value: String -> withInput.port = stepConfig.parseNCName(value) },
            Ns.select to { value: String -> withInput.select = XProcExpression.select(stepConfig, value) },
            Ns.href to { value: String -> withInput.href = XProcExpression.avt(stepConfig, value) },
            Ns.excludeInlinePrefixes to { value: String -> stepConfig.parseExcludeInlinePrefixes(value) },
            Ns.expandText to { value: String -> withInput.expandText = stepConfig.parseBoolean(value)}
        )

        processAttributes(node, withInput, attributeMapping)
        parseBindingChildren(node, withInput, true)

        return withInput
    }

    internal fun parseOutput(output: OutputInstruction, node: XProcNode): OutputInstruction {
        val stepConfig = output.stepConfig

        val attributeMapping = mapOf<QName, (String) -> Unit>(
            Ns.port to { value: String -> output.port = stepConfig.parseNCName(value) },
            Ns.sequence to { value: String -> output.sequence = stepConfig.parseBoolean(value) },
            Ns.primary to { value: String -> output.primary = stepConfig.parseBoolean(value) },
            Ns.contentTypes to { value: String -> output.contentTypes = stepConfig.parseContentTypes(value) },
            Ns.href to { value: String -> output.href = XProcExpression.avt(stepConfig, value) },
            Ns.pipe to { value: String -> output.pipe = value },
            Ns.excludeInlinePrefixes to { value: String -> stepConfig.parseExcludeInlinePrefixes(value) },
            Ns.serialization to { value: String -> output.serialization = XProcExpression.select(stepConfig, value) },
            Ns.expandText to { value: String -> output.expandText = stepConfig.parseBoolean(value)}
        )

        processAttributes(node, output, attributeMapping)
        parseBindingChildren(node, output, true)

        return output
    }

    private fun parseBindingChildren(node: XProcNode, instruction: BindingContainer, allowPipe: Boolean = true) {
        for (child in node.children) {
            when (child.nodeName) {
                NsP.empty -> parseEmpty(instruction.empty(), child)
                NsP.document -> parseDocument(instruction, child)
                NsP.inline -> parseInline(instruction.inline((child as XProcInlineNode).inlineXml()), child)
                NsP.pipe -> {
                    if (allowPipe) {
                        parsePipe(instruction.pipe(), child)
                    } else {
                        child.stepConfig.reportError(XProcError.xsInvalidElement(child.nodeName))
                    }
                }
                else -> {
                    val inline = instruction.inline((child as XProcImplicitInlineNode).inlineXml())
                }
            }
        }
    }

    private fun parseEmpty(empty: EmptyInstruction, node: XProcNode): EmptyInstruction {
        forbidChildren(node, empty.stepConfig)
        return empty
    }

    private fun parsePipe(pipe: PipeInstruction, node: XProcNode): PipeInstruction {
        val attributeMapping = mapOf<QName, (String) -> Unit>(
            Ns.step to { value: String -> pipe.step = value },
            Ns.port to { value: String -> pipe.port = value },
            Ns.expandText to { value: String -> pipe.expandText = pipe.stepConfig.parseBoolean(value)}
        )

        processAttributes(node, pipe, attributeMapping)
        forbidChildren(node, pipe.stepConfig)

        return pipe
    }

    private fun parseDocument(instruction: BindingContainer, node: XProcNode): DocumentInstruction? {
        if (node.attributes[Ns.href] == null) {
            node.stepConfig.reportError(XProcError.xsMissingRequiredAttribute(Ns.href))
            return null
        }

        val document = instruction.document(XProcExpression.avt(instruction.stepConfig, node.attributes[Ns.href]!!))
        val stepConfig = document.stepConfig

        val attributeMapping = mapOf<QName, (String) -> Unit>(
            Ns.href to { _ -> }, // handled above
            Ns.contentType to { value: String -> document.contentType = MediaType.parse(value) },
            Ns.documentProperties to { value: String -> document.documentProperties = XProcExpression.select(stepConfig, value) },
            Ns.parameters to { value: String -> document.parameters = XProcExpression.select(stepConfig, value) },
            Ns.expandText to { value: String -> document.expandText = stepConfig.parseBoolean(value)}
        )

        processAttributes(node, document, attributeMapping)
        forbidChildren(node, stepConfig)

        return document
    }

    private fun parseInline(inline: InlineInstruction, node: XProcInlineNode): InlineInstruction {
        val stepConfig = inline.stepConfig

        val attributeMapping = mapOf<QName, (String) -> Unit>(
            Ns.excludeInlinePrefixes to { value: String -> stepConfig.parseExcludeInlinePrefixes(value) },
            Ns.contentType to { value: String -> inline.contentType = MediaType.parse(value) },
            Ns.documentProperties to { value: String -> inline.documentProperties = XProcExpression.select(stepConfig, value) },
            Ns.encoding to { value: String -> inline.encoding = value },
            Ns.expandText to { value: String -> inline.expandText = stepConfig.parseBoolean(value)}
        )

        processAttributes(node, inline, attributeMapping)
        forbidChildren(node, stepConfig)

        return inline
    }

    private fun parseForEach(decl: DeclareStepInstruction, node: XProcNode): ForEachInstruction {
        val forEach = decl.forEach(node.attributes[Ns.name])
        return forEach
    }

    private fun parseAtomicStep(step: AtomicStepInstruction, decl: XProcDeclareStepNode, node: XProcNode): XProcStepInstruction {
        val stepConfig = step.stepConfig

        val seenOptions = mutableSetOf<QName>()
        val seenPorts = mutableSetOf<String>()

        /*
        val legalOptions = mutableMapOf<QName, OptionInstruction>()
        val legalInputs = mutableMapOf<String, InputInstruction>()
        for (api in decl.api) {
            when (api) {
                is OptionInstruction -> legalOptions[api.name] = api
                is InputInstruction -> legalInputs[api.port] = api
                is OutputInstruction -> Unit
                else -> TODO("What else can occur here?")
            }
        }
         */

        val standardStep = node.nodeName.namespaceUri == NsP.namespace
        for ((name, value) in node.attributes) {
            if ((standardStep && name == Ns.message) || (!standardStep && name == NsP.message)) {
                TODO("handle message attribute")
            } else if ((standardStep && name == Ns.depends) || (!standardStep && name == NsP.depends)) {
                TODO("handle depends attribute")
            } else if ((standardStep && name == Ns.expandText || (!standardStep && name == NsP.expandText))) {
                step.expandText = stepConfig.parseBoolean(value)
            } else if (name == Ns.name) {
                Unit
            } else {
                if (name.namespaceUri == NamespaceUri.NULL) {
                    seenOptions.add(name)
                    val option = step.withOption(name)
                    option.wasShortcut = true
                    option.select = XProcExpression.avt(stepConfig, ValueTemplateParser.parse(value))
                } else {
                    step.setExtensionAttribute(name, value)
                }
            }
        }

        for (child in node.children) {
            when (child.nodeName) {
                NsP.withInput -> {
                    val withInput = parseWithInput(step, child)
                    val portKey = withInput.port
                    if (seenPorts.contains(portKey)) {
                        stepConfig.reportError(XProcError.xsDuplicatePortName(portKey))
                    }
                }
                NsP.withOption -> {
                    val option = parseWithOption(step, child)
                    if (option != null) {
                        if (seenOptions.contains(option.name)) {
                            stepConfig.reportError(XProcError.xsDuplicateOption(option.name))
                        }
                    }
                }
                else -> {
                    stepConfig.reportError(XProcError.xsInvalidElement(child.nodeName))
                }
            }
        }

        return step
    }

    // ============================================================

    private fun subpipeline(node: XProcNode, instruction: CompoundContainer) {
        val stepConfig = instruction.stepConfig

        val attributeMapping = mapOf<QName, (String) -> Unit>(
            Ns.name to { _ -> },
        )

        processAttributes(node, instruction, attributeMapping)

        /*
        for (child in node.children) {
            when (child.nodeName) {
                NsP.output -> {
                    val port = child.attributes[Ns.port]
                    if (port == null) {
                        stepConfig.reportError(XProcError.xsMissingRequiredAttribute(Ns.port))
                    } else {
                        /*
                        var value = child.attributes[Ns.primary]
                        val primary = if (value != null) { stepConfig.parseBoolean(value) } else { null }
                        value = child.attributes[Ns.sequence]
                        val sequence = if (value != null) { stepConfig.parseBoolean(value) } else { null }
                         */
                        val output = instruction.output(port)
                        parseOutput(output, child)
                    }
                }
                NsP.variable -> parseVariable(instruction, child)
                NsP.declareStep -> {
                    val sdecl = decl.declareStep(child.attributes[Ns.name])
                    parseDeclareStep(child as XProcDeclareStepNode, sdecl)
                }
                NsP.forEach -> parseForEach(decl, child)
                else -> {
                    val adecl = node.visible[child.nodeName] ?: standardLibrary.visible[child.nodeName]
                    if (adecl == null) {
                        decl.stepConfig.reportError(XProcError.xsMissingStepDeclaration(child.nodeName))
                    }
                    parseAtomicStep(decl.atomicStep(child.nodeName, child.attributes[Ns.name]), adecl!!.step, child)
                }
            }
        }

         */
    }

    private fun forbidChildren(node: XProcNode, stepConfig: StepConfiguration) {
        for (child in node.children) {
            stepConfig.reportError(XProcError.xsInvalidElement(child.nodeName))
        }
    }

    private fun processAttributes(node: XProcNode, instruction: XProcInstruction, attributeMapping: Map<QName, (String) -> Unit>) {
        for ((name, value) in node.attributes) {
            if (attributeMapping.containsKey(name)) {
                try {
                    attributeMapping[name]!!(value)
                } catch (ex: Exception) {
                    if (ex is XProcException) {
                        node.stepConfig.reportError(ex.error)
                    } else {
                        throw ex
                    }
                }
            } else {
                if (node.nodeName.namespaceUri == NsP.namespace) {
                    // This is a p:xxx element
                    if (name == Ns.useWhen) {
                        // ignore this
                    } else {
                        if (name.namespaceUri != NamespaceUri.NULL) {
                            instruction.setExtensionAttribute(name, value)
                        } else {
                            node.stepConfig.reportError(XProcError.xsInvalidAttribute(name))
                        }
                    }
                } else {
                    // This is not a p:xxx element
                    if (name == NsP.useWhen) {
                        // ignore this
                    } else {
                        if (name.namespaceUri != NamespaceUri.NULL) {
                            instruction.setExtensionAttribute(name, value)
                        } else {
                            node.stepConfig.reportError(XProcError.xsInvalidAttribute(name))
                        }
                    }
                }
            }
        }
    }

    private fun parseMap(node: XProcNode, instruction: XProcInstruction, expr: String): Map<QName, XdmValue> {
        val compiler = instruction.stepConfig.newXPathCompiler()
        for ((name, value) in node.staticOptions) {
            if (value != null) {
                compiler.declareVariable(name)
            }
        }
        val selector = compiler.compile(expr).load()
        for ((name, value) in node.staticOptions) {
            if (value != null) {
                selector.setVariable(name, value)
            }
        }
        val map = selector.evaluate()
        return instruction.stepConfig.asMap(map as XdmMap)
    }
}
