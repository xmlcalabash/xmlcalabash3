package com.xmlcalabash.datamodel

import com.xmlcalabash.exceptions.XProcError
import com.xmlcalabash.namespace.Ns
import com.xmlcalabash.namespace.NsP
import net.sf.saxon.s9api.QName
import java.net.URI

open class VariableInstruction(parent: XProcInstruction, name: QName): VariableBindingContainer(parent, name, NsP.variable) {
    private var context: InstructionStaticContext? = null

    override fun elaborate() {
        if (select == null) {
            reportError(XProcError.xsMissingRequiredAttribute(Ns.select))
        } else {
            asType = asType ?: stepConfig.parseSequenceType("item()*")
            select = select!!.cast(asType!!)
            if (select!!.contextRef && children.isEmpty()) {
                pipe()
            }
        }

        super.elaborate()
    }

    override fun staticAnalysis(context: InstructionStaticContext) {
        this.context = context
        super.staticAnalysis(context)
    }

    fun promoteToStep(step: XProcInstruction): List<AtomicStepInstruction> {
        if (staticValue != null) {
            return emptyList()
        }

        val exprStep = AtomicExpressionStepInstruction(step, select!!)
        for (name in select!!.variableRefs) {
            val variable = context!!.inscopeVariables[name]!!
            if (variable.withOutput != null) {
                val wi = exprStep.withInput()
                wi.port = "Q{${name.namespaceUri}${name.localName}"
                val pipe = wi.pipe()
                pipe.setReadablePort(variable.withOutput!!)
            }
        }

        val steps = mutableListOf<AtomicStepInstruction>()
        if (children.isNotEmpty()) {
            val wi = exprStep.withInput()
            wi.port = "source"
            for (child in children) {
                val csteps = (child as ConnectionInstruction).promoteToStep(step)
                if (csteps.isNotEmpty()) {
                    val last = csteps.last()
                    val pipe = wi.pipe()
                    pipe.setReadablePort(last.primaryOutput()!!)
                }
                steps.addAll(csteps)
            }
        }

        steps.add(exprStep)
        return steps
    }

}