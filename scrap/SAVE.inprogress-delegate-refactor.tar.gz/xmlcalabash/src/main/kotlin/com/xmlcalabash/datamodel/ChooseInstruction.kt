package com.xmlcalabash.datamodel

import com.xmlcalabash.exceptions.XProcError
import com.xmlcalabash.namespace.NsP
import com.xmlcalabash.xprocparser.StepConfiguration

class ChooseInstruction(parent: XProcInstruction, stepConfig: StepConfiguration, name: String?): CompoundContainer(parent, stepConfig, NsP.group, name) {
    override val contentModel = mapOf(NsP.withInput to '1', NsP.`when` to '*', NsP.otherwise to '?')

    fun addWhen(whenInstruction: WhenInstruction) {
        _children.add(whenInstruction)
    }

    fun addOtherwise(otherwiseInstruction: OtherwiseInstruction) {
        if (children.filterIsInstance<OtherwiseInstruction>().isNotEmpty()) {
            otherwiseInstruction.reportError(XProcError.xsInvalidElement(otherwiseInstruction.instructionType))
            return
        }
        _children.add(otherwiseInstruction)
    }
}