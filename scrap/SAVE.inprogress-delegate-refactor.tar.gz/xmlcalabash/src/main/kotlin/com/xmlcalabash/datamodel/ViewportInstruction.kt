package com.xmlcalabash.datamodel

import com.xmlcalabash.namespace.NsP
import com.xmlcalabash.xprocparser.StepConfiguration

class ViewportInstruction(parent: XProcInstruction, stepConfig: StepConfiguration, name: String?): CompoundContainer(parent, stepConfig, NsP.viewport, name) {
    companion object {
        private val INVALID_MATCH = "*** no match pattern specified ***"
    }

    override val contentModel = anySteps + mapOf(NsP.withInput to '1', NsP.output to '1')

    var match: String = INVALID_MATCH
        set(value) {
            checkOpen()
            field = value
        }
}