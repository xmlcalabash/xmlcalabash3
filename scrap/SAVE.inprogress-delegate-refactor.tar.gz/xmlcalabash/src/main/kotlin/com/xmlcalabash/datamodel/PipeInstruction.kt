package com.xmlcalabash.datamodel

import com.xmlcalabash.exceptions.XProcError
import com.xmlcalabash.namespace.NsP
import com.xmlcalabash.xprocparser.StepConfiguration
import java.nio.channels.Pipe

class PipeInstruction(parent: XProcInstruction): ConnectionInstruction(parent, NsP.pipe) {
    private var _readablePort: PortBindingContainer? = null
    val readablePort: PortBindingContainer?
        get() = _readablePort

    constructor(parent: XProcInstruction, step: String?, port: String?): this(parent) {
        this.step = step
        this.port = port
    }

    var step: String? = null
        set(value) {
            checkOpen()
            field = value
        }

    var port: String? = null
        set(value) {
            checkOpen()
            field = value
        }

    override fun staticAnalysis(context: InstructionStaticContext) {
        val fromStep = if (step == null) {
            if (context.drp == null) {
                reportError(XProcError.xsPortNotReadable())
                return
            }
            context.drp!!.parent as NamedInstruction
        } else {
            if (context.inscopeStepNames.contains(step)) {
                context.inscopeStepNames[step]!!
            } else {
                reportError(XProcError.xsPortNotReadable(step!!))
                return
            }
        }

        step = fromStep.name

        val fromPort = if (hasAncestor(fromStep)) {
            if (port == null) {
                fromStep.primaryInput()
            } else {
                fromStep.namedInput(port!!)
            }
        } else {
            if (port == null) {
                fromStep.primaryOutput()
            } else {
                fromStep.namedOutput(port!!)
            }
        }

        if (fromPort == null) {
            if (port == null) {
                reportError(XProcError.xsPortNotReadable())
            } else {
                reportError(XProcError.xsPortNotReadable(port!!))
            }
        } else {
            port = fromPort.port
            _readablePort = fromPort
        }

        super.staticAnalysis(context)
    }

    fun setReadablePort(readable: PortBindingContainer) {
        _readablePort = readable
        step = (readable.parent!! as NamedInstruction).name
        port = readable.port
    }

    override fun promoteToStep(step: XProcInstruction): List<AtomicStepInstruction> {
        // Pipes don't get promoted
        return emptyList()
    }

    override fun toString(): String {
        return "${instructionType}/${id} step=${step ?: ""} port=${port ?: ""}"
    }
}