package com.xmlcalabash.datamodel

import com.xmlcalabash.namespace.NsP
import com.xmlcalabash.xprocparser.StepConfiguration
import net.sf.saxon.s9api.QName

class CatchInstruction(parent: XProcInstruction, stepConfig: StepConfiguration, name: String?): CompoundContainer(parent, stepConfig, NsP.catch, name) {
    override val contentModel = anySteps + mapOf(NsP.withInput to '0', NsP.output to '*')

    private val _code = mutableListOf<QName>()
    var code: List<QName>
        get() = _code
        set(value) {
            checkOpen()
            _code.clear()
            _code.addAll(value)
        }
}