package com.xmlcalabash.io

class DocumentManager {
}