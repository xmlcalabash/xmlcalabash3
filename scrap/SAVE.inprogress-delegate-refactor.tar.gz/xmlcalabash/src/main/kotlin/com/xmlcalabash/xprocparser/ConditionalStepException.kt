package com.xmlcalabash.xprocparser

class ConditionalStepException(message: String): RuntimeException(message) {
}