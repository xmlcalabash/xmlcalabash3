package com.xmlcalabash.datamodel

import com.xmlcalabash.exceptions.XProcError
import com.xmlcalabash.xprocparser.StepConfiguration
import net.sf.saxon.s9api.QName

internal class InstructionStaticContext(val stepConfig: StepConfiguration) {
    //val inscopeStepTypes = mutableMapOf<QName, DeclareStepInstruction>()
    val inscopeStepNames = mutableMapOf<String, NamedInstruction>()
    val inscopeVariables = mutableMapOf<QName, VariableBindingContainer>()
    //val importedLibraries = mutableSetOf<URI>()
    var drp: PortBindingContainer? = null

    fun copy(): InstructionStaticContext {
        val copy = InstructionStaticContext(stepConfig)
        //copy.inscopeStepTypes.putAll(inscopeStepTypes)
        copy.inscopeStepNames.putAll(inscopeStepNames)
        copy.inscopeVariables.putAll(inscopeVariables)
        //copy.importedLibraries.addAll(importedLibraries)
        copy.drp = drp
        return copy
    }

    fun addInscopeStepName(step: NamedInstruction) {
        if (inscopeStepNames.containsKey(step.name)) {
            step.stepConfig.reportError(XProcError.xsDuplicateStepName(step.name))
        }
        inscopeStepNames[step.name] = step
    }

    fun addInscopeVariable(binding: VariableBindingContainer) {
        val current = inscopeVariables[binding.name]
        if (current is OptionInstruction && current.static) {
            binding.reportError(XProcError.xsShadowStaticOption(binding.name))
            return
        }

        inscopeVariables[binding.name] = binding
    }

}