package com.xmlcalabash.datamodel

import com.xmlcalabash.namespace.NsP
import com.xmlcalabash.xprocparser.StepConfiguration

class FinallyInstruction(parent: XProcInstruction, stepConfig: StepConfiguration, name: String?): CompoundContainer(parent, stepConfig, NsP.finally, name) {
    override val contentModel = anySteps + mapOf(NsP.withInput to '0', NsP.output to '*')
}