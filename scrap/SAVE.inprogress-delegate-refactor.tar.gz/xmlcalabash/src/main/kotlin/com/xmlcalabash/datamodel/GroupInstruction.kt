package com.xmlcalabash.datamodel

import com.xmlcalabash.namespace.NsP
import com.xmlcalabash.xprocparser.StepConfiguration

class GroupInstruction(parent: XProcInstruction, stepConfig: StepConfiguration, name: String?): CompoundContainer(parent, stepConfig, NsP.group, name) {
    override val contentModel = anySteps + mapOf(NsP.withInput to '0', NsP.output to '*')
}