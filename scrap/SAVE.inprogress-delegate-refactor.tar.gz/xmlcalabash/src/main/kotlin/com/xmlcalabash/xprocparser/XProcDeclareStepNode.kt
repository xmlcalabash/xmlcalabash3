package com.xmlcalabash.xprocparser

import com.xmlcalabash.datamodel.XProcInstruction
import com.xmlcalabash.namespace.Ns
import com.xmlcalabash.namespace.NsP
import net.sf.saxon.s9api.QName
import net.sf.saxon.s9api.XdmNode
import java.net.URI

class XProcDeclareStepNode(parser: PipelineParser, stepConfig: StepConfiguration, node: XdmNode): XProcStepContainer(parser, stepConfig, node) {
    private var _stepType: QName? = null
    override val stepType: QName?
        get() = _stepType
    private var compiledApi = false
/*
    private var _api = mutableListOf<XProcInstruction>()
    internal val api: List<XProcInstruction>
        get() = _api
 */

    init {
        if (attributes[Ns.type] != null) {
            _stepType = stepConfig.parseQName(attributes[Ns.type]!!)
        }
    }

    /*
    internal fun compileApi() {
        if (compiledApi) {
            return
        }

        // Don't try to import the standard library into the standard library...
        if (baseUri != URI("https://xmlcalabash.com/library/library.xpl")) {
            visible.putAll(parser.standardLibrary.exports)
        }

        for (child in children) {
            when (child.nodeName) {
                NsP.input -> _api.add(parser.parseInput(child))
                NsP.output -> _api.add(parser.parseOutput(child))
                NsP.option -> parser.parseOption(child)?.let { _api.add(it) }
                else -> Unit
            }
        }
    }

     */

    override fun resolveDisplay(indent: String): String {
        if (stepType == null) {
            return "${indent}${nodeName}"
        } else {
            return "${indent}${nodeName} ${stepType}"
        }
    }
}