package com.xmlcalabash.util

import com.xmlcalabash.api.XProcStep
import com.xmlcalabash.config.PipelineConfiguration
import com.xmlcalabash.exceptions.XProcError
import com.xmlcalabash.namespace.NsCx
import com.xmlcalabash.namespace.NsP
import com.xmlcalabash.runtime.XProcRuntime
import com.xmlcalabash.runtime.parameters.StepParameters
import com.xmlcalabash.spi.AtomicStepManager
import com.xmlcalabash.spi.AtomicStepProvider
import net.sf.saxon.s9api.QName

class StandardStepProvider: AtomicStepManager, AtomicStepProvider {
    val implMap = mapOf<QName, () -> XProcStep>()
    /*
    val implMap = mapOf(
        NsP.addAttribute        to { r: XProcRuntime, _: StepParameters? -> AddAttributeStep(r) },
        NsP.addXmlBase          to { r: XProcRuntime, _: StepParameters? -> AddXmlBaseStep(r) },
        NsP.archive             to { r: XProcRuntime, _: StepParameters? -> ArchiveStep(r) },
        NsP.archiveManifest     to { r: XProcRuntime, _: StepParameters? -> ArchiveManifestStep(r) },
        NsP.castContentType     to { r: XProcRuntime, _: StepParameters? -> CastContentTypeStep(r) },
        NsP.compare             to { r: XProcRuntime, _: StepParameters? -> CompareStep(r) },
        NsP.compress            to { r: XProcRuntime, _: StepParameters? -> CompressStep(r) },
        NsP.count               to { r: XProcRuntime, _: StepParameters? -> CountStep(r) },
        NsP.cssFormatter        to { r: XProcRuntime, _: StepParameters? -> CssFormatterStep(r) },
        NsP.delete              to { r: XProcRuntime, _: StepParameters? -> DeleteStep(r) },
        NsP.directoryList       to { r: XProcRuntime, _: StepParameters? -> DirectoryListStep(r) },
        NsP.error               to { r: XProcRuntime, _: StepParameters? -> ErrorStep(r) },
        NsP.fileCopy            to { r: XProcRuntime, _: StepParameters? -> FileCopyStep(r) },
        NsP.fileCreateTempfile  to { r: XProcRuntime, _: StepParameters? -> CreateTempfileStep(r) },
        NsP.fileDelete          to { r: XProcRuntime, _: StepParameters? -> FileDeleteStep(r) },
        NsP.fileInfo            to { r: XProcRuntime, _: StepParameters? -> FileInfoStep(r) },
        NsP.fileMkdir           to { r: XProcRuntime, _: StepParameters? -> FileMkdirStep(r) },
        NsP.fileMove            to { r: XProcRuntime, _: StepParameters? -> FileMoveStep(r) },
        NsP.fileTouch           to { r: XProcRuntime, _: StepParameters? -> FileTouchStep(r) },
        NsP.filter              to { r: XProcRuntime, _: StepParameters? -> FilterStep(r) },
        NsP.hash                to { r: XProcRuntime, _: StepParameters? -> HashStep(r) },
        NsP.httpRequest         to { r: XProcRuntime, _: StepParameters? -> HttpRequestStep(r) },
        NsP.identity            to { r: XProcRuntime, _: StepParameters? -> IdentityStep(r) },
        NsP.insert              to { r: XProcRuntime, _: StepParameters? -> InsertStep(r) },
        NsP.jsonJoin            to { r: XProcRuntime, _: StepParameters? -> JsonJoinStep(r) },
        NsP.jsonMerge           to { r: XProcRuntime, _: StepParameters? -> JsonMergeStep(r) },
        NsP.labelElements       to { r: XProcRuntime, _: StepParameters? -> LabelElementsStep(r) },
        NsP.load                to { r: XProcRuntime, _: StepParameters? -> LoadStep(r) },
        NsP.makeAbsoluteUris    to { r: XProcRuntime, _: StepParameters? -> MakeAbsoluteUrisStep(r) },
        NsP.markdownToHtml      to { r: XProcRuntime, _: StepParameters? -> MarkdownToHtml(r) },
        NsP.namespaceDelete     to { r: XProcRuntime, _: StepParameters? -> NamespaceDeleteStep(r) },
        NsP.namespaceRename     to { r: XProcRuntime, _: StepParameters? -> NamespaceRenameStep(r) },
        NsP.osExec              to { r: XProcRuntime, _: StepParameters? -> OsExec(r) },
        NsP.osInfo              to { r: XProcRuntime, _: StepParameters? -> OsInfo(r) },
        NsP.pack                to { r: XProcRuntime, _: StepParameters? -> PackStep(r) },
        NsP.rename              to { r: XProcRuntime, _: StepParameters? -> RenameStep(r) },
        NsP.replace             to { r: XProcRuntime, _: StepParameters? -> ReplaceStep(r) },
        NsP.setAttributes       to { r: XProcRuntime, _: StepParameters? -> SetAttributesStep(r) },
        NsP.setProperties       to { r: XProcRuntime, _: StepParameters? -> SetPropertiesStep(r) },
        NsP.sink                to { r: XProcRuntime, _: StepParameters? -> SinkStep(r) },
        NsP.sleep               to { r: XProcRuntime, _: StepParameters? -> SleepStep(r) },
        NsP.splitSequence       to { r: XProcRuntime, _: StepParameters? -> SplitSequenceStep(r) },
        NsP.store               to { r: XProcRuntime, _: StepParameters? -> StoreStep(r) },
        NsP.stringReplace       to { r: XProcRuntime, _: StepParameters? -> StringReplaceStep(r) },
        NsP.textCount           to { r: XProcRuntime, _: StepParameters? -> TextCountStep(r) },
        NsP.textHead            to { r: XProcRuntime, _: StepParameters? -> TextHeadStep(r) },
        NsP.textJoin            to { r: XProcRuntime, _: StepParameters? -> TextJoinStep(r) },
        NsP.textReplace         to { r: XProcRuntime, _: StepParameters? -> TextReplaceStep(r) },
        NsP.textSort            to { r: XProcRuntime, _: StepParameters? -> TextSortStep(r) },
        NsP.textTail            to { r: XProcRuntime, _: StepParameters? -> TextTailStep(r) },
        NsP.unarchive           to { r: XProcRuntime, _: StepParameters? -> UnarchiveStep(r) },
        NsP.uncompress          to { r: XProcRuntime, _: StepParameters? -> UncompressStep(r) },
        NsP.unwrap              to { r: XProcRuntime, _: StepParameters? -> UnwrapStep(r) },
        NsP.uuid                to { r: XProcRuntime, _: StepParameters? -> UuidStep(r) },
        NsP.wrap                to { r: XProcRuntime, _: StepParameters? -> WrapStep(r) },
        NsP.wrapSequence        to { r: XProcRuntime, _: StepParameters? -> WrapSequenceStep(r) },
        NsP.wwwFormUrldecode    to { r: XProcRuntime, _: StepParameters? -> WwwFormUrlDecodeStep(r) },
        NsP.wwwFormUrlencode    to { r: XProcRuntime, _: StepParameters? -> WwwFormUrlEncodeStep(r) },
        NsP.validateWithDTD         to { r: XProcRuntime, _: StepParameters? -> ValidateWithDTD(r) },
        NsP.validateWithNVDL        to { r: XProcRuntime, _: StepParameters? -> ValidateWithNVDL(r) },
        NsP.validateWithRelaxNG     to { r: XProcRuntime, _: StepParameters? -> ValidateWithRelaxNG(r) },
        NsP.validateWithSchematron  to { r: XProcRuntime, _: StepParameters? -> ValidateWithSchematron(r) },
        NsP.validateWithXmlSchema   to { r: XProcRuntime, _: StepParameters? -> ValidateWithXmlSchema(r) },
        NsP.validateWithJsonSchema  to { r: XProcRuntime, _: StepParameters? -> ValidateWithJsonSchema(r) },
        NsP.xinclude            to { r: XProcRuntime, _: StepParameters? -> XIncludeStep(r) },
        NsP.xquery              to { r: XProcRuntime, _: StepParameters? -> XQueryStep(r) },
        NsP.xslFormatter        to { r: XProcRuntime, _: StepParameters? -> XslFormatterStep(r) },
        NsP.xslt                to { r: XProcRuntime, _: StepParameters? -> XsltStep(r) },

        NsCx.cacheAddDocument   to { r: XProcRuntime, p: StepParameters? -> CacheDocument(r) },
        NsCx.cacheRemoveDocument to { r: XProcRuntime, p: StepParameters? -> UncacheDocument(r) },
        NsCx.guard              to { r: XProcRuntime, p: StepParameters? -> GuardStep(r,p as GuardStepParameters) },
        NsCx.expression         to { r: XProcRuntime, p: StepParameters? -> ExpressionStep(r,p as ExpressionStepParameters) },
        NsCx.inline             to { r: XProcRuntime, p: StepParameters? -> InlineStep(r,p as InlineStepParameters) },
        NsCx.document           to { r: XProcRuntime, p: StepParameters? -> DocumentStep(r,p as DocumentStepParameters) },
        NsCx.empty              to { r: XProcRuntime, p: StepParameters? -> EmptyStep(r,p as EmptyStepParameters) },
        NsCx.inputFilter        to { r: XProcRuntime, p: StepParameters? -> InputFilterStep(r,p as InputFilterStepParameters) },
        NsCx.joiner             to { r: XProcRuntime, _: StepParameters? -> JoinerStep(r) },
        NsCx.splitter           to { r: XProcRuntime, _: StepParameters? -> SplitterStep(r) },
        NsCx.select             to { r: XProcRuntime, p: StepParameters? -> SelectStep(r,p as SelectStepParameters ) },
        NsCx.head               to { r: XProcRuntime, _: StepParameters? -> NullStep(r) },
        NsCx.foot               to { r: XProcRuntime, _: StepParameters? -> NullStep(r) },
        NsCx.contentTypeCheck   to { r: XProcRuntime, p: StepParameters? -> ContentTypeCheckStep(r,p as ContentTypeCheckStepParameters) },
        NsCx.unimplemented      to { r: XProcRuntime, p: StepParameters? -> UnimplementedStep(r, p as UnimplementedStepParameters) }
    )
     */

    override fun create(config: PipelineConfiguration): AtomicStepManager {
        return this
    }

    override fun stepTypes(): Set<QName> {
        return implMap.keys
    }

    override fun stepAvailable(stepType: QName): Boolean {
        return implMap[stepType] != null
    }

    override fun createStep(runtime: XProcRuntime, params: StepParameters): () -> XProcStep {
        val constructor = implMap[params.stepType]
            ?: throw XProcError.xiNotImplemented("createStep for ${params.stepType}").exception()
        TODO("unimplemented")
        //return { -> constructor(runtime, params) }
    }
}