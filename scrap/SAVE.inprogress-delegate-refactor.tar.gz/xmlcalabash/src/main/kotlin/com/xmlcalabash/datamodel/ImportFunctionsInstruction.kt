package com.xmlcalabash.datamodel

import com.xmlcalabash.namespace.NsP
import com.xmlcalabash.xprocparser.StepConfiguration
import net.sf.saxon.om.NamespaceUri
import java.net.URI

class ImportFunctionsInstruction(parent: XProcInstruction, val inputHref: URI): XProcInstruction(parent, parent.stepConfig.newInstance(false), NsP.importFunctions) {
    val href: URI
        get() {
            if (stepConfig.baseUri == null) {
                return inputHref
            }
            return stepConfig.baseUri!!.resolve(inputHref)
        }

    var contentType: MediaType? = null
        set(value) {
            checkOpen()
            field = value
        }

    var namespace: NamespaceUri? = null
        set(value) {
            checkOpen()
            field = value
        }

    override fun staticAnalysis(context: InstructionStaticContext) {
        // nop
    }

    fun loadFunctions(stepConfig: StepConfiguration) {
        TODO("unimplemented")
    }
}