package com.xmlcalabash.spi

import com.xmlcalabash.documents.XProcDocument
import com.xmlcalabash.io.DocumentManager
import com.xmlcalabash.xprocparser.StepConfiguration
import java.net.URI

interface DocumentResolver {
    fun configure(manager: DocumentManager)
    fun resolve(context: StepConfiguration, uri: URI, current: XProcDocument?): XProcDocument?
}