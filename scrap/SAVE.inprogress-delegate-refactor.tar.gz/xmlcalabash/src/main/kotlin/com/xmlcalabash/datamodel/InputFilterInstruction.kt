package com.xmlcalabash.datamodel

import com.xmlcalabash.namespace.NsCx

class InputFilterInstruction(parent: XProcInstruction, val port: String, name: String?): AtomicStepInstruction(parent, NsCx.inputFilter, name) {
}