package com.xmlcalabash.datamodel

import com.xmlcalabash.exceptions.XProcError
import com.xmlcalabash.xprocparser.StepConfiguration
import net.sf.saxon.s9api.QName

abstract class XProcInstruction internal constructor(initialParent: XProcInstruction?, val stepConfig: StepConfiguration, val instructionType: QName) {
    internal var _parent = initialParent
    val parent: XProcInstruction?
        get() = _parent

    val id = stepConfig.pipelineConfig.nextId
    var expandText: Boolean? = null

    internal val _children = mutableListOf<XProcInstruction>()
    val children: List<XProcInstruction>
        get() = _children

    protected val _extensionAttributes = mutableMapOf<QName, String>()
    var extensionAttributes: Map<QName, String>
        get() = _extensionAttributes
        set(value) {
            checkOpen()
            _extensionAttributes.clear()
            _extensionAttributes.putAll(value)
        }
    fun setExtensionAttribute(name: QName, value: String) {
        _extensionAttributes[name] = value
    }

    internal var open = true
    protected fun checkOpen() {
        if (!open) {
            throw IllegalArgumentException("${instructionType} cannot be changed")
        }
    }

    val errors: List<XProcError>
        get() = stepConfig.errors
    val hasErrors: Boolean
        get() {
            return stepConfig.hasErrors
        }
    fun reportError(error: XProcError) {
        stepConfig.reportError(error)
    }

    internal open fun elaborate() {
        for (child in children) {
            child.elaborate()
        }
    }

    internal open fun staticAnalysis(context: InstructionStaticContext) {
        throw RuntimeException("${instructionType} must override staticAnalysis")
    }

    internal open fun rewrite() {
        for (child in children) {
            child.rewrite()
        }
    }

    internal fun hasAncestor(instruction: XProcInstruction): Boolean {
        var p: XProcInstruction? = this
        while (p != null) {
            if (p === instruction) {
                return true
            }
            p = p.parent
        }
        return false
    }

    open fun dump(depth: Int) {
        print("".padEnd(depth, ' '))
        println(this)
        for (child in children) {
            child.dump(depth + 2)
        }
    }

    override fun toString(): String {
        return "${instructionType}/${id}"
    }
}