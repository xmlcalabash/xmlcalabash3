package com.xmlcalabash.datamodel

import com.xmlcalabash.namespace.NsP

class WithOutputInstruction(parent: XProcInstruction): PortBindingContainer(parent, NsP.withOutput) {
    constructor(parent: XProcInstruction, port: String, primary: Boolean?, sequence: Boolean?) : this(parent) {
        this.port = port
        this.primary = primary
        this.sequence = sequence
    }
}