package com.xmlcalabash.datamodel

import com.xmlcalabash.xprocparser.StepConfiguration
import net.sf.saxon.s9api.QName
import net.sf.saxon.s9api.XdmValue

abstract class XProcStepInstruction(parent: XProcInstruction?, stepConfig: StepConfiguration, instructionType: QName, stepName: String?): NamedInstruction(parent, stepConfig, instructionType, stepName) {
    internal val _staticOptions = mutableMapOf<QName, XdmValue>()
    val staticOptions: Map<QName, XdmValue>
        get() = _staticOptions

    override fun staticAnalysis(context: InstructionStaticContext) {
        // nop; the buck stops here
    }

    override fun rewrite() {
        for (input in inputs()) {
            for (binding in input.children) {
                (binding as ConnectionInstruction).promoteToStep(this)
            }
        }

        super.rewrite()
    }

    override fun toString(): String {
        return "${instructionType} ${name}"
    }
}