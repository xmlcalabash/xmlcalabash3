package com.xmlcalabash.datamodel

import com.xmlcalabash.exceptions.XProcError
import com.xmlcalabash.namespace.NsP
import com.xmlcalabash.xprocparser.StepConfiguration
import net.sf.saxon.om.NamespaceUri
import net.sf.saxon.s9api.QName
import net.sf.saxon.s9api.XdmValue

open class LibraryInstruction(stepConfig: StepConfiguration, private val containerImpl: StepContainerImpl): XProcInstruction(null, stepConfig, NsP.library), StepContainerInterface by containerImpl {
    var psviRequired: Boolean? = null
        set(value) {
            checkOpen()
            field = value
        }

    var xpathVersion: Double? = null
        set(value) {
            checkOpen()
            field = value
        }

    private val _excludeInlineNamespaces = mutableSetOf<NamespaceUri>()
    var excludeInlineNamespaces: Set<NamespaceUri>
        get() = _excludeInlineNamespaces
        set(value) {
            checkOpen()
            _excludeInlineNamespaces.clear()
            _excludeInlineNamespaces.addAll(value)
        }

    var version: Double? = null
        set(value) {
            checkOpen()
            field = value
        }

    override fun staticAnalysis(context: InstructionStaticContext) {
        super.staticAnalysis(context)

        /*
        for (child in children.filterIsInstance<DeclareStepInstruction>()) {
            if (child.type != null) {
                // If it's already present, then we must have self-imported it.
                if (!context.inscopeStepTypes.contains(child.type)) {
                    context.addInscopeStepType(child)
                }
            }
        }
         */

        for (child in children) {
            when (child) {
                is ImportFunctionsInstruction -> TODO("unimplemented")
                is OptionInstruction -> {
                    child.staticAnalysis(context.copy())
                    context.addInscopeVariable(child)
                }
                is DeclareStepInstruction -> {
                    child.staticAnalysis(context.copy())
                }
                else -> TODO("unexpected")
            }
        }
    }

    override fun rewrite() {
        for (child in children.filterIsInstance<DeclareStepInstruction>()) {
            child.rewrite()
        }
    }

    fun option(name: QName): OptionInstruction {
        val option = OptionInstruction(this, name)
        addIOType(option)
        return option
    }

    fun option(name: QName, staticValue: XdmValue): OptionInstruction {
        val option = OptionInstruction(this, name)
        option.select = XProcExpression.constant(stepConfig, staticValue)
        option.static = true
        addIOType(option)
        return option
    }

    fun addIOType(instruction: XProcInstruction) {
        if (instruction is OptionInstruction) {
            if (!instruction.static) {
                instruction.reportError(XProcError.xsInvalidElement(instruction.instructionType))
            }
        }

        val last = children.lastOrNull()
        if (last == null || last is ImportFunctionsInstruction) {
            _children.add(instruction)
            return
        }

        instruction.reportError(XProcError.xsInvalidElement(instruction.instructionType))
    }

    // ============================================================

    internal fun validate() {
        if (this !is StandardLibraryInstruction) {
            dump(0)
        }

        // Work out what step types are visible where. Note that we don't have to take special
        // care to avoid "duplicate" imports because those will be the same declare step
        // instruction objects.
        resolveImportsAndExports()

        elaborate()
        if (!stepConfig.hasErrors) {
            staticAnalysis(InstructionStaticContext(stepConfig))
        }
        if (!stepConfig.hasErrors) {
            rewrite()
        }
        println("now what?")
        if (this !is StandardLibraryInstruction) {
            dump(0)
        }
    }

    override fun directlyExported(visited: MutableSet<StepContainerInterface>) {
        if (visited.contains(this)) {
            return
        }

        //println("Computing directly exported for ${this}")
        visited.add(this)

        containerImpl.exports.clear()
        for (child in children.filterIsInstance<DeclareStepInstruction>()) {
            child.directlyExported(visited)
            if (child.type != null && child.visibility != Visibility.PRIVATE) {
                containerImpl.exports[child.type!!] = child
            }
        }

        for (container in containerImpl.imported) {
            container.directlyExported(visited)
        }
    }

    override fun visibleInside(visited: MutableSet<StepContainerInterface>) {
        if (visited.contains(this)) {
            return
        }
        visited.add(this)

        //println("Computed visible inside for ${this}")

        stepConfig.inscopeStepTypes = mapOf()

        for (child in children.filterIsInstance<DeclareStepInstruction>().filter { it.type != null }) {
            stepConfig.addVisibleStep(child.type!!, child)
        }

        for (child in containerImpl.imported) {
            traverse(stepConfig, setOf(), child)
        }

        for (child in children.filterIsInstance<DeclareStepInstruction>()) {
            child.stepConfig.inscopeStepTypes = stepConfig.inscopeStepTypes
            child.visibleInside(visited)
        }

        for (child  in containerImpl.imported) {
            child.visibleInside(visited)
        }
    }

    // ============================================================

    /*
    fun addImportFunctions(import: ImportFunctionsInstruction) {
        if (children.filterIsInstance<OptionStaticInstruction>().isNotEmpty()
            || children.filterIsInstance<DeclareStepInstruction>().isNotEmpty()) {
            import.reportError(XProcError.xsInvalidElement(import.instructionType))
            return
        }
        _children.add(import)
    }

    fun addOption(option: OptionStaticInstruction) {
        if (children.filterIsInstance<DeclareStepInstruction>().isNotEmpty()) {
            option.reportError(XProcError.xsInvalidElement(option.instructionType))
            return
        }
        _children.add(option)
    }
    */

    fun addDeclareStep(decl: DeclareStepInstruction) {
        _children.add(decl)
    }

    override fun toString(): String {
        return "${instructionType}/${id}: ${stepConfig.baseUri}"
    }
}