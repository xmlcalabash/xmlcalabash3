package com.xmlcalabash.datamodel

import com.xmlcalabash.datamodel.XProcExpression.Companion.select
import com.xmlcalabash.exceptions.XProcError
import com.xmlcalabash.util.XProcCollectionFinder
import com.xmlcalabash.xprocparser.StepConfiguration
import net.sf.saxon.s9api.SaxonApiException
import net.sf.saxon.s9api.SequenceType
import net.sf.saxon.s9api.XdmAtomicValue
import net.sf.saxon.s9api.XdmValue

class XProcSelectExpression private constructor(stepConfig: StepConfiguration, val select: String, asType: SequenceType, values: List<XdmAtomicValue>): XProcExpression(stepConfig, asType, values) {
    companion object {
        fun newInstance(stepConfig: StepConfiguration, select: String, asType: SequenceType = SequenceType.ANY, values: List<XdmAtomicValue> = emptyList()): XProcSelectExpression {
            return XProcSelectExpression(stepConfig, select, asType, values)
        }
    }

    override fun cast(asType: SequenceType, values: List<XdmAtomicValue>): XProcExpression {
        return select(stepConfig, select, asType, values)
    }

    override fun evaluate(): XdmValue {
        val compiler = stepConfig.processor.newXPathCompiler()
        if (stepConfig.processor.isSchemaAware) {
            compiler.isSchemaAware = true
        }

        var collectionFinder: XProcCollectionFinder? = null
        compiler.baseURI = stepConfig.baseUri

        for ((prefix, uri) in stepConfig.inscopeNamespaces) {
            compiler.declareNamespace(prefix, uri.toString())
        }
        for (name in variableRefs) {
            compiler.declareVariable(name)
        }
        val selector = try {
            compiler.compile(select).load()
        } catch (ex: SaxonApiException) {
            // This is a bit of a hack; the problem appears in a test case for p:set-attributes but
            // I suppose it's possible that it could occur elsewhere...still, hopefully the message
            // is clear enough.
            if (ex.message != null && ex.message!!.contains("cannot be used as a namespace URI")) {
                throw XProcError.xcCannotSetNamespaces().exception()
            }
            throw ex
        }

        collectionFinder = XProcCollectionFinder(defaultCollection, selector.underlyingXPathContext.collectionFinder)
        selector.underlyingXPathContext.collectionFinder = collectionFinder
        //selector.resourceResolver = stepConfig.pipelineConfig.documentManager

        setupExecutionContext(selector)

        val result = try {
            selector.evaluate()
        } catch (ex: Throwable) {
            selector.underlyingXPathContext.collectionFinder = collectionFinder.chain
            throw ex
        }

        selector.underlyingXPathContext.collectionFinder = collectionFinder.chain

        teardownExecutionContext()

        if (asType !== SequenceType.ANY || values.isNotEmpty()) {
            return stepConfig.checkType(null, result, asType, values)
        }

        return result
    }
}