package com.xmlcalabash.datamodel

import com.xmlcalabash.documents.XProcDocument
import com.xmlcalabash.exceptions.XProcError
import com.xmlcalabash.namespace.NsFn
import com.xmlcalabash.namespace.NsP
import com.xmlcalabash.namespace.NsP.variable
import com.xmlcalabash.parsers.XPathExpressionDetails
import com.xmlcalabash.parsers.XPathExpressionParser
import com.xmlcalabash.runtime.XProcExecutionContext
import com.xmlcalabash.util.ValueTemplate
import com.xmlcalabash.util.ValueTemplateParser
import com.xmlcalabash.xprocparser.StepConfiguration
import net.sf.saxon.s9api.*

abstract class XProcExpression(val stepConfig: StepConfiguration, val asType: SequenceType, val values: List<XdmAtomicValue>) {
    companion object {
        // FIXME: what's the right list here?
        val contextDependentFunctions = setOf(
            NsP.systemProperty, NsP.iterationPosition, NsP.iterationSize, NsP.documentProperties,
            NsP.documentPropertiesDocument, NsP.documentProperty,
            NsFn.currentDate, NsFn.currentDateTime, NsFn.currentTime,
            NsFn.baseUri, NsFn.doc, NsFn.docAvailable, NsFn.document, NsFn.unparsedText,
            NsFn.unparsedTextAvailable)

        fun select(stepConfig: StepConfiguration, select: String, asType: SequenceType = SequenceType.ANY, values: List<XdmAtomicValue> = emptyList()): XProcSelectExpression {
            val expr = XProcSelectExpression.newInstance(stepConfig, select, asType, values)
            expr._details = XPathExpressionParser(stepConfig).parse(select)
            return expr
        }

        fun avt(stepConfig: StepConfiguration, avt: String, asType: SequenceType = SequenceType.ANY, values: List<XdmAtomicValue> = emptyList()): XProcAvtExpression {
            return avt(stepConfig, ValueTemplateParser.parse(avt), asType, values)
        }

        fun avt(stepConfig: StepConfiguration, avt: ValueTemplate, asType: SequenceType = SequenceType.ANY, values: List<XdmAtomicValue> = emptyList()): XProcAvtExpression {
            val expr = XProcAvtExpression.newInstance(stepConfig, avt, asType, values)

            val parser = XPathExpressionParser(stepConfig)
            var errors = false
            var context = false
            val variables = mutableSetOf<QName>()
            val functions = mutableSetOf<QName>()
            for (avtExpr in avt.expressions()) {
                val details = parser.parse(avtExpr)
                errors = errors || details.errors
                context = context || details.contextRef
                variables.addAll(details.variableRefs)
                functions.addAll(details.functionRefs)
            }

            expr._details = XPathExpressionDetails(errors, variables, functions, context)
            return expr
        }

        fun constant(stepConfig: StepConfiguration, value: XdmValue, asType: SequenceType = SequenceType.ANY, values: List<XdmAtomicValue> = emptyList()): XProcConstantExpression {
            val expr = XProcConstantExpression.newInstance(stepConfig, value, asType, values)
            expr._details = XPathExpressionDetails(errors = false, variableRefs = emptySet(), functionRefs = emptySet(), contextRef = false)
            return expr
        }

        fun error(stepConfig: StepConfiguration): XProcErrorExpression {
            return XProcErrorExpression.newInstance(stepConfig)
        }
    }

    private var constructedExecutionContext = false

    protected lateinit var _details: XPathExpressionDetails
    val details: XPathExpressionDetails
        get() = _details

    protected val staticVariableBindings = mutableMapOf<QName, Any>()
    protected val variableBindings = mutableMapOf<QName, Any>()

    private var _contextItem: Any? = null
    var contextItem: Any?
        get() = _contextItem
        set(value) {
            if (value == null || value is XdmValue || value is XProcDocument) {
                _contextItem = value
            } else {
                stepConfig.reportError(XProcError.xiImpossible("Context item must be a value or a document"))
                _contextItem = null
            }
        }

    private var _defaultCollection = mutableListOf<XProcDocument>()
    val defaultCollection: List<XProcDocument>
        get() = _defaultCollection

    val variableRefs: Set<QName>
        get() = details.variableRefs

    val functionRefs: Set<QName>
        get() = details.functionRefs

    val contextRef: Boolean
        get() = details.contextRef

    fun canBeResolvedStatically(): Boolean {
        if (details.errors || details.contextRef) {
            return false
        }

        for (name in details.functionRefs) {
            if (contextDependentFunctions.contains(name)) {
                return false
            }
        }

        for (name in details.variableRefs) {
            if (!staticVariableBindings.contains(name)) {
                return false
            }
        }

        return true
    }

    protected var checkedStatic = false
    internal var _staticValue: XdmValue? = null
    val staticValue: XdmValue?
        get() = _staticValue

    abstract fun evaluate(): XdmValue
    abstract fun cast(asType: SequenceType, values: List<XdmAtomicValue> = emptyList()): XProcExpression

    open internal fun computeStaticValue(context: InstructionStaticContext): XdmValue? {
        if (checkedStatic) {
            return staticValue
        }
        checkedStatic = true

        for (name in variableRefs) {
            val variable = context.inscopeVariables[name]
            if (variable == null) {
                stepConfig.reportError(XProcError.xsXPathStaticError(name))
            } else {
                if (variable.staticValue != null) {
                    setStaticBinding(name, variable.staticValue!!)
                }
            }
        }

        // The expression can be resolved statically if it doesn't refer to a collection,
        // doesn't have any bindings, and can be resolved statically.
        if (canBeResolvedStatically()) {
            try {
                _staticValue = stepConfig.checkType(null, evaluate(), asType, emptyList())
            } catch (ex: SaxonApiException) {
                stepConfig.reportError(XProcError.xsXPathStaticError(ex.message!!))
            }
        }

        return staticValue
    }

    internal fun promoteToStep(step: XProcInstruction, context: InstructionStaticContext): List<AtomicStepInstruction> {
        val newSteps = mutableListOf<AtomicStepInstruction>()

        val exprStep = AtomicExpressionStepInstruction(step, this)
        for (name in variableRefs) {
            val variable = context.inscopeVariables[name]!!
            if (variable.staticValue != null) {
                exprStep._staticOptions[name] = variable.staticValue!!
            } else {
                val wi = exprStep.withInput()
                wi.port = "Q{${name.namespaceUri}}${name.localName}"
                wi.sequence = true
                val pipe = wi.pipe()
                pipe.setReadablePort(variable.primaryOutput())
            }
        }

        if (contextRef) {
            val wi = exprStep.withInput()
            wi.port = "source"
            val pipe = wi.pipe()
            pipe.setReadablePort(context.drp!!)
        } else {
            val emptyStep = AtomicEmptyStepInstruction(step)
            emptyStep.elaborate()
            emptyStep.staticAnalysis(context.copy())
            context.addInscopeStepName(emptyStep)

            val wi = exprStep.withInput()
            wi.port = "source"
            val pipe = wi.pipe()
            pipe.setReadablePort(emptyStep.primaryOutput()!!)
            newSteps.add(emptyStep)
        }

        exprStep.elaborate()
        exprStep.staticAnalysis(context.copy())

        newSteps.add(exprStep)
        return newSteps
    }

    fun reset() {
        variableBindings.clear()
        contextItem = null
        _defaultCollection.clear()
    }

    fun defaultCollection(items: List<XProcDocument>) {
        _defaultCollection.clear()
        _defaultCollection.addAll(items)
    }

    fun setBinding(name: QName, value: XdmValue) {
        if (variableRefs.contains(name)) {
            variableBindings[name] = value
        }
    }
    fun setBinding(name: QName, value: XProcDocument) {
        if (variableRefs.contains(name)) {
            variableBindings[name] = value
        }
    }

    fun setStaticBinding(name: QName, value: XdmValue) {
        if (variableRefs.contains(name)) {
            staticVariableBindings[name] = value
        }
    }
    fun setStaticBinding(name: QName, value: XProcDocument) {
        if (variableRefs.contains(name)) {
            staticVariableBindings[name] = value
        }
    }

    protected fun setupExecutionContext(selector: XPathSelector) {
        constructedExecutionContext = false

        // If this is being called during compilation, there won't be a thread-local one yet
        var execContext = stepConfig.saxonConfig.getExecutionContext()
        if (execContext == null) {
            execContext = XProcExecutionContext(stepConfig)
            stepConfig.setExecutionContext(execContext)
            constructedExecutionContext = true
        }

        for (name in variableRefs) {
            val value = variableBindings[name] ?: staticVariableBindings[name]
            when (value) {
                null -> Unit // bad is going to happen
                is XdmValue -> selector.setVariable(name, value)
                is XProcDocument -> {
                    selector.setVariable(name, value.value)
                    stepConfig.addProperties(value)
                }
                else -> Unit // this can't happen, but bad is going to happen if it does
            }
        }

        when (contextItem) {
            null -> Unit
            is XdmItem -> {
                selector.contextItem = contextItem as XdmItem
            }
            is XProcDocument -> {
                val doc = contextItem as XProcDocument
                val value = doc.value

                if (value is XdmItem) {
                    selector.contextItem = value
                }
                stepConfig.addProperties(doc)
            }
        }
    }

    protected fun teardownExecutionContext() {
        if (contextItem is XProcDocument && (contextItem as XProcDocument).value is XdmItem) {
            stepConfig.removeProperties((contextItem as XProcDocument))
        }

        for ((_, doc) in variableBindings) {
            if (doc is XProcDocument) {
                stepConfig.removeProperties(doc)
            }
        }

        if (constructedExecutionContext) {
            stepConfig.releaseExecutionContext()
            constructedExecutionContext = false
        }
    }
}