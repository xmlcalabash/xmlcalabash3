package com.xmlcalabash.runtime.parameters

import net.sf.saxon.s9api.QName

open class StepParameters(val stepType: QName) {
}