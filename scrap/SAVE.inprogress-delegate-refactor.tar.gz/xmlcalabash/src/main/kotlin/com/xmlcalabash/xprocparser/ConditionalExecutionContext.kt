package com.xmlcalabash.xprocparser

import com.xmlcalabash.runtime.XProcExecutionContext
import net.sf.saxon.s9api.QName

class ConditionalExecutionContext(stepConfig: StepConfiguration, val inscopeStepTypes: Map<QName,Boolean>): XProcExecutionContext(stepConfig) {
    override fun stepAvailable(name: QName): Boolean {
        if (inscopeStepTypes.containsKey(name)) {
            if (inscopeStepTypes[name]!!) {
                return true
            } else {
                throw ConditionalStepException("${name}")
            }
        }
        return false
    }
}