package com.xmlcalabash.graph

import com.xmlcalabash.datamodel.AtomicStepInstruction
import com.xmlcalabash.datamodel.MediaType
import com.xmlcalabash.datamodel.XProcInstruction
import com.xmlcalabash.namespace.NsCx

class ContentTypeCheck(parent: XProcInstruction, name: String?, val accept: List<MediaType>, val outputCheck: Boolean): AtomicStepInstruction(parent, NsCx.contentTypeCheck, name) {
}