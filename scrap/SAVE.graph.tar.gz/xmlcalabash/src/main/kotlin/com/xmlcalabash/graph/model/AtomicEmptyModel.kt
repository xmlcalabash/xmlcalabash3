package com.xmlcalabash.graph.model

import com.xmlcalabash.datamodel.AtomicStepInstruction

class AtomicEmptyModel(builder: AtomicStepInstruction, parent: Model, val signalDefault: Boolean): AtomicModel(builder, parent) {

}