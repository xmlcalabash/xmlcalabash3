package com.xmlcalabash.graph

import com.xmlcalabash.graph.model.Model
import com.xmlcalabash.graph.model.SubpipelineModel

class NodeId(model: Model) {
    val id: String

    companion object {
        private var nextId = 1
    }

    init {
        synchronized(Companion) {
            if (model is SubpipelineModel) {
                id = "M${model.parent!!.modelId}s"
            } else {
                id = "M${model.modelId}"
            }
        }
    }

    override fun toString() = id
}