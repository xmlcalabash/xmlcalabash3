package com.xmlcalabash.graph.model

import com.xmlcalabash.datamodel.XProcInstruction
import com.xmlcalabash.datamodel.XProcStepInstruction
import com.xmlcalabash.documents.XProcDocument
import net.sf.saxon.s9api.QName
import java.io.PrintStream

abstract class AbstractAtomicModel(builder: XProcInstruction, parent: Model): Model(builder, parent) {
    val options = mutableMapOf<QName, OptionModel>()
    val bindings = mutableMapOf<QName, XProcDocument>()

    override fun describe(out: PrintStream, depth: Int) {
        val DEPTH = 3

        out.println()
        out.print("${"".padStart(depth*DEPTH)}<atomic id='M${modelId}'")

        when (builder) {
            is XProcStepInstruction -> out.print(" name='${builder.name}' type='${builder.instructionType}'")
            else -> out.print(" ERROR='${builder}'")
        }

        when (this) {
            is HeadModel -> out.print(" head='true'")
            is FootModel -> out.print(" foot='true'")
        }

        out.println(">")
        for (input in inputs) {
            out.println("${"".padStart((depth+1)*DEPTH)}<input id='P${input.portId}' name='${input.name}'/>")
        }
        for (output in outputs) {
            out.println("${"".padStart((depth+1)*DEPTH)}<output id='P${output.portId}' name='${output.name}'/>")
        }
        out.println("${"".padStart(depth*DEPTH)}</atomic>")
    }

}