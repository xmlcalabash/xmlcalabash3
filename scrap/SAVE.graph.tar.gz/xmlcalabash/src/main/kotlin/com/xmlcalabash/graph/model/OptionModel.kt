package com.xmlcalabash.graph.model

import com.xmlcalabash.documents.XProcDocument
import net.sf.saxon.s9api.QName

class OptionModel(val name: QName, val value: XProcDocument, val defaulted: Boolean, val static: Boolean  = false) {
}