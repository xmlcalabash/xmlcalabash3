package com.xmlcalabash.graph.model

import com.xmlcalabash.datamodel.EmptyBindingBuilder
import com.xmlcalabash.datamodel.RunBuilder
import com.xmlcalabash.documents.XProcDocument

class RunModel(builder: RunBuilder, parent: Model): AbstractAtomicModel(builder, parent)  {
    val useDefaultInputs: Set<String> = builder.useDefaultInputs

    override fun build() {
        val runBuilder = builder as RunBuilder

        for ((name, value) in runBuilder.inScopeStatics) {
            bindings[name] = XProcDocument(value, context)
        }

        val inputList = mutableListOf(runBuilder.withInput)
        inputList.addAll(runBuilder.runInputs)
        for (input in inputList) {
            var empty = true
            for (gchild in input.children) {
                empty = empty && gchild is EmptyBindingBuilder
            }
            if (!empty) {
                addInput(input)
            }
        }

        for (output in runBuilder.outputs) {
            addOutput(output)
        }

        for (option in runBuilder.runOptions) {
            if (option.staticValue == null) {
                addInput("Q{${option.name!!.namespaceUri}}${option.name!!.localName}", false, false, listOf(), false)
            } else {
                val doc = XProcDocument(option.staticValue!!, option.context)
                options.put(option.name!!, OptionModel(option.name!!, doc, option.defaulted, option.static == true))
            }
        }
    }

}