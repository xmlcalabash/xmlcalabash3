package com.xmlcalabash.graph

import com.xmlcalabash.datamodel.AtomicStepInstruction
import com.xmlcalabash.datamodel.CompoundContainer
import com.xmlcalabash.namespace.NsCx

class Joiner(builder: CompoundContainer, name: String?): AtomicStepInstruction(builder, NsCx.joiner, name) {
}