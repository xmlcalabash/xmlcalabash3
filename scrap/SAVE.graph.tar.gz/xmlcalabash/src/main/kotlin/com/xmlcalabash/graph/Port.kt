package com.xmlcalabash.graph

class Port(val node: Node, val port: String) {
    override fun toString(): String {
        return "${node}/${port}"
    }
}