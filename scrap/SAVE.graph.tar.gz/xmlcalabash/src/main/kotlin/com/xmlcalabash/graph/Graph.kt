package com.xmlcalabash.graph

import com.xmlcalabash.datamodel.*
import com.xmlcalabash.documents.XProcDocument
import com.xmlcalabash.graph.model.*
import com.xmlcalabash.namespace.NsCx
import com.xmlcalabash.namespace.NsP
import com.xmlcalabash.runtime.api.PortFlangeInfo
import net.sf.saxon.s9api.QName

class Graph() {
    companion object {
        fun compile(pipeline: DeclareStepInstruction): Graph {
            //pipeline.describe().text()
            val model = PipelineModel(pipeline)
            model.build()
            val builder = Graph()
            builder.makeGraph(model)
            return builder
        }
    }

    val nodes = mutableListOf<Node>()
    val edges = mutableListOf<Edge>()
    private var _pipeline: CompoundNode? = null
    val pipeline: CompoundNode
        get() = _pipeline ?: throw RuntimeException("Configuration exception: pipeline is null")

    private fun makeGraph(model: PipelineModel) {
        val nodeMap = mutableMapOf<Model,Node>()
        _pipeline = makeNodes(model, nodeMap) as CompoundNode
        nodes.addAll(nodeMap.values)

        for (conn in model.connections) {
            val from = Port(nodeMap[conn.from.parent]!!, conn.from.name)
            val to = Port(nodeMap[conn.to.parent]!!, conn.to.name)
            edges.add(Edge(from, to))
        }
    }

    private fun makeNodes(model: Model, nodeMap: MutableMap<Model,Node>): Node {
        val inputs = mutableMapOf<String, PortFlangeInfo>()
        for (port in model.inputs) {
            inputs.put(port.name, PortFlangeInfo(port))
        }

        val outputs = mutableMapOf<String, PortFlangeInfo>()
        for (port in model.outputs) {
            val info = PortFlangeInfo(port)
            if (model.builder.instructionType == NsP.forEach) {
                info.sequence = true
            }
            outputs.put(port.name, info)
        }

        when (model) {
            is CompoundModel -> {
                val headOutputs = mutableMapOf<String, PortFlangeInfo>()
                for (input in model.inputs) {
                    headOutputs.put(input.name, PortFlangeInfo(input))
                }

                val footInputs = mutableMapOf<String, PortFlangeInfo>()
                for (output in model.outputs) {
                    footInputs.put(output.name, PortFlangeInfo(output))
                }

                val headOptions = mutableListOf<OptionInstruction>()
                val head = Head(NodeParameters(NsCx.head, model.head, mapOf(), headOutputs), headOptions)

                val foot = Foot(NodeParameters(NsCx.foot, model.foot, footInputs, mapOf()))

                val children = mutableListOf<Node>()
                for (child in model.children) {
                    children.add(makeNodes(child, nodeMap))
                }
                val node = CompoundNode(NodeParameters(model.stepType, model, inputs, outputs), head, foot, children)
                nodeMap.put(model.head, head)
                nodeMap.put(model.foot, foot)
                nodeMap.put(model, node)
                return node
            }

            is AtomicModel -> {
                val type = (model.builder as XProcStepInstruction).instructionType
                val params = NodeParameters(type, model, inputs, outputs)
                params.options = model.options
                params.bindings = model.bindings
                val node = AtomicNode(params, model.useDefaultInputs)
                nodeMap.put(model, node)
                return node
            }

            is FilterModel -> {
                val params = NodeParameters(model.type, model, inputs, outputs)
                params.options = model.options
                params.bindings = model.bindings
                val node = AtomicNode(params)
                nodeMap.put(model, node)
                return node
            }

            is SubpipelineModel -> {
                val impl = makeNodes(model.parent!!, nodeMap)

                // Are there any static options to pass through?
                val options = mutableMapOf<QName, OptionModel>()
                for (child in model.builder.children.filterIsInstance<WithOptionInstruction>()) {
                    options[child.name] = OptionModel(child.name, XProcDocument(child.staticValue!!, child.stepConfig), child.staticValue != null)
                }

                val params = NodeParameters(NsCx.subpipeline, model, inputs, outputs)
                params.options = options
                val node = SubpipelineNode(params, impl as CompoundNode)

                // FIXME can this be made more configurable?
                val step = model.builder
                if (step is CompoundContainer) {
                    when (step.instructionType) {
                        NsP.forEach -> node.weldInput("current")
                        NsP.viewport -> node.weldInput("current")
                        else -> Unit
                    }
                }

                nodeMap.put(model, node)
                return node
            }

            is RunModel -> {
                val params = NodeParameters(NsP.run, model, inputs, outputs)
                params.options = model.options
                params.bindings = model.bindings
                val node = RunNode(params, model.useDefaultInputs)
                nodeMap.put(model, node)
                return node
            }

            else -> throw RuntimeException("Configuration error: unexpected model: ${model}")
        }
    }

}