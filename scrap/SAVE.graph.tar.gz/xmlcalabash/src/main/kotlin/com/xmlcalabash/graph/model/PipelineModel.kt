package com.xmlcalabash.graph.model

import com.xmlcalabash.datamodel.*
import com.xmlcalabash.exceptions.XProcError
import com.xmlcalabash.graph.*
import com.xmlcalabash.namespace.NsCx
import com.xmlcalabash.namespace.NsP
import java.io.PrintStream
import java.util.*

class PipelineModel(builder: DeclareStepInstruction): CompoundModel(NsP.declareStep, builder, null) {
    val modelMap = mutableMapOf<InstructionBuilder, Model>()
    val connections = mutableListOf<Connection>()
    var cacheCount = 0

    override fun build() {
        super.build()
        addConnections(this)

        for ((builder, model) in modelMap) {
            if (builder is DeclareStepBuilder) {
                (model as CompoundModel).patchDefaultInputs(modelMap, connections)
            }
        }

        addSplitters()
        addFilters()

        if (builder.context.environment.options.pipelineGraph != null) {
            describe(builder.context.environment.options.pipelineGraph!!)
        }

        checkLoops(this, Stack<Model>())

        markDefaults()

        decompose(this)
    }

    private fun markDefaults() {
        val defaultContributors = mutableMapOf<Model,String>()
        for ((builder, model) in modelMap) {
            if (builder is InputFilterBuilder) {
                defaultContributors.put(model, builder.port)
            }
        }

        var done = false
        while (!done) {
            done = true
            for (conn in connections) {
                if (defaultContributors.containsKey(conn.to.parent)) {
                    if (!defaultContributors.containsKey(conn.from.parent)) {
                        done = false
                        defaultContributors.put(conn.from.parent, defaultContributors[conn.to.parent]!!)
                    }
                }
            }
        }

        for ((model,port) in defaultContributors) {
            if (model !is HeadModel && model.builder.instructionType != NsCx.inputFilter) {
                model.contributesToDefault = port
            }
        }
    }

    private fun checkLoops(node: Model, seen: Stack<Model>) {
        if (node in seen) {
            throw XProcError.xsLoop(node.builder.context.stepName).exception()
        }
        seen.push(node)

        for (conn in connections) {
            if (conn.from.parent == node && conn.to.parent !is FootModel) {
                checkLoops(conn.to.parent, seen)
            }
        }

        if (node is CompoundModel) {
            for (child in node.children) {
                checkLoops(child, seen)
            }
        }

        seen.pop()
    }

    fun addConnection(from: ModelPort, to: ModelPort) {
        // There are four cases:
        // 1. The steps are siblings, just make the connection
        if (to.parent.parent === from.parent.parent) {
            // These are siblings
            connections.add(Connection(from, to))
            return
        }

        // 2. The step is writing to its parent; this is the output of a compound step
        if (to.parent === from.parent.parent) {
            // This is the output for a pipeline
            val readFrom = if (from.parent is CompoundModel) {
                from.parent.addOutput(from)
            } else {
                from
            }
            val writeTo = (to.parent as CompoundModel).foot.addInput(to)
            connections.add(Connection(readFrom, writeTo))
            return
        }

        // 3. The step is reading from its parent
        if (to.parent.parent == from.parent) {
            val readFrom = (from.parent as CompoundModel).head.addOutput(from)
            connections.add(Connection(readFrom, to))
            return
        }

        // 4. The step is reading from some ancestor above its parent
        val cacheName = "!cache_${++cacheCount}"
        val grandParent = to.parent.parent as CompoundModel
        val readFrom = grandParent.head.addOutput(cacheName, from)
        connections.add(Connection(readFrom, to))

        val pwriteTo = to.parent.parent.addInput(cacheName, to)

        // The p:for-each and p:viewport steps feed their subpipelines one document at a time
        if (grandParent.stepType == NsP.forEach || grandParent.stepType == NsP.viewport) {
            // FIXME: it should be possible to tweak things so that the sequence check is avoided
        }

        addConnection(from, pwriteTo)
    }

    fun connections(port: ModelPort): List<Connection> {
        val ports = mutableListOf<Connection>()
        for (conn in connections) {
            if (conn.from === port || conn.to === port) {
                ports.add(conn)
            }
        }
        return ports
    }

    fun findWritable(element: InstructionBuilder, name: String): ModelPort {
        if (modelMap.isEmpty()) {
            scanModel()
        }

        val model = modelMap[element] ?: throw RuntimeException("Configuration error: no model for ${element}")
        if (model is CompoundModel) {
            for (port in model.outputs) {
                if (port.name == name) {
                    return port
                }
            }
        }
        for (port in model.inputs) {
            if (port.name == name) {
                return port
            }
        }
        throw RuntimeException("Configuration error: no ${name} input port on ${model}")
    }

    fun findReadable(element: InstructionBuilder, name: String): ModelPort {
        if (modelMap.isEmpty()) {
            scanModel()
        }

        val model = modelMap[element] ?: throw RuntimeException("Configuration error: no model for ${element}")
        if (model is CompoundModel) {
            for (port in model.inputs) {
                if (port.name == name) {
                    return port
                }
            }
            for (port in foot.outputs) {
                if (port.name == name) {
                    return port
                }
            }
        }
        for (port in model.outputs) {
            if (port.name == name) {
                return port
            }
        }
        throw RuntimeException("Configuration error: no ${name} output port on ${model}")
    }

    private fun scanModel(root: Model = this) {
        modelMap.put(root.builder, root)
        if (root is CompoundModel) {
            for (child in root.children) {
                scanModel(child)
            }
        }
    }

    private fun addSplitters() {
        val portMap = mutableMapOf<ModelPort,MutableList<Connection>>()
        for (conn in connections) {
            if (conn.from !in portMap.keys) {
                portMap[conn.from] = mutableListOf()
            }
            portMap[conn.from]!!.add(conn)
        }

        for ((_, conns) in portMap) {
            if (conns.size > 1) {
                val container = conns[0].to.parent.parent as CompoundModel

                val splitterStep = Splitter(container.builder as CompoundStepBuilder, context)

                val splitter = FilterModel(NsCx.splitter, conns[0].to.parent.builder, splitterStep, container)
                val splitterInput = splitter.addInput("source", conns[0].from)
                splitterInput.sequence = true

                container.children.add(splitter)

                val source = conns[0].from
                //val writePipe = conns[0].pipe

                for (index in conns.indices) {
                    val readsFrom = splitter.addOutput("!result_${index+1}", conns[index].to)
                    conns[index].from = readsFrom
                }

                connections.add(Connection(source, splitterInput))
            }
        }

        portMap.clear()
        for (conn in connections) {
            if (conn.to !in portMap.keys) {
                portMap[conn.to] = mutableListOf()
            }
            portMap[conn.to]!!.add(conn)
        }

        for ((_,conns) in portMap) {
            if (conns.size > 1) {
                val container = conns[0].to.parent.parent as CompoundModel

                val joinerStep = Joiner(container.builder as CompoundStepBuilder, context)

                val mediaTypes = mutableSetOf<MediaType>()
                for (conn in conns) {
                    mediaTypes.addAll(conn.from.contentTypes)
                }

                val joiner = FilterModel(NsCx.joiner, conns[0].to.parent.builder, joinerStep, container)
                val joinerOutput = joiner.addOutput("source", true, true, mediaTypes.toList())
                joinerOutput.sequence = true

                val target = conns[0].to
                //val writePipe = conns[0].pipe

                container.children.add(joiner)

                for (index in conns.indices) {
                    val writesTo = joiner.addInput("!source_${index+1}", false, true, conns[index].from.contentTypes, false)
                    conns[index].to = writesTo
                }

                connections.add(Connection(joinerOutput, target))
            }
        }
    }

    private fun addFilters() {
        val newConnections = mutableListOf<Connection>()
        for (conn in connections) {
            val container = conn.to.parent.parent as CompoundModel
            val fromPort = conn.from
            val toPort = conn.to

            if (needContentTypeFilter(fromPort, toPort)) {
                val typeCheck = ContentTypeCheck(container.builder as CompoundStepBuilder, context, toPort.contentTypes, toPort.parent is FootModel)

                val typeCheckModel = FilterModel(NsCx.contentTypeCheck, toPort.parent.builder, typeCheck, container)
                container.children.add(typeCheckModel)

                val filterInput = typeCheckModel.addInput("source", true, true, fromPort.contentTypes, false)
                val filterOutput = typeCheckModel.addOutput("result", true, true, toPort.contentTypes)

                filterInput.contentTypes = toPort.contentTypes

                val newConn = Connection(fromPort, filterInput)
                newConnections.add(newConn)

                conn.from = filterOutput
            }

        }
        connections.addAll(newConnections)
    }

    private fun needContentTypeFilter(from: ModelPort, to: ModelPort): Boolean {
        // If the receiver accepts any type, then we don't need a filter
        if (to.contentTypes.isEmpty()) {
            return false
        }

        for (ctype in to.contentTypes) {
            if (ctype == MediaType.ANY && ctype.suffix == null) {
                return false
            }
        }

        // If the sender can send any content type (but the receiver can't accept any)
        // then we need a filter
        if (from.contentTypes.isEmpty()) {
            return true
        }

        for (ctype in from.contentTypes) {
            if (ctype == MediaType.ANY && ctype.suffix == null) {
                return true
            }
        }

        // Otherwise, do a pair-wise checking
        var mightFail = false
        for (fromtype in from.contentTypes) {
            var thisIsOk = false
            for (totype in to.contentTypes) {
                if (totype.matches(fromtype)) {
                    thisIsOk = true
                }
            }
            mightFail = mightFail || !thisIsOk
        }

        return mightFail
    }

    fun describe() {
        describe(System.out)
    }

    fun describe(out: PrintStream) {
        out.println("<graph>")
        super.describe(out, 0)
        for (connection in connections) {
            out.println("<connect from='P${connection.from.portId}' to='P${connection.to.portId}'/>")
        }
        out.println("</graph>")
    }
}