package com.xmlcalabash.graph.model

import com.xmlcalabash.datamodel.*
import com.xmlcalabash.documents.XProcDocument

open class AtomicModel(builder: AtomicStepInstruction, parent: Model): AbstractAtomicModel(builder, parent) {
    val useDefaultInputs: Set<String> = setOf() // builder.useDefaultInputs

    override fun build() {
        /*
        for ((name, value) in (builder as XProcStepInstruction).inScopeStatics) {
            bindings[name] = XProcDocument(value, context)
        }
         */

        for (child in builder.children) {
            when (child) {
                is WithInputInstruction -> {
                    var empty = true
                    for (gchild in child.children) {
                        empty = empty && gchild is EmptyInstruction
                    }
                    if (!empty) {
                        addInput(child)
                    }
                }
                is WithOutputInstruction -> addOutput(child)
                is WithOptionInstruction -> {
                    if (child.staticValue == null) {
                        addInput("Q{${child.name.namespaceUri}}${child.name.localName}", false, false, listOf(), false)
                    } else {
                        val doc = XProcDocument(child.staticValue!!, child.stepConfig)
                        options.put(child.name, OptionModel(child.name, doc, child.staticValue != null))
                    }
                }
                else -> throw RuntimeException("Configuration error: unexpected child in atomic step: ${child}")
            }
        }
    }

}