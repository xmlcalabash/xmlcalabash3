package com.xmlcalabash.graph

import com.xmlcalabash.documents.XProcDocument
import com.xmlcalabash.graph.model.Model
import com.xmlcalabash.graph.model.OptionModel
import com.xmlcalabash.runtime.api.PortFlangeInfo
import net.sf.saxon.s9api.QName

open class NodeParameters(val stepType: QName,
                          val model: Model,
                          val inputs: Map<String, PortFlangeInfo>,
                          val outputs: Map<String, PortFlangeInfo>) {
    private val _options = mutableMapOf<QName, OptionModel>()
    private val _bindings = mutableMapOf<QName, XProcDocument>()

    var options: Map<QName, OptionModel>
        get() = _options
        internal set(value) {
            _options.clear()
            _options.putAll(value)
        }

    var bindings: Map<QName, XProcDocument>
        get() = _bindings
        internal set(value) {
            _bindings.clear()
            _bindings.putAll(value)
        }

}