package com.xmlcalabash.graph

import com.xmlcalabash.datamodel.OptionInstruction

class Head(parameters: NodeParameters,
           val optionDeclarations: List<OptionInstruction>): AtomicNode(parameters)