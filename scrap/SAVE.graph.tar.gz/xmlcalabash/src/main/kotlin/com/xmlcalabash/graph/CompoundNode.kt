package com.xmlcalabash.graph

class CompoundNode(parameters: NodeParameters,
                   val head: Node,
                   val foot: Node,
                   val subpipeline: List<Node>): Node(parameters) {
    override fun toString(): String {
        return parameters.stepType.toString()
    }
}
