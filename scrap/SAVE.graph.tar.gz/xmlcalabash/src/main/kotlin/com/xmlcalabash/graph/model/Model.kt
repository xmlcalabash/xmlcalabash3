package com.xmlcalabash.graph.model

import com.xmlcalabash.datamodel.*
import java.io.PrintStream

abstract class Model(val builder: XProcInstruction, val parent: Model? = null) {
    companion object {
        private var id = 0
    }
    val modelId = ++id

    val context = builder.stepConfig

    internal var contributesToDefault: String? = null

    protected val _inputs = mutableListOf<ModelPort>()
    val inputs: List<ModelPort>
        get() = _inputs
    protected val _outputs = mutableListOf<ModelPort>()
    val outputs: List<ModelPort>
        get() = _outputs

    abstract fun build()
    abstract fun describe(out: PrintStream, depth: Int = 0)

    fun addInput(xport: PortBindingContainer): ModelPort {
        val port = xport // context.environment.portPatches[xport] ?: xport
        var explicitlyEmpty = false
        var notEmpty = false
        for (child in port.children) {
            explicitlyEmpty = explicitlyEmpty || child is EmptyInstruction
            notEmpty = child !is EmptyInstruction
        }
        return addInput(port.port, port.primary == true, port.sequence == true, port.contentTypes, explicitlyEmpty && !notEmpty)
    }

    fun addInput(port: ModelPort): ModelPort {
        return addInput(port.name, port.primary, port.sequence, port.contentTypes, port.empty)
    }

    fun addInput(name: String, port: ModelPort): ModelPort {
        if (name.startsWith("!cache")) {
            return addInput(name, port.primary, port.sequence, listOf(), port.empty) // Ignore content types for cache input
        }
        return addInput(name, port.primary, port.sequence, port.contentTypes, port.empty)
    }

    fun addInput(name: String, primary: Boolean, sequence: Boolean, contentTypes: List<MediaType>, empty: Boolean): ModelPort {
        for (port in inputs) {
            if (port.name == name) {
                return port
            }
        }
        val port = ModelPort(name, this, primary, sequence, contentTypes, empty)
        _inputs.add(port)
        return port
    }

    fun addOutput(port: PortBindingContainer): ModelPort {
        return addOutput(port.port, port.primary == true, port.sequence == true, port.contentTypes)
    }

    fun addOutput(port: ModelPort): ModelPort {
        return addOutput(port.name, port.primary, port.sequence, port.contentTypes)
    }

    fun addOutput(name: String, port: ModelPort): ModelPort {
        return addOutput(name, port.primary, port.sequence, port.contentTypes)
    }

    fun addOutput(name: String, primary: Boolean, sequence: Boolean, contentTypes: List<MediaType>): ModelPort {
        for (port in outputs) {
            if (port.name == name) {
                return port
            }
        }
        val port = ModelPort(name, this, primary, sequence, contentTypes, false)
        _outputs.add(port)
        return port
    }

    override fun toString(): String {
        return builder.toString()
    }
}