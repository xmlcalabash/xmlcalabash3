package com.xmlcalabash.graph

open class AtomicNode(parameters: NodeParameters,
                      val useDefaultInputs: Set<String> = setOf()): Node(parameters) {
    override fun toString(): String {
        return parameters.stepType.toString()
    }
}