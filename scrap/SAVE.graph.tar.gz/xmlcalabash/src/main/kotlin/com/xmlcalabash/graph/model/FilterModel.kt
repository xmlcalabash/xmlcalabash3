package com.xmlcalabash.graph.model

import com.xmlcalabash.datamodel.XProcInstruction
import com.xmlcalabash.datamodel.XProcStepInstruction
import net.sf.saxon.s9api.QName

class FilterModel(val type: QName, val filterFor: XProcInstruction, builder: XProcStepInstruction, parent: Model): AbstractAtomicModel(builder, parent) {
    override fun build() {
        // nop
    }

}