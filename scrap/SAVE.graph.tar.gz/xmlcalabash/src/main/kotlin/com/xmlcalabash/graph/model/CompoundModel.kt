package com.xmlcalabash.graph.model

import com.xmlcalabash.datamodel.*
import com.xmlcalabash.exceptions.XProcError
import com.xmlcalabash.graph.Connection
import com.xmlcalabash.namespace.NsCx
import com.xmlcalabash.namespace.NsP
import net.sf.saxon.s9api.QName
import net.sf.saxon.s9api.XdmValue
import java.io.PrintStream

open class CompoundModel(val stepType: QName, builder: CompoundContainer, parent: Model?): Model(builder, parent) {
    val head = HeadModel(builder, this)
    val foot = FootModel(builder, this)
    val children = mutableListOf<Model>()
    val staticValues = mutableMapOf<QName, XdmValue>()

    override fun build() {
        for (child in builder.children) {
            when (child) {
                is InputInstruction -> addInput(child)
                is WithInputInstruction -> addInput(child)
                is OutputInstruction -> addOutput(child)
                is OptionInstruction -> {
                    if (child.staticValue != null) {
                        staticValues[child.name] = child.staticValue!!
                    }
                }
                is WithOptionInstruction -> {
                    if (child.staticValue == null) {
                        addInput("Q{${child.name.namespaceUri}}${child.name.localName}", false, false, listOf(), false)
                    } else {
                        staticValues[child.name] = child.staticValue!!
                    }
                }

                is VariableInstruction -> {
                    if (child.staticValue == null) {
                        throw RuntimeException("unexpected variable with non-null static value")
                    } else {
                        staticValues[child.name] = child.staticValue!!
                    }
                }

                is CompoundContainer -> {
                    // Ignore declarations for atomic steps; their implementation comes from elsewhere
                    if (child !is DeclareStepInstruction || !child.isAtomic) {
                        val cmodel = when (child) {
                            is ForEachInstruction -> CompoundModel(NsP.forEach, child, this)
                            is ViewportInstruction -> CompoundModel(NsP.viewport, child, this)
                            is ChooseInstruction -> CompoundModel(NsP.choose, child, this)
                            is OtherwiseInstruction -> CompoundModel(NsP.otherwise, child, this)
                            is WhenInstruction -> CompoundModel(NsP.`when`, child, this)
                            is GroupInstruction -> CompoundModel(NsP.group, child, this)
                            is TryInstruction -> CompoundModel(NsP.`try`, child, this)
                            is CatchInstruction -> CompoundModel(NsP.catch, child, this)
                            is FinallyInstruction -> CompoundModel(NsP.finally, child, this)
                            is DeclareStepInstruction -> CompoundModel(child.type ?: NsCx.unreachableType, child, this)
                            else -> throw RuntimeException("Configuration error: unexpected compound step: ${child}")
                        }
                        cmodel.build()
                        children.add(cmodel)
                    }
                }
/*
                is AtomicEmptyInstruction -> {
                    val amodel = AtomicEmptyModel(child, this, child.signalDefault)
                    amodel.build()
                    children.add(amodel)
                }
*/
                is AtomicStepInstruction -> {
                    val amodel = AtomicModel(child, this)
                    amodel.build()
                    children.add(amodel)
                }

                is WithOutputInstruction -> {
                    if (child.port.startsWith("!depends")) {
                    } else {
                        throw XProcError.xsInvalidElement().exception()
                    }
                }
/*
                is RunBuilder -> {
                    val rmodel = RunModel(child, this)
                    rmodel.build()
                    children.add(rmodel)
                }
                is ImportBuilder -> Unit // ignore
                is com.xmlcalabash.datamodel.ImportFunctionsBuilder -> Unit // also ignore
*/
                else -> throw RuntimeException("unexpected child type: ${child.javaClass}")
            }
        }
    }

    fun addConnections(pipeline: PipelineModel) {
        for (child in children.filterIsInstance<CompoundModel>()) {
            child.addConnections(pipeline)
        }

        for (child in children.filterIsInstance<AbstractAtomicModel>()) {
            connectIO(pipeline, child)
        }

        connectIO(pipeline, this)
    }

    private fun connectIO(pipeline: PipelineModel, model: Model) {
        for (child in model.builder.children) {
            when (child) {
                is InputInstruction -> connectPipes(pipeline, child)
                is WithInputInstruction -> connectPipes(pipeline, child)
                is OutputInstruction -> connectPipes(pipeline, child)
                is WithOutputInstruction -> connectPipes(pipeline, child)
                else -> Unit
            }
        }
/*
        if (model.builder is XProcStepInstruction) {
            for ((name, readsFrom) in model.builder.inScopeDynamics) {
                val readPort = pipeline.findReadable(readsFrom.parent!!, readsFrom.port!!)
                val writePort = model.addInput("V{${name.namespaceUri}}${name.localName}", false, false, listOf(), false)
                pipeline.addConnection(readPort, writePort)
            }
        }
 */
    }

    private fun connectPipes(pipeline: PipelineModel, element: XProcInstruction) {
        for (child in element.children) {
            when (child) {
                is PipeInstruction -> connectPipe(pipeline, child)
                else -> Unit
            }
        }
    }

    private fun connectPipe(pipeline: PipelineModel, pipe: PipeInstruction) {
        val parent = pipe.parent

        if (parent is WithInputInstruction && parent.port.startsWith("Q{")) {
            val pos = parent.port.indexOf("}")
            val name = QName(parent.port.substring(2, pos), parent.port.substring(pos + 1))
            if (staticValues.containsKey(name)) {
                return
            }
        }

        val readsFrom = pipe.readablePort ?: throw RuntimeException("Configuration error: pipe readsFrom is null")
        val readPort = when (readsFrom) {
            is InputInstruction -> pipeline.findReadable(readsFrom.parent!!, readsFrom.port)
            is WithInputInstruction -> pipeline.findReadable(readsFrom.parent!!, readsFrom.port)
            is OutputInstruction -> pipeline.findReadable(readsFrom.parent!!, readsFrom.port)
            is WithOutputInstruction -> pipeline.findReadable(readsFrom.parent!!, readsFrom.port)
            else -> throw RuntimeException("Unexpected readsFrom: ${readsFrom}")
        }

        val writePort = when (parent) {
            is InputInstruction -> pipeline.findWritable(parent.parent!!, parent.port)
            is WithInputInstruction -> pipeline.findWritable(parent.parent!!, parent.port)
            is OutputInstruction -> pipeline.findWritable(parent.parent!!, parent.port)
            is WithOutputInstruction -> pipeline.findWritable(parent.parent!!, parent.port)
            else -> throw RuntimeException("Unexpected reader: ${parent}")
        }

        pipeline.addConnection(readPort, writePort)
    }

    internal fun patchDefaultInputs(modelMap: Map<XProcInstruction,Model>, connections: List<Connection>) {
        val portMapping = mutableMapOf<ModelPort, ModelPort>()

        for (conn in connections) {
            val fromParent = conn.from.parent
            val fromType = fromParent.builder.instructionType
            val toParent = conn.to.parent
            val toType = toParent.builder.instructionType
            if (fromParent is HeadModel && toParent is AtomicModel) {
                if (fromType == NsP.declareStep && toType == NsCx.inputFilter) {
                    val toPort = modelMap[toParent.builder]!!.outputs.first()
                    portMapping[conn.from] = toPort
                }
            }
        }

        for (conn in connections) {
            if (portMapping.containsKey(conn.from)) {
                val toParent = conn.to.parent
                val type = toParent.builder.instructionType
                if (toParent is AtomicModel && type == NsCx.inputFilter) {
                    continue
                }
                conn.from = portMapping[conn.from]!!
            }
        }
    }

    internal fun xpatchDefaultInputs(connections: MutableList<Connection>) {
        for (child in children) {
            val newConnections = mutableListOf<Connection>()
            if (child is AtomicModel && child.builder is InputFilterInstruction) {
                val port = child.builder.port
                for (conn in connections) {
                    if (conn.from.parent is HeadModel && conn.from.name == port) {
                        if (conn.from.parent.builder == builder) {
                            // println("old: ${conn}")

                            // Create the source input on the default input step
                            val defaultSource = child.addInput("source", true, true, listOf(),false)

                            // We need to fake a PipeBindingBuilder for the source to default connection
                            val newPipe = PipeInstruction(child.builder)
                            val declBuilder = conn.from.parent.builder as DeclareStepInstruction
                            val fromPort = declBuilder.namedInput(port)
                            newPipe.setReadablePort(fromPort!!)

                            val newFrom = child.outputs.first()
                            val newConn = Connection(newFrom, conn.to)
                            newConnections.add(newConn)

                            // println("new: ${newConn}")

                            val newTo = defaultSource
                            conn.to = newTo

                            // println("fix: ${conn}")
                        }
                    }
                }
            }
            connections.addAll(newConnections)
        }
    }

    fun decompose(pipeline: PipelineModel) {
        for (index in children.indices) {
            val child = children[index]
            if (child is CompoundModel) {
                val submodel = SubpipelineModel(child)
                for (input in child.inputs) {
                    val port = submodel.addInput(input)
                    for (conn in pipeline.connections) {
                        if (conn.to.parent == child && conn.to.name == port.name) {
                            conn.to = port
                        }
                    }
                }

                for (output in child.outputs) {
                    val port = submodel.addOutput(output)
                    for (conn in pipeline.connections) {
                        if (conn.from.parent == child && conn.from.name == port.name) {
                            conn.from = port
                        }
                    }
                }

                children[index] = submodel
                child.decompose(pipeline)
            }
        }
    }

    override fun describe(out: PrintStream, depth: Int) {
        val DEPTH = 3

        out.println()
        out.print("${"".padStart(depth*DEPTH)}<compound id='M${modelId}'")
        if (builder is XProcStepInstruction) {
            out.print(" name='${builder.name}' type='${builder.instructionType}'")
        }
        out.println(">")
        for (input in inputs) {
            out.println("${"".padStart((depth+1)*DEPTH)}<input id='P${input.portId}' name='${input.name}'/>")
        }
        for (output in outputs) {
            out.println("${"".padStart((depth+1)*DEPTH)}<output id='P${output.portId}' name='${output.name}'/>")
        }
        head.describe(out,depth+1)
        for (child in children) {
            child.describe(out, depth+1)
        }
        foot.describe(out, depth+1)
        out.println("${"".padStart(depth*DEPTH)}</compound>")
    }
}