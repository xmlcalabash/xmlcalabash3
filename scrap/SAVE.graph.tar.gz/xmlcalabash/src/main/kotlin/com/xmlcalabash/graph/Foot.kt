package com.xmlcalabash.graph

class Foot(parameters: NodeParameters): AtomicNode(parameters)