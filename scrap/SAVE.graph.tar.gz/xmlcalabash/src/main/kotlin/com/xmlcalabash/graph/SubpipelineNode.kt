package com.xmlcalabash.graph

class SubpipelineNode(parameters: NodeParameters,
                      val implementation: CompoundNode): AtomicNode(parameters) {
    private val weldedInputs = mutableSetOf<String>()
    fun weldInput(port: String) {
        if (port in parameters.inputs) {
            weldedInputs.add(port)
        }
    }
    fun weldedInput(port: String): Boolean = weldedInputs.contains(port)
}