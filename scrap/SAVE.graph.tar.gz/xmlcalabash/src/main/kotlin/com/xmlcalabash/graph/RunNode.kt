package com.xmlcalabash.graph

open class RunNode(parameters: NodeParameters,
                   useDefaultInputs: Set<String> = setOf()): AtomicNode(parameters, useDefaultInputs) {
    override fun toString(): String {
        return parameters.stepType.toString()
    }
}