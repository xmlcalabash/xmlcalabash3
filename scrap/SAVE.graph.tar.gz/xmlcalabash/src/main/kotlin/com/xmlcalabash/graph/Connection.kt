package com.xmlcalabash.graph

import com.xmlcalabash.graph.model.ModelPort

class Connection(var from: ModelPort, var to: ModelPort) {
    override fun toString(): String {
        return "${from} -> ${to}"
    }
}