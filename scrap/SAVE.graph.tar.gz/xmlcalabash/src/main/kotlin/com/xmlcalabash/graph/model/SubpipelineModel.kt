package com.xmlcalabash.graph.model

import java.io.PrintStream

class SubpipelineModel(model: CompoundModel): Model(model.builder, model) {
    override fun build() {
        // nop
    }

    override fun describe(out: PrintStream, depth: Int) {
        out.println()
        out.println("${"".padStart(depth*3)}<atomic id='M${modelId}'>")
        for (input in inputs) {
            out.println("${"".padStart((depth+1)*3)}<input id='I${input.portId}' name='${input.name}'/>")
        }
        for (output in outputs) {
            out.println("${"".padStart((depth+1)*3)}<input id='I${output.portId}' name='${output.name}'/>")
        }
    }
}