package com.xmlcalabash.graph.model

import com.xmlcalabash.datamodel.CompoundContainer

class FootModel(builder: CompoundContainer, parent: Model): AbstractAtomicModel(builder, parent) {
    override fun build() {
        // nop
    }
}