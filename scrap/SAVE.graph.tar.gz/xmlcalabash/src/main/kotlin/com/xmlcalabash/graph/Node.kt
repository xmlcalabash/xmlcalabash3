package com.xmlcalabash.graph

abstract class Node(val parameters: NodeParameters) {
    val nodeId = NodeId(parameters.model)
}