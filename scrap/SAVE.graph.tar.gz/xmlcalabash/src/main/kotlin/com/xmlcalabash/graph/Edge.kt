package com.xmlcalabash.graph

class Edge(val from: Port, val to: Port) {
    override fun toString(): String {
        return "${from} -> ${to}"
    }
}