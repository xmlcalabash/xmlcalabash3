package com.xmlcalabash.graph.model

import com.xmlcalabash.datamodel.CompoundContainer

class HeadModel(builder: CompoundContainer, parent: Model): AbstractAtomicModel(builder, parent) {
    override fun build() {
        // nop
    }
}