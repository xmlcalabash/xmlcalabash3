package com.xmlcalabash.graph.model

import com.xmlcalabash.datamodel.MediaType

class ModelPort(var name: String,
                val parent: Model,
                var primary: Boolean,
                var sequence: Boolean,
                var contentTypes: List<MediaType>,
                var empty: Boolean) {
    companion object {
        private var id = 0
    }
    val portId = ++id

    override fun toString(): String {
        return "${parent}/${name}"
    }
}