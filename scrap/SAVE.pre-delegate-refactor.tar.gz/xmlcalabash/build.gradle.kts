import com.xmlcalabash.build.XmlCalabashBuildExtension

plugins {
  id("buildlogic.kotlin-library-conventions")
  id("com.xmlcalabash.build.xmlcalabash-build")
  id("com.github.gmazzo.buildconfig") version "5.3.5"
  id("org.jetbrains.dokka") version "1.9.20"
  `maven-publish`
}

repositories {
  mavenLocal()
  mavenCentral()
  maven { url = uri("https://maven.saxonica.com/maven") }
}

configurations.forEach {
  it.exclude("com.sun.xml.ibind.jaxp")
  it.exclude("isorelax")
  it.exclude("relaxngDatatype")
}

dependencies {
  implementation("org.jetbrains.kotlin:kotlin-stdlib:2.0.0")
  implementation("org.jetbrains.kotlinx:kotlinx-coroutines-core:1.8.1")
  implementation("org.jetbrains.kotlin:kotlin-reflect:2.0.0")
  implementation("name.dmaus.schxslt:schxslt:1.9.5")
  implementation("nu.validator:htmlparser:1.4.16")
  implementation("org.apache.commons:commons-compress:1.26.1")
  implementation("commons-codec:commons-codec:1.17.0")
  implementation("javax.activation:activation:1.1.1") // For mimetype mapping
  implementation("com.nwalsh:sinclude:5.2.4") {
    exclude(group="net.sf.saxon", module="Saxon-HE")
  }
  implementation("org.commonmark:commonmark:0.22.0")
  implementation("org.commonmark:commonmark-ext-gfm-tables:0.22.0")
  implementation("org.commonmark:commonmark-ext-gfm-strikethrough:0.22.0")
  implementation("org.commonmark:commonmark-ext-image-attributes:0.22.0")
  implementation("org.relaxng:jing:20220510")
  implementation("com.networknt:json-schema-validator:1.4.0")
  implementation("org.xmlresolver:xmlresolver:6.0.4")

  // I was using log4j but httpclient5 uses slf4j.
  // Could I get httpclient5 to use log4j? Maybe. ¯\_(ツ)_/¯
  // But I got tired of trying to figure it out so I did this instead.
  implementation("org.slf4j:slf4j-api:2.0.13")
  implementation("org.slf4j:slf4j-simple:2.0.13")
  implementation("org.apache.logging.log4j:log4j-to-slf4j:2.23.1")

  implementation("org.apache.httpcomponents.client5:httpclient5:5.3.1")
}

val xmlbuild = the<XmlCalabashBuildExtension>()

buildConfig {
  className("XmlCalabashBuildConfig")
  packageName("com.xmlcalabash")
  useKotlinOutput { internalVisibility = false } 

  buildConfigField("APP_NAME", xmlbuild.name.get())
  buildConfigField("APP_VERSION", xmlbuild.version.get())
  buildConfigField("BUILD_TIME", System.currentTimeMillis())
  //buildConfigField("BUILD_HASH", xmlbuild.gitHash())
}

tasks.dokkaHtml {
    outputDirectory.set(layout.buildDirectory.dir("documentation/html"))
}

tasks.dokkaGfm {
    outputDirectory.set(layout.buildDirectory.dir("documentation/markdown"))
}

tasks.jar {
  archiveFileName.set(xmlbuild.jarArchiveFilename())
}

val sourcesJar by tasks.registering(Jar::class) {
  archiveClassifier = "sources"
  from(sourceSets.main.get().allSource)
}

publishing {
  repositories {
    maven {
      url = uri("https://github.com/xmlcalabash/xmlcalabash3")
    }
  }

  publications {
    register("mavenJava", MavenPublication::class) {
      pom {
        name = "XML Calabash"
        packaging = "jar"
        description = "An XProc 3.0 processor"
        url = "https://github.com/xmlcalabash/xmlcalabash3"

        scm {
          url = "scm:git@github.com:xmlcalabash/xmlcalabash3.git"
          connection = "scm:git@github.com:xmlcalabash/xmlcalabash3.git"
          developerConnection = "scm:git@github.com:xmlcalabash/xmlcalabash3.git"
        }

        licenses {
          license {
            name = "Apache License, Version 2.0"
            url = "https://www.apache.org/licenses/LICENSE-2.0"
            distribution = "repo"
          }
        }

        developers {
          developer {
            id = "ndw"
            name = "Norm Tovey-Walsh"
          }
        }
      }

      from(components["java"])
      artifact(sourcesJar.get())
    }
  }
}

