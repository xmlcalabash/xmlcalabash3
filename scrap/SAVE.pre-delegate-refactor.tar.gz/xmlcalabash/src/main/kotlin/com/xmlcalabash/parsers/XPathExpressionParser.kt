package com.xmlcalabash.parsers

import com.xmlcalabash.namespace.NsFn
import com.xmlcalabash.parsers.XPath31.EventHandler
import com.xmlcalabash.xprocparser.StepConfiguration
import net.sf.saxon.om.NamespaceUri
import net.sf.saxon.s9api.QName
import java.util.*

class XPathExpressionParser(val stepConfig: StepConfiguration) {
    companion object {
        private val TRACE = false
    }

    fun parse(expr: String): XPathExpressionDetails {
        var errors = false
        val handler = FindRefs(TRACE)
        handler.initialize()

        // Hack. This doesn't trigger a ContextItemExpr
        handler.context = expr.startsWith("/")

        val parser = XPath31(expr, handler)
        try {
            parser.parse_XPath()
        } catch (ex: Exception) {
            errors = true
        }

        val variables = mutableSetOf<QName>()
        for (name in handler.varlist) {
            variables.add(stepConfig.parseQName(name))
        }

        val functions = mutableSetOf<QName>()
        for (name in handler.funclist) {
            val fname = stepConfig.parseQName(name)
            if (fname.namespaceUri == NamespaceUri.NULL) {
                functions.add(QName(NsFn.namespace, fname.localName))
            } else {
                functions.add(fname)
            }
        }

        return XPathExpressionDetails(errors, variables, functions, handler.context)
    }

    /*
unab:

PathExpr / RelativePathExpr / StepExpr / AxisStep / ForwardStep / ForwardAxis

$doc

PathExpr / RelativePathExpr / StepExpr / PostfixExpr / PrimaryExpr / VarRef

s-doc

PathExpr / ‘/’
PathExpr / ‘//’

doc:

PathExpr / RelativePathExpr / StepExpr / AxisStep / ForwardStep / AbbrevForwardStep / NodeTest

dot:

PathExpr / RelativePathExpr / StepExpr / PostfixExpr / PrimaryExpr / ContextItemExpr
     */

    private enum class XPathState {
        IGNORE, PATHEXPR, RELPATHEXPR, STEPEXPR, AXISSTEP, POSTFIXEXPR, PRIMARYEXPR
    }

    private class FindRefs(val trace: Boolean): EventHandler {
        private var input: String = ""
        private var sawDollar = false
        // Simple switches won't work if they can nest, but I don't think they can...
        private var functionCall = false
        private var functionName = false
        private var quantified = false // I bet this one can nest...
        private var quantvar: MutableSet<String> = mutableSetOf()
        private val stack: Stack<String> = Stack()
        private var xpathState = XPathState.IGNORE

        var context = false
        val varlist: MutableList<String> = mutableListOf()
        val funclist: MutableList<String> = mutableListOf()

        fun initialize() {
            input = ""
            context = false
            varlist.clear()
            funclist.clear()
            stack.clear()
            sawDollar = false
            functionCall = false
            functionName = false
        }

        override fun reset(string: CharSequence?) {
            if (trace) {
                println("Parser reset: ${string}")
            }
            input = string?.toString() ?: ""
        }

        override fun startNonterminal(name: String?, begin: Int) {
            when (name) {
                "PathExpr" -> xpathState = XPathState.PATHEXPR
                "RelativePathExpr" -> {
                    if (xpathState == XPathState.PATHEXPR) {
                        xpathState = XPathState.RELPATHEXPR
                    } else {
                        xpathState = XPathState.IGNORE
                    }
                }
                "StepExpr" -> {
                    if (xpathState == XPathState.RELPATHEXPR) {
                        xpathState = XPathState.STEPEXPR
                    } else {
                        xpathState = XPathState.IGNORE
                    }
                }
                "AxisStep" -> {
                    if (xpathState == XPathState.STEPEXPR) {
                        context = true
                    }
                    xpathState = XPathState.IGNORE
                }
                "PostfixExpr" -> {
                    if (xpathState == XPathState.STEPEXPR) {
                        xpathState = XPathState.POSTFIXEXPR
                    } else {
                        xpathState = XPathState.IGNORE
                    }
                }
                "PrimaryExpr" -> {
                    if (xpathState == XPathState.POSTFIXEXPR) {
                        xpathState = XPathState.PRIMARYEXPR
                    } else {
                        xpathState = XPathState.IGNORE
                    }
                }
                "ContextItemExpr" -> {
                    if (xpathState == XPathState.PRIMARYEXPR) {
                        context = true
                        xpathState = XPathState.IGNORE
                    }
                }
            }

            if (trace) {
                println("+NT: ${name} (${xpathState})")
            }
            stack.push(name)

            when (name) {
                "FunctionCall" -> functionCall = true
                "FunctionName" -> functionName = true
                "QuantifiedExpr" -> quantified = true
                else -> Unit
            }
        }

        override fun endNonterminal(name: String?, end: Int) {
            if (trace) {
                println("-NT: ${name}")
                if (name == "XPath") {
                    println("--- CONTEXT=${context}")
                }
            }
            stack.pop()

            when (name) {
                "FunctionCall" -> functionCall = false
                "FunctionName" -> functionName = false
                else -> Unit
            }
        }

        override fun terminal(name: String?, begin: Int, end: Int) {
            if (trace) {
                println("  T: ${name}")
            }

            if (xpathState == XPathState.PATHEXPR && (name == "'/'" || name == "'//'")) {
                context = true
            }

            if (sawDollar) {
                val varname = characters(begin, end)
                if (quantified) {
                    quantvar += varname
                } else {
                    if (!quantvar.contains(varname)) {
                        varlist += varname
                    }
                }
            } else {
                if (functionCall && functionName) {
                    funclist += characters(begin, end)
                }
            }
            sawDollar = name == "'$'"
            if (quantified && name == "in") {
                quantified = false
            }
        }

        override fun whitespace(begin: Int, end: Int) {
            // nop
        }

        private fun characters(begin: Int, end: Int): String =
            if (begin < end) {
                input.substring(begin, end)
            } else {
                ""
            }
    }
}