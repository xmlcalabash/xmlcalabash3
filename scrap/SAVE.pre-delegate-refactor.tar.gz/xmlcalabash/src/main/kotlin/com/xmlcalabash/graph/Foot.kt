package com.xmlcalabash.graph

class Foot(val parent: CompoundNode): Node(parent.step) {
    override fun addEdges() {
        // nop
    }

    override fun toString(): String {
        return "Foot(${parent})"
    }
}