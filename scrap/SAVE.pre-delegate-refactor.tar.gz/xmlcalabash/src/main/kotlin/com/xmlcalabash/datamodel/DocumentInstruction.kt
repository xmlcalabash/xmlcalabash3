package com.xmlcalabash.datamodel

import com.xmlcalabash.exceptions.XProcError
import com.xmlcalabash.namespace.Ns
import com.xmlcalabash.namespace.NsP
import net.sf.saxon.s9api.*

class DocumentInstruction private constructor(parent: XProcInstruction): ConnectionInstruction(parent, NsP.document) {
    constructor(parent: XProcInstruction, href: XProcExpression): this(parent) {
        this.href = href.cast(parent.stepConfig.parseSequenceType("xs:anyURI"))
    }

    private var context: InstructionStaticContext? = null

    var href: XProcExpression = XProcExpression.error(parent.stepConfig)
        set(value) {
            checkOpen()
            field = value.cast(parent!!.stepConfig.parseSequenceType("xs:anyURI"))
        }

    var contentType: MediaType? = null
        set(value) {
            checkOpen()
            field = value
        }

    private var _documentProperties: XProcExpression? = null
    var documentProperties: XProcExpression
        get() = _documentProperties!!
        set(value) {
            checkOpen()
            _documentProperties = value.cast(parent!!.stepConfig.parseSequenceType("map(xs:QName,item()*)"))
        }

    private var _parameters: XProcExpression? = null
    var parameters: XProcExpression
        get() = _parameters!!
        set(value) {
            checkOpen()
            _parameters = value.cast(parent!!.stepConfig.parseSequenceType("map(xs:QName,item()*)"))
        }

    override fun elaborate() {
        if (_documentProperties == null) {
            _documentProperties = XProcExpression.constant(parent!!.stepConfig, XdmMap(), parent!!.stepConfig.parseSequenceType("map(xs:QName,item()*)"))
        }

        if (_parameters == null) {
            _parameters = XProcExpression.constant(parent!!.stepConfig, XdmMap(), parent!!.stepConfig.parseSequenceType("map(xs:QName,item()*)"))
        }

        for (child in children) {
            reportError(XProcError.xsInvalidElement(child.instructionType))
        }

        super.elaborate()
    }

    override fun staticAnalysis(context: InstructionStaticContext) {
        this.context = context.copy()

        if ((parameters.contextRef || documentProperties.contextRef) && context.drp == null) {
            reportError(XProcError.xsPortNotReadable())
        }

        for (varname in parameters.variableRefs) {
            val variable = context.inscopeVariables[varname]
            if (variable == null) {
                reportError(XProcError.xsXPathStaticError(varname))
                continue
            }
        }

        super.staticAnalysis(context)
    }

    override fun promoteToStep(step: XProcInstruction): List<AtomicStepInstruction> {
        val newSteps = mutableListOf<AtomicStepInstruction>()

        val docStep = AtomicDocumentStepInstruction(step, "!document_${stepConfig.pipelineConfig.nextId}")

        documentProperties.computeStaticValue(context!!)
        if (documentProperties.staticValue != null) {
            docStep._staticOptions[Ns.documentProperties] = documentProperties.staticValue!!
        } else {
            val exprSteps = documentProperties.promoteToStep(step, context!!)
            val expr = exprSteps.last()

            val wi = docStep.withInput()
            wi.port = "Q{}document-properties"
            val pipe = wi.pipe()
            pipe.setReadablePort(expr.primaryOutput()!!)
            newSteps.addAll(exprSteps)
        }

        docStep.documentProperties = documentProperties
        docStep.parameters = parameters
        docStep.contentType = contentType

        //  docStep.depends.addAll(findStep().depends)

        docStep.elaborate()
        docStep.staticAnalysis(context!!)

        //docStep.stepDepends(staticContext)

        val output = docStep.primaryOutput()!!
        output.sequence = false
        if (docStep.contentType == null) {
            output.contentTypes = MediaType.XML_OR_HTML
        } else {
            output.contentTypes = listOf(docStep.contentType!!)
        }

        newSteps.add(docStep)
        return newSteps
    }
}