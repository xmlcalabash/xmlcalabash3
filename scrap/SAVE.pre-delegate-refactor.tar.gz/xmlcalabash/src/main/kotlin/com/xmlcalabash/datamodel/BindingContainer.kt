package com.xmlcalabash.datamodel

import net.sf.saxon.s9api.QName
import net.sf.saxon.s9api.XdmNode

open class BindingContainer(parent: XProcInstruction, instructionType: QName): XProcInstruction(parent, parent.stepConfig.newInstance(false), instructionType) {
    override fun staticAnalysis(context: InstructionStaticContext) {
        for (child in children) {
            child.staticAnalysis(context)
        }
    }

    internal fun promoteHref(href: XProcExpression) {
        val doc = DocumentInstruction(this, href)
        _children.add(doc)
    }

    internal fun promotePipe(pipe: String) {
        if (pipe.trim().isEmpty()) {
            return // Why is this allowed anyway
        }

        for (token in pipe.split("\\s+".toRegex())) {
            val pos = token.indexOf('@')
            if (pos >= 0) {
                val port = token.substring(0, pos)
                val step = token.substring(pos + 1)
                if (port.isEmpty()) {
                    _children.add(PipeInstruction(this, step, null))
                } else if (step.isEmpty()) {
                    _children.add(PipeInstruction(this, null, port))
                } else {
                    _children.add(PipeInstruction(this, step, port))
                }
            } else {
                _children.add(PipeInstruction(this, null, token))
            }
        }
    }

    // ============================================================

    open fun empty(): EmptyInstruction {
        val empty = EmptyInstruction(this)
        _children.add(empty)
        return empty
    }

    open fun document(href: XProcExpression): DocumentInstruction {
        val doc = DocumentInstruction(this, href)
        _children.add(doc)
        return doc
    }

    open fun pipe(): PipeInstruction {
        val pipe = PipeInstruction(this)
        _children.add(pipe)
        return pipe
    }

    open fun inline(documentNode: XdmNode): InlineInstruction {
        val inline = InlineInstruction(this, documentNode)
        _children.add(inline)
        return inline
    }
}