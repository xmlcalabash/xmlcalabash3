package com.xmlcalabash.datamodel

import com.xmlcalabash.namespace.NsCx
import com.xmlcalabash.util.ValueTemplateFilter

class AtomicInlineStepInstruction(parent: XProcInstruction, val filter: ValueTemplateFilter, name: String?): AtomicStepInstruction(parent, NsCx.inline, name) {
    var contentType: MediaType? = null
    var encoding: String? = null
}