package com.xmlcalabash.datamodel

import com.xmlcalabash.namespace.NsCx

class AtomicDocumentStepInstruction(parent: XProcInstruction, name: String?): AtomicStepInstruction(parent, NsCx.document, name) {
    var contentType: MediaType? = null
    lateinit var documentProperties: XProcExpression
    lateinit var parameters: XProcExpression
}