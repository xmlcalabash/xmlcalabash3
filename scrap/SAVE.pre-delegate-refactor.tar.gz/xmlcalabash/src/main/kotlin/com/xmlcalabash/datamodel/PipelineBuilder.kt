package com.xmlcalabash.datamodel

import com.xmlcalabash.config.PipelineConfiguration
import com.xmlcalabash.xprocparser.PipelineParser
import com.xmlcalabash.xprocparser.StepConfiguration

class PipelineBuilder internal constructor(val pipelineConfiguration: PipelineConfiguration) {
    fun newPipelineParser(): PipelineParser {
        return PipelineParser(pipelineConfiguration)
    }

    fun newDeclareStep(name: String?): DeclareStepInstruction {
        val stepConfig = StepConfiguration.getInstance(pipelineConfiguration).newInstance()
        return DeclareStepInstruction(null, stepConfig, name ?: "!declstep_${stepConfig.pipelineConfig.nextId}")
    }

    fun newLibrary(): LibraryInstruction {
        val stepConfig = StepConfiguration.getInstance(pipelineConfiguration).newInstance()
        return LibraryInstruction(stepConfig)
    }
}