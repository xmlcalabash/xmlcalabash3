package com.xmlcalabash.datamodel

import com.xmlcalabash.exceptions.XProcError
import com.xmlcalabash.namespace.NsCx
import com.xmlcalabash.namespace.NsP
import net.sf.saxon.s9api.QName

class PipelineInstruction(parent: DeclareStepInstruction, name: String?): CompoundContainer(parent, NsCx.pipeline, name) {
    override val contentModel = anySteps + mapOf(NsP.withInput to '*', NsP.output to '*', NsP.withOption to '*')

    override fun staticAnalysis(context: InstructionStaticContext) {
        context.inscopeStepNames.clear()
        super.staticAnalysis(context)

        context.addInscopeStepName(this)
        for (child in children.filterIsInstance<XProcStepInstruction>()) {
            context.addInscopeStepName(child)
        }

        stepConfig.inscopeStepNames = context.inscopeStepNames

        if (context.drp != null) {
            context.drp = namedInput(context.drp!!.port)
        }

        for (child in children) {
            when (child) {
                is WithInputInstruction, is OutputInstruction -> {
                    val portDecl = child as PortBindingContainer
                    portDecl.staticAnalysis(context.copy())
                }
                is OptionInstruction -> {
                    child.staticAnalysis(context.copy())
                    context.addInscopeVariable(child)
                }
                is VariableInstruction -> {
                    child.staticAnalysis(context.copy())
                    context.addInscopeVariable(child)
                }
                is XProcStepInstruction -> {
                    child.staticAnalysis(context.copy())
                    context.drp = child.primaryOutput()
                }
                else -> {
                    throw XProcError.xiImpossible("Unexpected child: ${child}").exception()
                }
            }
        }

        val lastStep = children.filterIsInstance<XProcStepInstruction>().last()
        for (output in outputs()) {
            if (output.children.isEmpty()) {
                val result = lastStep.primaryOutput()
                if (result == null) {
                    reportError(XProcError.xsNoOutputConnection(output.port))
                } else {
                    val pipe = output.pipe()
                    pipe.setReadablePort(result)
                }
            }
        }
    }

    override fun rewrite() {
        val newChildren = mutableListOf<XProcInstruction>()
        for (child in children) {
            when (child) {
                is VariableInstruction -> {
                    if (child.staticValue == null) {
                        val newSteps = child.promoteToStep(this)
                        val last = newSteps.last()
                        child._withOutput = last.primaryOutput() as WithOutputInstruction
                        newChildren.addAll(newSteps)
                    }
                }
                is XProcStepInstruction -> {
                    val newSteps = mutableListOf<AtomicStepInstruction>()
                    for (input in child.inputs()) {
                        val connChildren = input._children.toList()
                        input._children.clear()
                        for (conn in connChildren) {
                            val newConnSteps = (conn as ConnectionInstruction).promoteToStep(this)
                            if (newConnSteps.isEmpty()) {
                                input._children.add(conn)
                            } else {
                                val last = newConnSteps.last()
                                val pipe = input.pipe()
                                pipe.setReadablePort(last.primaryOutput()!!)
                            }
                            newSteps.addAll(newConnSteps)
                        }
                    }
                    newChildren.addAll(newSteps)
                    newChildren.add(child)
                }
                else -> {
                    newChildren.add(child)
                }
            }
        }

        _children.clear()
        _children.addAll(newChildren)
    }

    internal fun option(name: QName): OptionInstruction {
        val option = OptionInstruction(this, name)
        _children.add(option)
        return option
    }
}