package com.xmlcalabash.datamodel

import com.xmlcalabash.exceptions.XProcError
import com.xmlcalabash.namespace.NsP
import com.xmlcalabash.xprocparser.StepConfiguration
import net.sf.saxon.s9api.QName

class DeclareStepInstruction(parent: XProcInstruction?, stepConfig: StepConfiguration, val stepName: String? = null): StepContainer(parent, stepConfig, NsP.declareStep, null) {
    constructor(stepConfig: StepConfiguration, type: QName, name: String? = null): this(null, stepConfig, name) {
        this.type = type
    }
    constructor(parent: XProcInstruction, name: String? = null): this(parent, parent.stepConfig.newInstance(), name)
    constructor(parent: XProcInstruction, type: QName, name: String? = null): this(parent, parent.stepConfig.newInstance(), name) {
        this.type = type
    }

    private val declaredSteps = mutableListOf<DeclareStepInstruction>()
    internal var pipeline: PipelineInstruction? = PipelineInstruction(this, stepName)

    var type: QName? = null
        set(value) {
            checkOpen()
            field = value
        }

    var visibility: Visibility? = null
        set(value) {
            checkOpen()
            field = value
        }

    val isAtomic: Boolean
        get() {
            if (pipeline == null) {
                return true
            }
            for (child in pipeline!!.children) {
                when (child) {
                    is WithInputInstruction, is OutputInstruction, is OptionInstruction -> Unit
                    else -> return false
                }
            }
            return true
        }

    override fun elaborate() {
        super.elaborate()

        val inputs = children.filterIsInstance<InputInstruction>()
        if (inputs.size == 1) {
            val input = inputs.first()
            input.primary = input.primary != false
            pipeline!!.namedInput(input.port)!!.primary = input.primary
        }

        val outputs = children.filterIsInstance<OutputInstruction>()
        if (outputs.size == 1) {
            val output = outputs.first()
            output.primary = output.primary != false
            pipeline!!.namedOutput(output.port)!!.primary = output.primary
        }
        for (output in outputs) {
            val poutput = pipeline!!.namedOutput(output.port)!!
            for (conn in output.children) {
                conn._parent = poutput
                poutput._children.add(conn)
            }
            output._children.clear()
        }

        if (isAtomic) {
            pipeline = null
            return
        }

        pipeline!!.elaborate()

        if (pipeline!!.children.filterIsInstance<XProcStepInstruction>().isEmpty()) {
            reportError(XProcError.xsNoSteps())
        }
    }

    override fun staticAnalysis(context: InstructionStaticContext) {
        super.staticAnalysis(context)

        for (child in children.filterIsInstance<DeclareStepInstruction>()) {
            child.staticAnalysis(context.copy())
            declaredSteps.add(child)
        }

        val outputs = children.filterIsInstance<OutputInstruction>()
        var primaryOutput: PortBindingContainer? = null
        for (output in outputs) {
            if (output.primary == true) {
                if (primaryOutput != null) {
                    reportError(XProcError.xsMultiplePrimaryInputPorts(output.port))
                }
                primaryOutput = output
            }
        }

        val inputs = children.filterIsInstance<InputInstruction>()
        context.drp = null
        for (input in inputs) {
            if (input.primary == true) {
                if (context.drp != null) {
                    reportError(XProcError.xsMultiplePrimaryInputPorts(input.port))
                }
                context.drp = input
            }
        }

        if (isAtomic) {
            return
        }

        pipeline!!.staticAnalysis(context)
    }

    override fun rewrite() {
        for (decl in declaredSteps) {
            decl.rewrite()
        }

        if (isAtomic) {
            return
        }

        pipeline!!.rewrite()
    }

    fun getInputs(): List<InputInstruction> {
        return children.filterIsInstance<InputInstruction>()
    }

    fun getPrimaryInput(): InputInstruction? {
        for (input in getInputs()) {
            if (input.primary == true) {
                return input
            }
        }
        return null
    }

    fun getInput(port: String): InputInstruction? {
        for (input in children.filterIsInstance<InputInstruction>()) {
            if (input.port == port) {
                return input
            }
        }
        return null
    }

    fun getOutputs(): List<OutputInstruction> {
        return children.filterIsInstance<OutputInstruction>()
    }

    fun getPrimaryOutput(): OutputInstruction? {
        for (output in getOutputs()) {
            if (output.primary == true) {
                return output
            }
        }
        return null
    }

    fun getOutput(port: String): OutputInstruction? {
        for (output in children.filterIsInstance<OutputInstruction>()) {
            if (output.port == port) {
                return output
            }
        }
        return null
    }

    fun getOption(name: QName): OptionInstruction? {
        for (opt in children.filterIsInstance<OptionInstruction>()) {
            if (opt.name == name) {
                return opt
            }
        }
        return null
    }

    // ============================================================

    override fun directlyExported(visited: MutableSet<StepContainer>) {
        if (visited.contains(this)) {
            return
        }

        //println("Computing directly exported for ${this}")
        visited.add(this)

        exports.clear()
        if (type != null && visibility != Visibility.PRIVATE) {
            exports[type!!] = this
        }

        for (child in children.filterIsInstance<DeclareStepInstruction>()) {
            child.directlyExported(visited)
        }

        for (container in imported) {
            container.directlyExported(visited)
        }
    }

    override fun visibleInside(visited: MutableSet<StepContainer>) {
        if (visited.contains(this)) {
            return
        }
        visited.add(this)

        //println("Computed visible inside for ${this}")

        if (type != null) {
            stepConfig.addVisibleStep(type!!, this)
        }

        for (child in children.filterIsInstance<DeclareStepInstruction>().filter { it.type != null }) {
            stepConfig.addVisibleStep(child.type!!, child)
        }

        for (child in imported) {
            traverse(setOf(), child)
        }

        for (child in children.filterIsInstance<DeclareStepInstruction>()) {
            child.visibleInside(visited)
        }

        for (child  in imported) {
            child.visibleInside(visited)
        }
    }

    // ============================================================

    fun addImportFunctions(import: ImportFunctionsInstruction) {
        val last = children.lastOrNull()
        if (last == null || last is ImportFunctionsInstruction) {
            _children.add(import)
            return
        }

        import.reportError(XProcError.xsInvalidElement(import.instructionType))
    }

    override fun addIOType(instruction: XProcInstruction) {
        val last = children.lastOrNull()
        if (last == null || last is ImportFunctionsInstruction
            || last is InputInstruction || last is OutputInstruction || last is OptionInstruction) {
            _children.add(instruction)
            return
        }
        instruction.reportError(XProcError.xsInvalidElement(instruction.instructionType))
    }

    fun input(port: String, primary: Boolean?, sequence: Boolean?): InputInstruction {
        val input = InputInstruction(this, port, primary, sequence)
        addIOType(input)
        pipeline!!.withInput(port)
        return input
    }

    fun output(port: String, primary: Boolean?, sequence: Boolean?): OutputInstruction {
        val output = OutputInstruction(this, port, primary, sequence)
        addIOType(output)
        pipeline!!.output(port)
        return output
    }

    override fun option(name: QName): OptionInstruction {
        return pipeline!!.option(name)
    }

    fun variable(name: QName): VariableInstruction {
        return pipeline!!.variable(name)
    }

    fun declareStep(name: String?): DeclareStepInstruction {
        val last = children.lastOrNull()
        if (last == null || last is ImportFunctionsInstruction
            || last is InputInstruction || last is OutputInstruction || last is OptionInstruction
            || last is DeclareStepInstruction) {
            val decl = DeclareStepInstruction(this, name ?: "!declstep_${stepConfig.pipelineConfig.nextId}")
            _children.add(decl)
            return decl
        }
        throw XProcError.xsInvalidElement(NsP.declareStep).exception()
    }

    fun forEach(name: String?): ForEachInstruction {
        return pipeline!!.forEach(name)
    }

    fun viewport(name: String?): ViewportInstruction {
        return pipeline!!.viewport(name)
    }

    fun choose(name: String?): ChooseInstruction {
        return pipeline!!.choose(name)
    }

    fun ifInstruction(name: String?): IfInstruction {
        return pipeline!!.ifInstruction(name)
    }

    fun group(name: String?): GroupInstruction {
        return pipeline!!.group(name)
    }

    fun tryInstruction(name: String?): TryInstruction {
        return pipeline!!.tryInstruction(name)
    }

    fun atomicStep(type: QName, name: String?): AtomicStepInstruction {
        return pipeline!!.atomicStep(type, name)
    }

    override fun dump(depth: Int) {
        print("".padEnd(depth, ' '))
        println(this)

        for (child in imported) {
            dumpImports(depth + 2, child)
        }

        for (decl in declaredSteps) {
            decl.dump(depth + 2)
        }

        for (child in children) {
            if (child !is DeclareStepInstruction) {
                child.dump(depth + 2)
            }
        }

        if (!isAtomic) {
            pipeline!!.dump(depth+2)
        }
    }

    override fun toString(): String {
        if (type == null) {
            if (name.startsWith("!")) {
                return "${instructionType}/${id}"
            }
            return "${instructionType}/${id} \"${name}\""
        }
        if (name.startsWith("!")) {
            return "${instructionType}/${id}: ${type}"
        }
        return "${instructionType}/${id}: ${type} \"${name}\""
    }
}