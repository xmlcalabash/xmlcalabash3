package com.xmlcalabash.graph

import com.xmlcalabash.datamodel.*
import com.xmlcalabash.exceptions.XProcError
import com.xmlcalabash.xprocparser.XProcStepContainer

class AtomicNode private constructor(val graph: Graph, step: AtomicStepInstruction): Node(step) {
    init {
        graph.nodes[step] = this
    }

    companion object {
        fun build(graph: Graph, step: AtomicStepInstruction): AtomicNode {
            val node = AtomicNode(graph, step)
            return node
        }
    }

    override fun addEdges() {
        for (child in step.children.filterIsInstance<WithInputInstruction>()) {
            for (conn in child.children) {
                when (conn) {
                    is PipeInstruction -> {
                        val from = graph.nodes[conn.readablePort!!.parent]!!
                        val to = graph.nodes[step]!!
                        graph.addEdge(from, conn.port!!, to, child.port)
                    }
                    else -> {
                        throw XProcError.xiImpossible("Connection is not a pipe: ${conn}").exception()
                    }
                }
            }
        }
    }

    override fun toString(): String {
        return step.toString()
    }
}