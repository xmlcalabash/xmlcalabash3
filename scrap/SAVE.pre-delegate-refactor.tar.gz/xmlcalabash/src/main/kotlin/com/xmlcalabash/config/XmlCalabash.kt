package com.xmlcalabash.config

import com.xmlcalabash.datamodel.PipelineBuilder
import net.sf.saxon.Configuration

class XmlCalabash private constructor(): XProcConfiguration {
    private lateinit var _saxonConfig: SaxonConfiguration
    //private lateinit var _documentManager: DocumentManager
    //private lateinit var _xprocOptions: XmlCalabashOptions

    companion object {
        fun getInstance(): XmlCalabash {
            return getInstance(Configuration.newLicensedConfiguration())
        }

        fun getInstance(config: Configuration): XmlCalabash {
            val globalConfiguration = XmlCalabash()
            globalConfiguration._saxonConfig = SaxonConfiguration.getInstance(config)
            //globalConfiguration._documentManager = DocumentManager()
            //globalConfiguration._xprocOptions = XmlCalabashOptions()
            return globalConfiguration
        }
    }

    fun newPipelineBuilder(): PipelineBuilder {
        val config = PipelineConfiguration.getInstance(this)
        return PipelineBuilder(config)
    }

    override fun saxonConfiguration(): SaxonConfiguration {
        return _saxonConfig
    }

    /*
    override fun documentManager(): DocumentManager {
        TODO("Not yet implemented")
    }

    override fun xprocOptions(): XmlCalabashOptions {
        TODO("Not yet implemented")
    }
     */
}