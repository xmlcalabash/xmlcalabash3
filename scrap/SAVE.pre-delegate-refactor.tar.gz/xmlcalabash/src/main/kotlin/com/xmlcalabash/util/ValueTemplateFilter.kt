package com.xmlcalabash.util

import com.xmlcalabash.documents.XProcDocument
import net.sf.saxon.s9api.QName
import net.sf.saxon.s9api.XdmNode
import net.sf.saxon.s9api.XdmValue

interface ValueTemplateFilter {
    fun expandStaticValueTemplates(initialExpand: Boolean, staticBindings: Map<QName, XdmValue>): XdmNode
    fun expandValueTemplates(contextItem: XProcDocument?, bindings: Map<QName,Any>): XdmNode
    fun getNode(): XdmNode
    fun isStatic(): Boolean
    fun usesContext(): Boolean
    fun usesVariables(): Set<QName>
    fun usesFunctions(): Set<QName>
}