package com.xmlcalabash.datamodel

import com.xmlcalabash.exceptions.XProcError
import com.xmlcalabash.xprocparser.StepConfiguration
import net.sf.saxon.om.NamespaceUri
import net.sf.saxon.s9api.QName
import net.sf.saxon.s9api.XdmValue
import java.net.URI

abstract class StepContainer(parent: XProcInstruction?, stepConfig: StepConfiguration, instructionType: QName, name: String?): NamedInstruction(parent, stepConfig, instructionType, name) {
    internal val imported = mutableListOf<StepContainer>()
    internal val exports = mutableMapOf<QName, DeclareStepInstruction>()

    val baseUri: URI?
        get() = stepConfig.baseUri

    var psviRequired: Boolean? = null
        set(value) {
            checkOpen()
            field = value
        }

    var xpathVersion: Double? = null
        set(value) {
            checkOpen()
            field = value
        }

    private val _excludeInlineNamespaces = mutableSetOf<NamespaceUri>()
    var excludeInlineNamespaces: Set<NamespaceUri>
        get() = _excludeInlineNamespaces
        set(value) {
            checkOpen()
            _excludeInlineNamespaces.clear()
            _excludeInlineNamespaces.addAll(value)
        }

    var version: Double? = null
        set(value) {
            checkOpen()
            field = value
        }

    internal abstract fun addIOType(instruction: XProcInstruction)

    open fun option(name: QName): OptionInstruction {
        val option = OptionInstruction(this, name)
        addIOType(option)
        return option
    }

    fun option(name: QName, staticValue: XdmValue): OptionInstruction {
        val option = OptionInstruction(this, name)
        option.select = XProcExpression.constant(stepConfig, staticValue)
        option.static = true
        addIOType(option)
        return option
    }

    internal abstract fun directlyExported(visited: MutableSet<StepContainer>)
    internal abstract fun visibleInside(visited: MutableSet<StepContainer>)

    internal fun validate() {
        if (this !is StandardLibraryInstruction) {
            dump(0)
        }

        // Work out what step types are visible where. Note that we don't have to take special
        // care to avoid "duplicate" imports because those will be the same declare step
        // instruction objects.
        resolveImportsAndExports()

        elaborate()
        if (!stepConfig.hasErrors) {
            staticAnalysis(InstructionStaticContext(stepConfig))
        }
        if (!stepConfig.hasErrors) {
            rewrite()
        }
        println("now what?")
        if (this !is StandardLibraryInstruction) {
            dump(0)
        }
    }

    protected fun resolveImportsAndExports() {
        // Work out what's directly exported by each container
        directlyExported(mutableSetOf())
        visibleInside(mutableSetOf())
    }

    protected fun traverse(visited: Set<StepContainer>, import: StepContainer) {
        if (visited.contains(import)) {
            return
        }

        for ((name, decl) in import.exports) {
            stepConfig.addVisibleStep(name, decl)
        }

        for (child in imported) {
            traverse(visited + import, child)
        }
    }

    override fun staticAnalysis(context: InstructionStaticContext) {
        if (version == null) {
            version = 3.0
        }
        if (version != 3.0) {
            reportError(XProcError.xsUnsupportedVersion(version!!))
        }
    }

    fun addImportLibrary(container: StepContainer) {
        stepConfig.pipelineConfig.importedContainers.add(container)
        imported.add(container)
    }

    override fun dump(depth: Int) {
        print("".padEnd(depth, ' '))
        println(this)
        for (child in imported) {
            dumpImports(depth + 2, child)
        }
        for (child in children) {
            child.dump(depth + 2)
        }
    }

    protected fun dumpImports(depth: Int, child: StepContainer, visited: Set<StepContainer> = setOf()) {
        print("".padEnd(depth, ' '))
        print(child)
        if (visited.contains(child)) {
            println(" (recursive)")
            return
        } else {
            println("")
        }
        for (gchild in child.imported) {
            dumpImports(depth + 2, gchild, visited + child)
        }
        for (gchild in child.children) {
            gchild.dump(depth + 2)
        }
    }
}