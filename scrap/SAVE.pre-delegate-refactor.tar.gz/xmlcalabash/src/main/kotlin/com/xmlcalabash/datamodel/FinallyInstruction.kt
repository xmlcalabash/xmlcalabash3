package com.xmlcalabash.datamodel

import com.xmlcalabash.namespace.NsP

class FinallyInstruction(parent: XProcInstruction, name: String?): CompoundContainer(parent, NsP.finally, name) {
    override val contentModel = anySteps + mapOf(NsP.withInput to '0', NsP.output to '*')
}