package com.xmlcalabash.parsers

import net.sf.saxon.s9api.QName

data class XPathExpressionDetails(
    val errors: Boolean,
    val variableRefs: Set<QName>,
    val functionRefs: Set<QName>,
    val contextRef: Boolean
)