package com.xmlcalabash.datamodel

import com.xmlcalabash.namespace.NsCx
import com.xmlcalabash.namespace.NsP

class EmptyInstruction(parent: XProcInstruction) : ConnectionInstruction(parent, NsP.empty) {
    private var context: InstructionStaticContext? = null

    override fun staticAnalysis(context: InstructionStaticContext) {
        this.context = context.copy()
        super.staticAnalysis(context)
    }

    override fun promoteToStep(step: XProcInstruction): List<AtomicStepInstruction> {
        val emptyStep = AtomicStepInstruction(step, NsCx.empty, "!empty_${stepConfig.pipelineConfig.nextId}")
        emptyStep.staticAnalysis(context!!)

        val output = emptyStep.withOutput()
        output.port = "result"
        output.primary = true
        output.sequence = true
        output.contentTypes = MediaType.MATCH_ANY

        return listOf(emptyStep)
    }
}