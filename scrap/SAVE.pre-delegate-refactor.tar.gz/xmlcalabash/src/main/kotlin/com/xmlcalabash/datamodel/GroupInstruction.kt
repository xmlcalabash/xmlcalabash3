package com.xmlcalabash.datamodel

import com.xmlcalabash.namespace.NsP

class GroupInstruction(parent: XProcInstruction, name: String?): CompoundContainer(parent, NsP.group, name) {
    override val contentModel = anySteps + mapOf(NsP.withInput to '0', NsP.output to '*')
}