package com.xmlcalabash.config

interface XProcConfiguration{
    fun saxonConfiguration(): SaxonConfiguration
    //fun documentManager(): DocumentManager
    //fun xprocOptions(): XmlCalabashOptions
}