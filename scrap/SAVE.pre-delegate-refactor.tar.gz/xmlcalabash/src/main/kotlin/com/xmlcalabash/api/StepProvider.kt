package com.xmlcalabash.api

import com.xmlcalabash.runtime.XProcRuntime
import com.xmlcalabash.runtime.parameters.StepParameters
import net.sf.saxon.s9api.QName

interface StepProvider {
    fun initialize()
    fun stepAvailable(stepType: QName): Boolean
    fun stepProvider(runtime: XProcRuntime, stepType: QName, vararg args: Any?): () -> XProcStep
    fun stepProvider2(runtime: XProcRuntime, params: StepParameters): () -> XProcStep
}