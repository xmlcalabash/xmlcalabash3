package com.xmlcalabash.util

import com.xmlcalabash.documents.XProcDocument
import com.xmlcalabash.xprocparser.StepConfiguration
import net.sf.saxon.s9api.QName
import net.sf.saxon.s9api.XdmNode
import net.sf.saxon.s9api.XdmValue
import java.net.URI

class ValueTemplateFilterNone(val stepConfig: StepConfiguration, val encodedNode: XdmNode, val baseUri: URI): ValueTemplateFilter {
    override fun getNode(): XdmNode {
        return encodedNode
    }

    override fun isStatic(): Boolean {
        return true
    }

    override fun usesContext(): Boolean {
        return false
    }

    override fun usesVariables(): Set<QName> {
        return setOf()
    }

    override fun usesFunctions(): Set<QName> {
        return setOf()
    }

    override fun expandStaticValueTemplates(initialExpand: Boolean, staticBindings: Map<QName,XdmValue>): XdmNode {
        return encodedNode
    }

    override fun expandValueTemplates(contextItem: XProcDocument?, bindings: Map<QName,Any>): XdmNode {
        return encodedNode
    }
}