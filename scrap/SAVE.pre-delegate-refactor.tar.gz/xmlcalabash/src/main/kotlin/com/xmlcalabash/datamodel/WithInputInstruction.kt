package com.xmlcalabash.datamodel

import com.xmlcalabash.exceptions.XProcError
import com.xmlcalabash.namespace.NsP

class WithInputInstruction(parent: XProcInstruction): PortBindingContainer(parent, NsP.withInput) {
    constructor(parent: XProcInstruction, port: String) : this(parent) {
        this.port = port
    }

    override fun elaborate() {
        /*
        if (sequence != null) {
            reportError(XProcError.xsAttributeForbidden(Ns.sequence))
        }

        if (primary != null) {
            reportError(XProcError.xsAttributeForbidden(Ns.primary))
        }

        if (contentTypes.isNotEmpty()) {
            reportError(XProcError.xsAttributeForbidden(Ns.contentTypes))
        }

         */

        super.elaborate()
    }

    override fun staticAnalysis(context: InstructionStaticContext) {
        super.staticAnalysis(context)

        if (parent is PipelineInstruction) {
            // these are special
        } else {
            if (children.isEmpty()) {
                if (context.drp != null) {
                    val pipe = pipe()
                    pipe.staticAnalysis(context)
                } else {
                    reportError(XProcError.xsNoConnection(port))
                }
            }
        }
    }
}