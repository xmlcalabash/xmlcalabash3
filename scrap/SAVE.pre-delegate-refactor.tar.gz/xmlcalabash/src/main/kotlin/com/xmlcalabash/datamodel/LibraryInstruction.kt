package com.xmlcalabash.datamodel

import com.xmlcalabash.exceptions.XProcError
import com.xmlcalabash.namespace.NsP
import com.xmlcalabash.xprocparser.StepConfiguration

open class LibraryInstruction(stepConfig: StepConfiguration, containerImpl: StepContainerImpl): XProcInstruction(null, stepConfig, NsP.library), StepContainerInterface by containerImpl {

    override fun staticAnalysis(context: InstructionStaticContext) {
        super.staticAnalysis(context)

        /*
        for (child in children.filterIsInstance<DeclareStepInstruction>()) {
            if (child.type != null) {
                // If it's already present, then we must have self-imported it.
                if (!context.inscopeStepTypes.contains(child.type)) {
                    context.addInscopeStepType(child)
                }
            }
        }
         */

        for (child in children) {
            when (child) {
                is ImportFunctionsInstruction -> TODO("unimplemented")
                is OptionInstruction -> {
                    child.staticAnalysis(context.copy())
                    context.addInscopeVariable(child)
                }
                is DeclareStepInstruction -> {
                    child.staticAnalysis(context.copy())
                }
                else -> TODO("unexpected")
            }
        }
    }

    override fun rewrite() {
        for (child in children.filterIsInstance<DeclareStepInstruction>()) {
            child.rewrite()
        }
    }

    fun addIOType(instruction: XProcInstruction) {
        if (instruction is OptionInstruction) {
            if (!instruction.static) {
                instruction.reportError(XProcError.xsInvalidElement(instruction.instructionType))
            }
        }

        val last = children.lastOrNull()
        if (last == null || last is ImportFunctionsInstruction) {
            _children.add(instruction)
            return
        }

        instruction.reportError(XProcError.xsInvalidElement(instruction.instructionType))
    }

    // ============================================================

    override fun directlyExported(visited: MutableSet<StepContainer>) {
        if (visited.contains(this)) {
            return
        }

        //println("Computing directly exported for ${this}")
        visited.add(this)

        exports.clear()
        for (child in children.filterIsInstance<DeclareStepInstruction>()) {
            child.directlyExported(visited)
            if (child.type != null && child.visibility != Visibility.PRIVATE) {
                exports[child.type!!] = child
            }
        }

        for (container in imported) {
            container.directlyExported(visited)
        }
    }

    override fun visibleInside(visited: MutableSet<StepContainer>) {
        if (visited.contains(this)) {
            return
        }
        visited.add(this)

        //println("Computed visible inside for ${this}")

        stepConfig.inscopeStepTypes = mapOf()

        for (child in children.filterIsInstance<DeclareStepInstruction>().filter { it.type != null }) {
            stepConfig.addVisibleStep(child.type!!, child)
        }

        for (child in imported) {
            traverse(setOf(), child)
        }

        for (child in children.filterIsInstance<DeclareStepInstruction>()) {
            child.stepConfig.inscopeStepTypes = stepConfig.inscopeStepTypes
            child.visibleInside(visited)
        }

        for (child  in imported) {
            child.visibleInside(visited)
        }
    }

    // ============================================================

    /*
    fun addImportFunctions(import: ImportFunctionsInstruction) {
        if (children.filterIsInstance<OptionStaticInstruction>().isNotEmpty()
            || children.filterIsInstance<DeclareStepInstruction>().isNotEmpty()) {
            import.reportError(XProcError.xsInvalidElement(import.instructionType))
            return
        }
        _children.add(import)
    }

    fun addOption(option: OptionStaticInstruction) {
        if (children.filterIsInstance<DeclareStepInstruction>().isNotEmpty()) {
            option.reportError(XProcError.xsInvalidElement(option.instructionType))
            return
        }
        _children.add(option)
    }
    */

    fun addDeclareStep(decl: DeclareStepInstruction) {
        _children.add(decl)
    }

    override fun toString(): String {
        return "${instructionType}/${id}: ${stepConfig.baseUri}"
    }
}