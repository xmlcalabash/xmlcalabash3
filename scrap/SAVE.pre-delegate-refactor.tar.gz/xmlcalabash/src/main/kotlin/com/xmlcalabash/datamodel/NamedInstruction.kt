package com.xmlcalabash.datamodel

import com.xmlcalabash.xprocparser.StepConfiguration
import net.sf.saxon.s9api.QName

open class NamedInstruction(parent: XProcInstruction?, stepConfig: StepConfiguration, instructionType: QName, stepName: String?): XProcInstruction(parent, stepConfig, instructionType) {
    val name = stepName ?: "!${instructionType.localName}_${id}"

    fun inputs(): List<PortBindingContainer> {
        val list = mutableListOf<PortBindingContainer>()
        for (child in children.filter { it is InputInstruction || it is WithInputInstruction}) {
            list.add(child as PortBindingContainer)
        }
        return list
    }

    private fun primaryPort(ports: List<PortBindingContainer>): PortBindingContainer? {
        for (port in ports) {
            if (port.primary == true) {
                return port
            }
        }
        return null
    }

    private fun namedPort(ports: List<PortBindingContainer>, name: String): PortBindingContainer? {
        for (port in ports) {
            if (port.port == name) {
                return port
            }
        }
        return null
    }

    fun primaryInput(): PortBindingContainer? {
        return primaryPort(inputs())
    }

    fun namedInput(name: String): PortBindingContainer? {
        return namedPort(inputs(), name)
    }

    fun outputs(): List<PortBindingContainer> {
        val list = mutableListOf<PortBindingContainer>()
        for (child in children.filter { it is OutputInstruction || it is WithOutputInstruction}) {
            list.add(child as PortBindingContainer)
        }
        return list
    }

    fun primaryOutput(): PortBindingContainer? {
        return primaryPort(outputs())
    }

    fun namedOutput(name: String): PortBindingContainer? {
        return namedPort(outputs(), name)
    }
}