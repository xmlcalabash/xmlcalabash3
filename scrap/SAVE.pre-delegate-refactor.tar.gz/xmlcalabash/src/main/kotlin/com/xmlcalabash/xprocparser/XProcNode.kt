package com.xmlcalabash.xprocparser

import com.xmlcalabash.functions.StepAvailableFunction
import com.xmlcalabash.namespace.Ns
import com.xmlcalabash.namespace.NsP
import net.sf.saxon.om.NamespaceUri
import net.sf.saxon.s9api.*
import net.sf.saxon.trans.XPathException
import java.net.URI

open class XProcNode(val parser: PipelineParser, val stepConfig: StepConfiguration, node: XdmNode) {
    companion object {
        val DEBUG = false
    }

    internal val xml: XdmNode = node
    private val _attributes = mutableMapOf<QName,String>()
    private val _children = mutableListOf<XProcNode>()
    private val _pipeinfo = mutableListOf<XdmNode>()
    internal var useThis = true
    internal var useWhenExpression: String? = null
    private val _staticOptions = mutableMapOf<QName, XdmValue?>()
    private val _inscopeStepTypes = mutableMapOf<QName, Boolean>()
    protected val excludeNamespaceUris = mutableSetOf<NamespaceUri>()

    val staticOptions: Map<QName,XdmValue?>
        get() = _staticOptions

    val inscopeStepTypes: Set<QName>
        get() = _inscopeStepTypes.keys

    val nodeName = node.nodeName
    val baseUri: URI?
        get() = stepConfig.baseUri
    val attributes: Map<QName,String>
        get() = _attributes
    val children: List<XProcNode>
        get() = _children
    val pipeinfo: List<XdmNode>
        get() = _pipeinfo

    init {
        for (attr in node.axisIterator(Axis.ATTRIBUTE)) {
            _attributes[attr.nodeName] = attr.stringValue
            if ((node.nodeName.namespaceUri == NsP.namespace && attr.nodeName == Ns.useWhen)
                || (node.nodeName.namespaceUri != NsP.namespace && attr.nodeName == NsP.useWhen)) {
                useWhenExpression = attr.stringValue
            }
        }
    }

    protected open fun addChild(child: XProcNode) {
        _children.add(child)
        child.processChildren()
    }

    protected open fun processChildren() {
        val excludeNamespaces = mutableSetOf<NamespaceUri>()
        if (listOf(NsP.input, NsP.withInput, NsP.output, NsP.variable, NsP.withOption,
                NsP.declareStep, NsP.library, NsP.inline).contains(nodeName)) {
            val prefixes = attributes[Ns.excludeInlinePrefixes]
            if (prefixes != null) {
                excludeNamespaces.addAll(stepConfig.parseExcludeInlinePrefixes(prefixes))
            }
        }

        for (child in xml.axisIterator(Axis.CHILD)) {
            var childNode: XProcNode? = null

            when (child.nodeKind) {
                XdmNodeKind.ELEMENT -> {
                    when (child.nodeName) {
                        NsP.declareStep -> childNode = XProcDeclareStepNode(parser, stepConfig.newInstance(child), child)
                        NsP.library -> childNode = XProcLibraryNode(parser, stepConfig.newInstance(child), child)
                        NsP.import -> childNode = XProcImportNode(parser, stepConfig.newInstance(child, false), child)
                        NsP.inline -> childNode = XProcInlineNode(parser, stepConfig.newInstance(child, false), child)
                        NsP.option -> {
                            if ((xml.nodeName == NsP.declareStep || xml.nodeName == NsP.library)
                                && child.getAttributeValue(Ns.static) == "true"
                                && child.getAttributeValue(Ns.name) != null
                                && child.getAttributeValue(Ns.select) != null) {
                                val config = stepConfig.newInstance(child, false)
                                val name = config.parseQName(child.getAttributeValue(Ns.name)!!)
                                childNode = XProcOptionNode(parser, config, child, name, child.getAttributeValue(Ns.select))
                            } else {
                                childNode = XProcNode(parser, stepConfig.newInstance(child, false), child)
                            }
                        }
                        NsP.documentation -> Unit
                        NsP.pipeinfo -> {
                            _pipeinfo.add(child)
                        }
                        else -> {
                            if (listOf(NsP.input, NsP.withInput, NsP.output, NsP.variable, NsP.withOption).contains(xml.nodeName)) {
                                if (listOf(NsP.empty, NsP.document, NsP.pipe).contains(child.nodeName)) {
                                    childNode = XProcNode(parser, stepConfig.newInstance(child, false), child)
                                } else {
                                    childNode = XProcImplicitInlineNode(parser, stepConfig.newInstance(child, false), child)
                                }
                            } else {
                                childNode = XProcNode(parser, stepConfig.newInstance(child, false), child)
                            }
                        }
                    }
                }
                XdmNodeKind.TEXT -> {
                    if (child.stringValue.trim().isNotEmpty()) {
                        throw RuntimeException("Non-empty text node: ${child.stringValue}")
                    }
                }
                XdmNodeKind.COMMENT -> Unit
                XdmNodeKind.PROCESSING_INSTRUCTION -> Unit
                else -> throw RuntimeException("Unexpected node kind ${child.nodeKind}")
            }

            if (childNode != null) {
                childNode.excludeNamespaceUris.addAll(excludeNamespaceUris + excludeNamespaces)
                addChild(childNode)
            }
        }
    }

    open fun resolveConditionals(unconditional: Boolean, indent: String, currentStaticOptions: Map<QName, XdmValue?> = mapOf(), currentInscopeStepTypes: Map<QName, Boolean> = mapOf()) {
        _staticOptions.clear()
        _staticOptions.putAll(currentStaticOptions)
        _inscopeStepTypes.clear()
        _inscopeStepTypes.putAll(currentInscopeStepTypes)

        val nextIndent = if (DEBUG) "${indent}  " else indent

        if (DEBUG && indent == "") {
            println("============================================================")
        }
        if (useWhenExpression == null) {
            if (DEBUG) {
                println(resolveDisplay(indent))
            }
        } else {
            val value = resolveUseWhen(useWhenExpression!!)
            if (DEBUG) {
                if (value == null) {
                    println("${resolveDisplay(indent)}: ${useWhenExpression} -> inconclusive")
                } else {
                    println("${resolveDisplay(indent)}: ${useWhenExpression} => ${value}")
                }
            }
            if (value != null) {
                useWhenExpression = null
                useThis = value == true
            }
        }

        if (!useThis) {
            return
        }

        if (this is XProcStepContainer) {
            for ((type, cond) in findStepTypes(useWhenExpression == null)) {
                val always = cond || (_inscopeStepTypes[type] ?: false)
                _inscopeStepTypes[type] = always
            }
        }

        for (child in children) {
            child.resolveConditionals(unconditional, nextIndent, _staticOptions, _inscopeStepTypes)
            if (child.useThis) {
                when (child) {
                    is XProcOptionNode -> {
                        if (child.useWhenExpression == null) {
                            if (child.staticValue == null) {
                                val assignedValue = stepConfig.pipelineConfig.staticOptions[child.name]
                                child._staticValue = assignedValue ?: resolveExpression(child.select)
                                if (DEBUG) {
                                    if (child.staticValue == null) {
                                        println("${indent}    static: ${child.select} -> inconclusive")
                                    } else {
                                        println("${indent}    static: ${child.select} => ${child.staticValue}")
                                    }
                                }
                            }
                            if (_staticOptions.containsKey(child.name)) {
                                val curValue = _staticOptions[child.name]
                                if (curValue != null && child.staticValue != null) {
                                    throw RuntimeException("Shadowed static: ${child.name}")
                                } else {
                                    _staticOptions[child.name] = null
                                }
                            } else {
                                _staticOptions[child.name] = child.staticValue
                            }
                        } else {
                            _staticOptions[child.name] = null
                        }
                    }
                    is XProcImportNode -> {
                        if (child.container != null) {
                            child.container!!.resolveConditionals(unconditional && child.useWhenExpression == null, "${nextIndent}  ", _staticOptions, _inscopeStepTypes)
                        }
                    }
                    else -> Unit
                }
            }
        }
    }

    internal open fun resolveDisplay(indent: String): String {
        return "${indent}${nodeName}"
    }

    protected fun findConditionals(): Set<XProcNode> {
        val nodes = mutableSetOf<XProcNode>()
        if (useWhenExpression != null) {
            nodes.add(this)
        }
        for (child in children) {
            nodes.addAll(child.findConditionals())
            if (child is XProcImportNode && child.container != null) {
                nodes.addAll(child.container!!.findConditionals())
            }
        }
        return nodes
    }

    protected fun removeDeadConditionals() {
        if (!useThis) {
            return
        }

        val newChildren = mutableListOf<XProcNode>()
        for (child in children) {
            var keep: XProcNode? = null
            when (child) {
                is XProcImportNode -> {
                    if (child.container != null) {
                        if (child.useThis && child.container!!.useThis) {
                            keep = child
                            child.removeDeadConditionals()
                            child.container!!.removeDeadConditionals()
                        }
                    } else {
                        if (child.useThis) {
                            keep = child
                            child.removeDeadConditionals()
                        }
                    }
                }
                else -> {
                    if (child.useThis) {
                        keep = child
                        child.removeDeadConditionals()
                    }
                }
            }

            if (keep == null) {
                if (DEBUG) {
                    println("--- remove ${child.resolveDisplay("")}")
                }
            } else {
                newChildren.add(keep)
            }
        }

        _children.clear()
        _children.addAll(newChildren)
    }

    internal open fun computeInscopeStepTypes(inherited: Map<QName, VisibleStep>) {
        _inscopeStepTypes.clear()
        for ((name, value) in inherited) {
            _inscopeStepTypes[name] = !value.conditional
        }
        for (child in children) {
            child.computeInscopeStepTypes(inherited)
        }
    }

    private fun resolveUseWhen(expr: String): Boolean? {
        val context = ConditionalExecutionContext(stepConfig, _inscopeStepTypes)
        stepConfig.pipelineConfig.setExecutionContext(context)
        try {
            val selector = makeSelector(expr)
            val result = selector.effectiveBooleanValue()
            return result
        } catch (ex: Exception) {
            when (ex) {
                is ConditionalStepException -> Unit
                is SaxonApiException -> {
                    if (!conditionalOption(ex)) {
                        throw ex
                    }
                }
                else -> Unit // Just assume this will work better next time...
            }
        } finally {
            stepConfig.pipelineConfig.releaseExecutionContext()
        }
        return null
    }

    private fun resolveExpression(expr: String): XdmValue? {
        val context = ConditionalExecutionContext(stepConfig, _inscopeStepTypes)
        stepConfig.pipelineConfig.setExecutionContext(context)
        try {
            val selector = makeSelector(expr)
            val result = selector.evaluate()
            return result
        } catch (ex: Exception) {
            when (ex) {
                is ConditionalStepException -> Unit
                is SaxonApiException -> {
                    if (!conditionalOption(ex)) {
                        throw ex
                    }
                }
                else -> Unit // Just assume this will work better next time...
            }
        } finally {
            stepConfig.pipelineConfig.releaseExecutionContext()
        }
        return null
    }

    private fun conditionalOption(ex: SaxonApiException): Boolean {
        val cause = ex.cause
        val message = ex.message
        if (cause is XPathException && message != null) {
            val code = cause.showErrorCode()
            if (code == "XPST0008") {
                val pos = message.indexOf("\$")
                if (pos > 0) {
                    val name = message.substring(pos+1)
                    val qname = stepConfig.parseQName(name)
                        return _staticOptions.containsKey(qname)
                }
            }
        }
        return false
    }

    private fun makeSelector(expr: String): XPathSelector {
        val processor = stepConfig.saxonConfig.newProcessor()
        processor.registerExtensionFunction(StepAvailableFunction(stepConfig.pipelineConfig))

        val compiler = processor.newXPathCompiler()
        for ((prefix, uri) in stepConfig.inscopeNamespaces) {
            compiler.declareNamespace(prefix, uri.toString())
        }
        for ((name, value) in _staticOptions) {
            if (value != null) {
                compiler.declareVariable(name)
            }
        }
        val selector = compiler.compile(expr).load()
        for ((name, value) in _staticOptions) {
            if (value != null) {
                selector.setVariable(name, value)
            }
        }
        return selector
    }

    override fun toString(): String = nodeName.toString()
}