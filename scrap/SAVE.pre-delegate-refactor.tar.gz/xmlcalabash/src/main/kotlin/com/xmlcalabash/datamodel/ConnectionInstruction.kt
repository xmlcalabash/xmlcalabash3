package com.xmlcalabash.datamodel

import net.sf.saxon.s9api.QName

abstract class ConnectionInstruction(parent: XProcInstruction, instructionType: QName): XProcInstruction(parent, parent.stepConfig.newInstance(), instructionType) {
    override fun staticAnalysis(context: InstructionStaticContext) {
        // the buck stops here
    }

    abstract internal fun promoteToStep(step: XProcInstruction): List<AtomicStepInstruction>
}