package com.xmlcalabash.xprocparser

import com.xmlcalabash.namespace.NsP
import com.xmlcalabash.util.S9Api
import com.xmlcalabash.util.UriUtils
import net.sf.saxon.s9api.QName
import net.sf.saxon.s9api.XdmDestination
import net.sf.saxon.s9api.XdmNode
import org.xml.sax.InputSource
import java.net.URI
import javax.xml.transform.sax.SAXSource

abstract class XProcStepContainer(parser: PipelineParser, stepConfig: StepConfiguration, node: XdmNode): XProcNode(parser, stepConfig, node) {
    abstract val stepType: QName?

    internal val importedUris = mutableSetOf<URI>()
    internal val visible = mutableMapOf<QName, VisibleStep>()
    internal val exports = mutableMapOf<QName, VisibleStep>()

    init {
        if (node.baseURI != null) {
            importedUris.add(stepConfig.resolve(node.baseURI.toString()))
            if (stepConfig.baseUri != null) {
                stepConfig.baseUri = stepConfig.baseUri!!.resolve(node.baseURI)
            } else {
                stepConfig.baseUri = node.baseURI
            }
        }
    }

    override fun addChild(child: XProcNode) {
        super.addChild(child)

        if (child is XProcImportNode && child.href != null) {
            val href = child.href!!
            if (importedUris.contains(href)) {
                //println("Ignoring circular import: ${href}")
                return
            }

            val builder = child.stepConfig.processor.newDocumentBuilder()
            builder.isLineNumbering = true
            val destination = XdmDestination()

            try {
                // FIXME: DocumentManager
                val stream = href.toURL().openStream()
                val source = InputSource(stream)
                source.systemId = href.toString()
                builder.parse(SAXSource(source), destination)
                val doc = destination.xdmNode
                val root = S9Api.documentElement(doc)

                val stepConfig = child.stepConfig.newInstance(root)
                stepConfig.baseUri = UriUtils.cwdAsUri().resolve(href)
                val container: XProcStepContainer = when (root.nodeName) {
                    NsP.declareStep -> XProcDeclareStepNode(parser, stepConfig, root)
                    NsP.library -> XProcLibraryNode(parser, stepConfig, root)
                    else -> {
                        child.error = true
                        return
                    }
                }
                container.importedUris.addAll(importedUris)
                container.loadPipeline()
                child.container = container
                parser.importedContainers[href] = container
            } catch (ex: Exception) {
                child.error = true
            }
        }
    }

    fun loadPipeline() {
        processChildren()
    }

    fun findStepTypes(unconditional: Boolean): Map<QName, Boolean> {
        val stepTypes = mutableMapOf<QName, Boolean>()
        addStepType(stepTypes, stepType, unconditional)

        for (child in children) {
            when (child) {
                is XProcDeclareStepNode -> addStepType(stepTypes, child.stepType, unconditional && child.useWhenExpression == null)
                is XProcImportNode -> {
                    if (child.container != null) {
                        val types = child.container!!.findStepTypes(unconditional && child.useWhenExpression == null)
                        for ((type, cond) in types) {
                            addStepType(stepTypes, type, cond)
                        }
                    }
                }
                else -> Unit
            }
        }

        return stepTypes
    }

    private fun addStepType(types: MutableMap<QName, Boolean>, type: QName?, unconditional: Boolean) {
        if (type == null) {
            return
        }

        val always = unconditional || (types[type] ?: false)
        types[type] = always
    }

    fun resolveStaticStructure() {
        val conditionals = mutableSetOf<XProcNode>()
        conditionals.addAll(findConditionals())

        // N.B. Always go through at least once to resolve static options
        while (true) {
            val initialCount = conditionals.size

            parser.resolveImports()
            computeInscopeStepTypes(mapOf())

            resolveConditionals(useWhenExpression == null, "")
            removeDeadConditionals()

            conditionals.clear()
            conditionals.addAll(findConditionals())
            if (conditionals.isEmpty()) {
                parser.resolveImports()
                computeInscopeStepTypes(mapOf())
                return
            }

            val finalCount = conditionals.size
            if (finalCount == initialCount) {
                println("Stalled with ${finalCount} conditionals")
                for (node in conditionals) {
                    println("\t${node.resolveDisplay("")}: ${node.useWhenExpression}")
                }
                throw RuntimeException("stalled")
            }
        }
    }

    override fun computeInscopeStepTypes(inherited: Map<QName, VisibleStep>) {
        visible.clear()
        if (this is XProcDeclareStepNode) {
            if (stepType != null) {
                val current = visible[stepType!!]
                if (current == null || current.conditional) {
                    visible[stepType!!] = VisibleStep(this)
                }
            }
        }

        for (child in children.filterIsInstance<XProcImportNode>()) {
            val conditionalImport = child.useWhenExpression != null
            val container = parser.importedContainers[child.href]
            if (container != null) {
                for ((name, value) in container.exports) {
                    val current = visible[name]
                    if (current == null || current.conditional) {
                        value.conditional = conditionalImport
                        visible[name] = value
                    }
                }
            }
        }

        for (child in children.filterIsInstance<XProcDeclareStepNode>()) {
            if (child.stepType != null) {
                val current = visible[child.stepType!!]
                if (current == null || current.conditional) {
                    visible[child.stepType!!] = VisibleStep(child)
                }
            }
        }

        for (child in children) {
            child.computeInscopeStepTypes(visible)
        }
    }

    /*
    internal fun compileApis() {
        if (this is XProcDeclareStepNode) {
            compileApi()
        }

        for (child in children.filterIsInstance<XProcDeclareStepNode>()) {
            child.compileApi()
        }

        for (child in children.filterIsInstance<XProcImportNode>()) {
            if (child.container != null) {
                child.container!!.compileApis()
            }
        }
    }

     */
}