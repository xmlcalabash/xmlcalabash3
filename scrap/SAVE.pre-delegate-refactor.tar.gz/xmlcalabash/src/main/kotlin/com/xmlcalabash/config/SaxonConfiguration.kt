package com.xmlcalabash.config

import com.xmlcalabash.documents.XProcDocument
import com.xmlcalabash.runtime.XProcExecutionContext
import net.sf.saxon.Configuration
import net.sf.saxon.lib.ExtensionFunctionDefinition
import net.sf.saxon.s9api.Processor
import java.util.*

class SaxonConfiguration private constructor(val configuration: Configuration) {
    val processor = Processor(configuration)
    private val executables = mutableMapOf<Long, XProcExecutionContext>()

    val xpathVersion = "3.1"
    val psviSupported = processor.isSchemaAware
    var locale = Locale.getDefault().toString().replace("_", "-")

    private val extensionFunctions = mutableListOf<(SaxonConfiguration) -> ExtensionFunctionDefinition>()

    companion object {
        fun getInstance(configuration: Configuration): SaxonConfiguration {
            return SaxonConfiguration(configuration)
        }

        /*
        fun getInstance(staticConfig: XProcStaticConfiguration): SaxonConfiguration {
            val configuration = Configuration.newLicensedConfiguration()
            val saxonConfig = SaxonConfiguration(configuration)
            configureStandardFunctions(saxonConfig)
            saxonConfig.initialize()
            return saxonConfig
        }

        fun getInstance(configuration: Configuration, staticConfig: XProcStaticConfiguration): SaxonConfiguration {
            val saxonConfig = SaxonConfiguration(configuration)
            configureStandardFunctions(saxonConfig)
            saxonConfig.initialize()
            return saxonConfig
        }
         */

        private fun configureStandardFunctions(config: SaxonConfiguration) {
            /*
            config.extensionFunctions.add { cfg -> SystemPropertyFunction(cfg) }
            config.extensionFunctions.add { cfg -> IterationPositionFunction(cfg) }
            config.extensionFunctions.add { cfg -> IterationSizeFunction(cfg) }
            config.extensionFunctions.add { cfg -> DocumentPropertyFunction(cfg) }
            config.extensionFunctions.add { cfg -> DocumentPropertiesFunction(cfg) }
            config.extensionFunctions.add { cfg -> StepAvailableFunction(cfg) }
            config.extensionFunctions.add { cfg -> UrifyFunction(cfg) }
            config.extensionFunctions.add { cfg -> FunctionLibraryImportableFunction(cfg) }
            config.extensionFunctions.add { cfg -> ErrorFunction(cfg) }
             */
        }
    }

    fun newConfiguration(): SaxonConfiguration {
        val config = Configuration.newLicensedConfiguration()
        config.namePool = configuration.namePool
        config.documentNumberAllocator = configuration.documentNumberAllocator
        val saxonConfig = SaxonConfiguration(config)
        saxonConfig.extensionFunctions.addAll(extensionFunctions)
        saxonConfig.initialize()
        return saxonConfig
    }

    private fun initialize() {
        for (fn in extensionFunctions) {
            processor.registerExtensionFunction(fn(this))
        }
    }

    internal fun newProcessor(): Processor {
        return Processor(configuration)
    }

    fun getExecutionContext(): XProcExecutionContext? {
        //println("Get ${this}: ${executables[Thread.currentThread().id]} for ${Thread.currentThread().id}")

        return executables[Thread.currentThread().id]
    }

    fun setExecutionContext(dynamicContext: XProcExecutionContext) {
        //println("Set ${this}: ${dynamicContext} for ${Thread.currentThread().id}")

        executables[Thread.currentThread().id] = dynamicContext
    }

    fun releaseExecutionContext() {
        //println("Free ${this}: ${executables[Thread.currentThread().id]} for ${Thread.currentThread().id}")

        executables.remove(Thread.currentThread().id)
    }

    fun addProperties(doc: XProcDocument?) {
        if (doc == null) {
            return
        }
        executables[Thread.currentThread().id]!!.addProperties(doc)
    }

    fun removeProperties(doc: XProcDocument?) {
        if (doc == null) {
            return
        }
        executables[Thread.currentThread().id]!!.removeProperties(doc)
    }
}