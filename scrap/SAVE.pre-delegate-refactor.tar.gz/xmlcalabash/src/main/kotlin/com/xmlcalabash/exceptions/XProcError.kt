package com.xmlcalabash.exceptions

import com.xmlcalabash.datamodel.Location
import com.xmlcalabash.datamodel.MediaType
import com.xmlcalabash.documents.XProcDocument
import com.xmlcalabash.namespace.NsCx
import com.xmlcalabash.namespace.NsP
import net.sf.saxon.s9api.*
import java.net.URI

class XProcError private constructor(val code: QName, val variant: Int, val location: Location, val inputLocation: Location, vararg val details: Any) {
    companion object {
        private val errXD0036 = dynamicError(36)
        private val errXD0079 = dynamicError(79)

        fun staticError(code: Int): QName {
            return QName(NsP.errorNamespace, "err:XS${code.toString().padStart(4, '0')}")
        }

        fun dynamicError(code: Int): QName {
            return QName(NsP.errorNamespace, "err:XD${code.toString().padStart(4, '0')}")
        }

        fun stepError(code: Int): QName {
            return QName(NsP.errorNamespace, "err:XC${code.toString().padStart(4, '0')}")
        }

        fun static(code: Pair<Int, Int>, vararg details: Any): XProcError {
            val ecode = staticError(code.first)
            return XProcError(ecode, code.second, Location.NULL, Location.NULL, *details)
        }

        fun static(code: Int, vararg details: Any): XProcError = static(Pair(code, 1), *details)

        fun dynamic(code: Pair<Int,Int>, vararg details: Any): XProcError {
            val ecode = dynamicError(code.first)
            return XProcError(ecode, code.second, Location.NULL, Location.NULL, *details)
        }

        fun dynamic(code: Int, vararg details: Any): XProcError = dynamic(Pair(code, 1), *details)

        fun step(code: Pair<Int,Int>, vararg details: Any): XProcError {
            val ecode = stepError(code.first)
            return XProcError(ecode, code.second, Location.NULL, Location.NULL, *details)
        }

        fun step(code: Int, vararg details: Any): XProcError = step(Pair(code, 1), *details)

        fun internal(code: Pair<Int,Int>, vararg details: Any): XProcError {
            val ecode = QName(NsCx.errorNamespace, "cxerr:XI${code.first.toString().padStart(4, '0')}")
            return XProcError(ecode, code.second, Location.NULL, Location.NULL, *details)
        }

        fun internal(code: Int, vararg details: Any): XProcError = internal(Pair(code, 1), *details)

        // ====================================================================================

        fun xsLoop(name: String) = static(1, name)
        fun xsDuplicateStepName(name: String) = static(2, name)
        fun xsNotConnected(port: String) = static(Pair(3,1), port)
        fun xsNotConnected() = static(Pair(3,2))
        fun xsDuplicateOption(name: QName) = static(4, name)
        fun xsNoOutputConnection(name: String) = static(6, name)
        fun xsAttributeForbidden(name: QName) = static(Pair(8, 1), name)
        fun xsDuplicatePortName(name: String) = static(11, name)
        fun xsMultiplePrimaryOutputPorts(name: String) = static(14, name)
        fun xsNoSteps() = static(15)
        fun xsRequiredAndDefaulted(name: QName) = static(17, name)
        fun xsMissingRequiredOption(name: QName) = static(18, name)
        fun xsPortNotReadable(step: String) = static(Pair(22, 2), step)
        fun xsPortNotReadable(step: String, port: String) = static(Pair(22, 3), step, port)
        fun xsStepTypeInNoNamespace(type: QName) = static(Pair(25,1), type)
        fun xsStepTypeNotAllowed(type: QName) = static(Pair(25,2), type)
        fun xsMultiplePrimaryInputPorts(name: String) = static(30, name)
        fun xsNoSuchOption(name: QName) = static(31, name)
        fun xsNoConnection(name: String) = static(32, name)
        fun xsDuplicateStepType(name: QName) = static(36, name)
        fun xsTextNotAllowed(text: String) = static(37, text)
        fun xsMissingRequiredAttribute(name: QName) = static(38, name)
        fun xsPortNameNotAllowed() = static(43)
        fun xsMissingStepDeclaration(name: QName) = static(44, name)
        fun xsNotImportable(name: QName) = static(52, name)
        fun xsInvalidExcludePrefix() = static(Pair(57, 1))
        fun xsInvalidExcludePrefix(prefix: String) = static(Pair(57, 2), prefix)
        fun xsNoDefaultNamespace() = static(58)
        fun xsNotAPipeline(name: QName) = static(59, name)
        fun xsUnsupportedVersion(ver: Double) = static(60, ver)
        fun xsMissingVersion() = static(62)
        fun xsNoPrimaryInput() = static(65)
        fun xsPortNotReadable() = static(67)
        fun xsUnsupportedEncoding(encoding: String) = static(69, encoding)
        fun xsDuplicateStaticOption(name: QName) = static(71, name)
        fun xsDependsNotAStep(name: String) = static(Pair(73, 1), name)
        fun xsDependsNotReadable(step: String, port: String) = static(Pair(73, 2), step, port)
        fun xsDependsNotAllowed(name: String) = static(Pair(73, 3), name)
        fun xsWhenOrOtherwiseRequired() = static(74)
        fun xsTryWithoutSubpipeline() = static(Pair(75, 1))
        fun xsTryWithoutCatchOrFinally() = static(Pair(75, 2))
        fun xsTryWithMoreThanOneFinally() = static(Pair(75, 3))
        fun xsValueDoesNotSatisfyType(value: String, type: String) = static(77, value, type)
        fun xsInvalidImplicitInlineSiblings() = static(79)
        fun xsDuplicateWithOption(name: QName) = static(80, name)
        fun xsHrefAndChildren() = static(81)
        fun xsPipeAndChildren() = static(82)
        fun xsHrefAndPipe() = static(85)
        fun xsDuplicatePortDeclaration(port: String) = static(86, port)
        fun xsShadowStaticOption(name: QName) = static(88, name)
        fun xsEmptyNotAllowed() = static(89)
        fun xsInvalidPipeAttribute(token: String) = static(90, token)
        fun xsRequiredAndStatic(name: QName) = static(95, name)
        fun xsInvalidSequenceType(type: String) = static(96, type)
        fun xsAttributeNotAllowed(name: QName) = static(97, name)
        fun xsInvalidElement() = static(Pair(100,1))
        fun xsInvalidElement(name: QName) = static(Pair(100,2), name)
        fun xsInvalidImplicitInline(name: QName) = static(Pair(100,3), name)
        fun xsInvalidAttribute(name: QName) = static(Pair(100, 4), name)
        fun xsMissingRequiredElement(name: QName) = static(Pair(100, 5), name)
        fun xsInvalidValues(value: String) = static(101, value)
        fun xsDifferentPrimaryOutputs(port: String) = static(Pair(102, 1), port)
        fun xsDifferentPrimaryOutputs() = static(Pair(102, 2))
        fun xsImportFunctionsRequiresEE() = static(Pair(104, 1))
        fun xsImportFunctionsFailed(msg: String) = static(Pair(104, 2), msg)
        fun xsImportFunctionsFailed(code: QName, msg: String) = static(Pair(104, 3), code, msg)
        fun xsImportFunctionsUnloadable(code: QName, msg: String) = static(Pair(106, 1), msg)
        fun xsImportFunctionsUnloadable(uri: URI) = static(Pair(106, 2), uri)
        fun xsXPathStaticError(msg: String) = static(Pair(107,1), msg)
        fun xsXPathStaticError(name: QName) = static(Pair(107,2), name)
        fun xsPrimaryOutputRequiredOnIf() = static(108)
        fun xsLibraryOptionsMustBeStatic(name: QName) = static(109, name)
        fun xsInvalidContentType(value: String) = static(111, value)
        fun xsPrimaryOutputOnFinally() = static(Pair(112,1))
        fun xsPrimaryOutputOnFinally(port: String) = static(Pair(112,2), port)
        fun xsInvalidExpandText(value: String) = static(113, value)
        fun xsNoSuchPort(port: String) = static(114, port)
        fun xsUseWhenDeadlock(cycle: String) = static(115, cycle)

        fun xdSequenceForbidden() = dynamic(Pair(1,1))
        fun xdEmptySequenceForbidden() = dynamic(Pair(1,2))
        fun xdInputSequenceForbidden(port: String) = dynamic(6, port)
        fun xdOutputSequenceForbidden(port: String) = dynamic(7, port)
        fun xdViewportOnAttribute(expr: String) = dynamic(10, expr)
        fun xdDoesNotExist(path: String) = dynamic(11, path)
        fun xdInvalidQName(name: String) = dynamic(15, name)
        fun xdInvalidSelection(name: QName) = dynamic(Pair(16, 1), name)
        fun xdInvalidFunctionSelection() = dynamic(Pair(16, 2))
        fun xdValueNotAllowed(value: XdmValue, allowed: List<XdmAtomicValue>) = dynamic(19, value, allowed)
        fun xdValueDoesNotSatisfyType(value: String, type: String) = dynamic(28, value, type)
        fun xdStepFailed(message: String) = dynamic(30, message)
        fun xdBadType(value: String, type: String) = dynamic(Pair(36,1), value, type)
        fun xdBadType(value: String, type: ItemType) = dynamic(Pair(36,2), value, type)
        fun xdBadType(name: QName, value: String, type: String) = dynamic(Pair(36,3), name, value, type)
        fun xdBadType(message: String) = dynamic(Pair(36,4), message)
        fun xdNoInputContentType() = dynamic(Pair(38,1))
        fun xdBadInputContentType(type: String) = dynamic(Pair(38, 2), type)
        fun xdNoOutputContentType() = dynamic(Pair(42,1))
        fun xdBadOutputContentType(type: String) = dynamic(Pair(42, 2), type)
        fun xdNotWellFormed() = dynamic(49)
        fun xdInvalidAvtResult(result: String) = dynamic(51, result)
        fun xdEncodingWithXmlOrHtml(encoding: String) = dynamic(54, encoding)
        fun xdEncodingRequired(charset: String) = dynamic(55, charset)
        fun xdMarkupForbiddenWithEncoding(encoding: String) = dynamic(56, encoding)
        fun xdNotWellFormedJson() = dynamic(57)
        fun xdNotWellFormedHtml() = dynamic(60)
        fun xdInvalidDocumentPropertyQName(value: String) = dynamic(61, value)
        fun xdContentTypesDiffer(contentType: String, propType: String) = dynamic(62, contentType, propType)
        fun xdMarkupForbidden() = dynamic(63)
        fun xdInvalidUri(uri: String) = dynamic(64, uri)
        fun xdInvalidRelativeTo(uri: String) = dynamic(64, uri)
        fun xdInlineContextSequence() = dynamic(65)
        fun xdInvalidPrefix(name: String, prefix: String) = dynamic(69, name, prefix)
        fun xdInvalidSerialization() = dynamic(Pair(70, 1))
        fun xdInvalidSerialization(value: String) = dynamic(Pair(70, 2), value)
        fun xdViewportNotXml() = dynamic(72)
        fun xdViewportResultNotXml() = dynamic(73)
        fun xdUrifyFailed(filepath: String, basedir: String) = dynamic(74, filepath, basedir)
        fun xdUrifyDifferentDrives(filepath: String, basedir: String) = dynamic(75, filepath, basedir)
        fun xdUrifyMixedDrivesAndAuthorities(filepath: String, basedir: String) = dynamic(76, filepath, basedir)
        fun xdUrifyDifferentSchemes(filepath: String, basedir: String) = dynamic(77, filepath, basedir)
        fun xdInvalidContentType(value: String) = dynamic(79, value)
        fun xdUrifyNonhierarchicalBase(filepath: String, basedir: String) = dynamic(80, filepath, basedir)

        fun xdException(msg: String) = dynamic(999, msg)

        fun xcInvalidContentType(contentType: String) = step(1, contentType)
        fun xcHttpBadAuth(message: String) = step(3, message)
        fun xcXsltParameterNot20Compatible(name: QName, type: String) = step(7, name, type)
        fun xcXsltNoMode(mode: QName, message: String) = step(8, mode, message)
        fun xcXQueryVersionNotAvailable(version: String) = step(9, version)
        fun xcXmlSchemaVersionNotAvailable(version: String) = step(11, version)
        fun xcBadRenamePI() = step(13)
        fun xcNotADirectory(path: String) = step(17, path)
        fun xcComparisonFailed() = step(19)
        fun xcInvalidSelection(pattern: String) = step(Pair(23,1), pattern)
        fun xcInvalidSelection(pattern: String, nodeType: String) = step(Pair(23,2), pattern, nodeType)
        fun xcInvalidSelection(count: Int) = step(Pair(23,3), count)
        fun xcBadPosition(pattern: String, position: String) = step(24, pattern, position)
        fun xcBadTextPosition(pattern: String, position: String) = step(25, pattern, position)
        fun xcXIncludeError(message: String) = step(29, message)
        fun xcHttpCannotParseAs(contentType: MediaType) = step(30, contentType)
        fun xcOsExecMultipleInputs() = step(32)
        fun xcOsExecFailed() = step(33)
        fun xcOsExecBadCwd(cwd: String) = step(34, cwd)
        fun xcBadCrcVersion(version: String) = step(Pair(36,1), version)
        fun xcBadMdVersion(version: String) = step(Pair(36,2), version)
        fun xcBadShaVersion(version: String) = step(Pair(36,3), version)
        fun xcHashFailed(message: String) = step(Pair(36,4), message)
        fun xcBadHashAlgorithm(message: String) = step(Pair(36,5), message)
        fun xcMissingHmacKey() = step(Pair(36,6))
        fun xcHashBlake3ConflictingParameters() = step(Pair(36,7))
        fun xcHashBlake3IncompleteParameters() = step(Pair(36,8))
        fun xcHashBlake3Failed() = step(Pair(36,9))
        fun xcVersionNotAvailable(version: String) = step(38, version)
        fun xcCannotCopy(source: URI, target: URI) = step(50, source, target)
        fun xcNotSchemaValidSchematron() = step(Pair(54, 1))
        fun xcNotSchemaValidSchematron(uri: URI) = step(Pair(54, 2), uri)
        fun xcNotSchemaValidNVDL() = step(53)
        fun xcXsltNoTemplate(template: QName) = step(56, template)
        fun xcAllAndRelative() = step(58)
        fun xcCannotAddNamespaces(attName: QName) = step(Pair(59, 1), attName)
        fun xcCannotSetNamespaces() = step(Pair(59,2))
        fun xcUnsupportedUuidVersion(version: Int) = step(60, version)
        fun xcOsExecBadSeparator(sep: String) = step(63, sep)
        fun xcOsExecFailed(rc: Int) = step(64, rc)
        fun xcCannotSetContentType() = step(69)
        fun xcNotBase64(message: String) = step(72, message)
        fun xcContentTypeRequired() = step(73)
        fun xcDifferentContentTypes(contentType: MediaType, dataContentType: MediaType) = step(74, contentType, dataContentType)
        fun xcComparisonMethodNotSupported(method: QName) = step(76, method)
        fun xcComparisonNotPossible(sourceType: MediaType, altType: MediaType) = step(77, sourceType, altType)
        fun xcInvalidParameter(name: QName, value: String) = step(79, name, value)
        fun xcInvalidNumberOfArchives(number: Int) = step(80, number)
        fun xcFormatMissmatch(format: QName) = step(81, format)
        fun xcNoArchiveSourceUri() = step(Pair(84, 1))
        fun xcUnsupportedArchiveFormat(format: QName) = step(Pair(85,1), format)
        fun xcArchiveTooLarge(size: Long) = step(Pair(85,2), size)
        fun xcDuplicateArchiveSourceUri(uri: URI) = step(Pair(84, 2), uri)
        fun xcDuplicateArchiveSourceUri(name: String) = step(Pair(84, 3), name)
        fun xcInvalidArchiveFormat() = step(Pair(85,1))
        fun xcInvalidArchiveFormat(format: QName) = step(Pair(85,2), format)
        fun xcUnsupportedScheme(scheme: String) = step(90, scheme)
        fun xcAttributeNameCollision(name: String) = step(92, name)
        fun xcXsltCompileError(message: String, exception: Exception) = step(93, message, exception)
        fun xcXsltInputNot20Compatible() = step(Pair(94,1))
        fun xcXsltInputNot20Compatible(media: MediaType) = step(Pair(94,2), media)
        fun xcXsltRuntimeError(message: String) = step(95, message)
        fun xcXsltUserTermination(message: String) = step(96, message)
        fun xcBadSortKey(key: String) = step(98, key)
        fun xcSortKeySequence(key: String) = step(99, key)
        fun xcInvalidManifest() = step(Pair(100, 1))
        fun xcInvalidManifest(name: QName) = step(Pair(100, 2), name)
        fun xcInvalidManifestEntry(name: QName) = step(Pair(100, 3), name)
        fun xcInvalidManifestEntryName() = step(Pair(100, 4))
        fun xcInvalidManifestEntryHref() = step(Pair(100, 5))
        fun xcXQueryInputNot30Compatible(contentType: MediaType) = step(101, contentType)
        fun xcXQueryInvalidParameterType(name: QName, type: String) = step(102, name, type)
        fun xcXQueryCompileError(message: String, exception: Exception) = step(103, message, exception)
        fun xcXQueryEvalError(msg: String) = step(104, msg)
        fun xcDuplicateKeyInJsonMerge(key: XdmAtomicValue) = step(106, key)
        fun xcUnsupportedForJsonMerge() = step(107)
        fun xcNoNamespaceBindingForPrefix(prefix: String) = step(108, prefix)
        fun xcAttributeNameCollision(name: QName) = step(109, name)
        fun xcInvalidKeyForJsonMerge() = step(110)
        fun xcUnsupportedForJoin() = step(111)
        fun xcMultipleManifests() = step(112)
        fun xcDeleteFailed(path: String) = step(113, path)
        fun xcMkdirFailed(path: String) = step(114, path)
        fun xcTemporaryFileCreateFailed() = step(116)
        fun xcUnsupportedReportFormat(format: String) = step(117, format)
        fun xcInvalidFlatten(flatten: String) = step(119, flatten)
        fun xcNoUnarchiveBaseUri() = step(120)
        fun xcHttpInvalidAuth(name: String, value: String) = step(123, name, value)
        fun xcHttpInvalidParameter(name: String, value: String) = step(Pair(124, 1), name, value)
        fun xcHttpInvalidParameterType(name: String, value: String) = step(Pair(124, 2), name, value)
        fun xcHttpMultipartForbidden(href: URI) = step(125, href)
        fun xcHttpAssertionFailed(report: XdmNode) = step(126, report)
        fun xcHttpDuplicateHeader(name: String) = step(127, name)
        fun xcHttpUnsupportedScheme(scheme: String) = step(128, scheme)
        fun xcHttpUnsupportedHttpVersion(version: String) = step(129, version)
        fun xcUnsupportedTransferEncoding(encoding: String) = step(131, encoding)
        fun xcMultipartRequired(contentType: String) = step(133, contentType)
        fun xcUnsupportedFileInfoScheme(scheme: String) = step(134, scheme)
        fun xcUnsupportedFileTouchScheme(scheme: String) = step(136, scheme)
        fun xcUnsupportedFileCreateTempfileScheme(scheme: String) = step(138, scheme)
        fun xcUnsupportedFileMkdirScheme(scheme: String) = step(140, scheme)
        fun xcUnsupportedFileDeleteScheme(scheme: String) = step(142, scheme)
        fun xcUnsupportedFileCopyScheme(scheme: String) = step(144, scheme)
        fun xcBadOverrideContentTypes(length: Int) = step(146, length)
        fun xcInvalidRegex(pattern: String) = step(147, pattern)
        fun xcUnsupportedFileMoveScheme(scheme: String) = step(148, scheme)
        fun xcXmlSchemaInvalidSchema() = step(Pair(152, 1))
        fun xcXmlSchemaInvalidSchema(uri: URI) = step(Pair(152, 2), uri)
        fun xcNotRelaxNG(message: String) = step(Pair(153,1), message)
        fun xcNotRelaxNG(uri: URI, message: String) = step(Pair(153,2), uri, message)
        fun xcNotSchemaValidRelaxNG(message: String) = step(Pair(155,1), message)
        fun xcNotSchemaValidRelaxNG(uri: URI, message: String) = step(Pair(155,2), uri, message)
        fun xcNotSchemaValidXmlSchema(message: String) = step(Pair(156, 1), message)
        fun xcNotSchemaValidXmlSchema(uri: URI, message: String) = step(Pair(156, 2), uri, message)
        fun xcCopyDirectoryToFile(source: URI, target: URI) = step(157, source, target)
        fun xcMoveDirectoryToFile(source: URI, target: URI) = step(158, source, target)
        fun xcJsonSchemaInvalid() = step(Pair(164, 1))
        fun xcJsonSchemaInvalid(uri: URI) = step(Pair(164, 2), uri)
        fun xcNotSchemaValidJson() = step(Pair(165, 1))
        fun xcNotSchemaValidJson(uri: URI) = step(Pair(165,2), uri)
        fun xcNotAPipeline() = step(200)
        fun xcCannotUncompress(contentType: MediaType) = step(Pair(201,1), contentType)
        fun xcUnsupportedCompressionFormat(format: QName) = step(Pair(202, 1), format)
        fun xcCannotUncompress() = step(Pair(202,2))
        fun xcHttpInvalidBoundary(boundary: String) = step(203, boundary)
        fun xcUnsupportedContentType(contentType: MediaType) = step(204, contentType)
        fun xcRunInputPrimaryMismatch(primary: String) = step(Pair(206, 1), primary)
        fun xcRunInputPrimaryMismatch(primary: String, runPrimary: String) = step(Pair(206, 2), primary, runPrimary)
        fun xcRunInputPrimaryUndeclared(runPrimary: String) = step(Pair(206, 3), runPrimary)
        fun xcRunOutputPrimaryMismatch(primary: String) = step(Pair(207, 1), primary)
        fun xcRunOutputPrimaryMismatch(primary: String, runPrimary: String) = step(Pair(207, 2), primary, runPrimary)
        fun xcRunOutputPrimaryUndeclared(runPrimary: String) = step(Pair(207, 3), runPrimary)

        fun xiImpossibleNamespaceConfiguration(prefix: String, uri: String) = internal(1, prefix, uri)
        fun xiImpossibleNodeType(type: XdmNodeKind) = internal(2, type)
        fun xiUnrecognizedTypeName(name: QName) = internal(3, name)
        fun xiCannotCastTo(to: MediaType) = internal(4, to)
        fun xiStepOnlyAppliesToLibrary(step: String) = internal(5, step)
        fun xiStepRequiredForLibrary() = internal(6)
        fun xiStepNotInLibrary(name: String) = internal(7, name)
        fun xiStepNotUniqueInLibrary(step: String) = internal(8, step)
        fun xiRenameStep() = internal(9)
        fun xiChangeDeclaredType() = internal(10)
        fun xiNotWellFormedXml(node: XdmNode) = internal(11, node)
        fun xiStandardStepsNotLibrary() = internal(12)
        fun xiUriMustBeAbsolute(href: URI) = internal(13, href)
        fun xiStepExcludedByUseWhen() = internal(14)
        fun xiConfigurationUnreadable(file: String) = internal(16, file)
        fun xiConfigurationInvalid(file: String) = internal(Pair(17, 1), file)
        fun xiConfigurationInvalid(file: String, message: String) = internal(Pair(17, 2), file)
        fun xiConfigurationNotSchemaAware() = internal(18)
        fun xiConfigurationSchemaAware() = internal(19)
        fun xiUnreadableFile(filename: String) = internal(21, filename)
        fun xiUnrecognizedConfigurationProperty(name: QName) = internal(22, name)
        fun xiUnrecognizedConfigurationAttribute(elemName: QName, attrName: QName) = internal(25, elemName, attrName)
        fun xiMissingConfigurationAttribute(elemName: QName, attrName: QName) = internal(26, elemName, attrName)
        fun xiUnrecognizedConfigurationValue(elemName: QName, attrName: QName, value: String) = internal(27, elemName, attrName, value)
        fun xiUnrecognizedSaxonConfigurationProperty(key: String) = internal(28, key)
        fun xiInvalidSaxonConfigurationProperty(key: String, value: String) = internal(29, key, value)
        fun xiBaseUriRequiredToCache() = internal(30)
        fun xiUnwritableOutputFile(filename: String) = internal(32, filename)
        fun xiImportFunctionsXQueryNoNS() = internal(33)
        fun xiMultipleDocumentProperties() = internal(34)

        fun xiCliInvalidValue(option: String, value: String) = internal(200, option, value)
        fun xiCliNoPipeline() = internal(201)
        fun xiCliValueRequired(option: String) = internal(202, option)
        fun xiCliUnrecognizedOption(name: String) = internal(203, name)
        fun xiCliMoreThanOnePipeline(first: String, second: String) = internal(204, first, second)
        fun xiCliMalformedOption(type: String, opt: String) = internal(205, type, opt)
        fun xiCliDuplicateOutputFile(filename: String) = internal(206, filename)
        fun xiCliUnrecognizedPipelineOption(name: QName) = internal(207, name)
        fun xiCliConflictingConfig() = internal(208)
        fun xiHelp() = internal(209)

        fun xiImpossible(message: String) = internal(9998, message)
        fun xiNotImplemented(message: String) = internal(9999, message)
    }

    constructor(code: QName, location: Location = Location.NULL, inputLocation: Location = Location.NULL, vararg details: Any): this(code, 1, location, inputLocation, *details)

    var _throwable: Throwable? = null
    val throwable: Throwable?
        get() = _throwable

    fun asStatic(): XProcError {
        if (code == errXD0036) {
            val detail0 = details[0].toString()
            val detail1 = details[1].toString()
            return xsValueDoesNotSatisfyType(detail0, detail1)
        }
        if (code == errXD0079) {
            val detail0 = details[0].toString()
            return xsInvalidContentType(detail0)
        }
        return this
    }

    fun at(location: Location): XProcError {
        if (location != Location.NULL) {
            return XProcError(code, variant, location, inputLocation, *details)
        }
        return this
    }

    fun at(saxonLocation: net.sf.saxon.s9api.Location?): XProcError {
        if (saxonLocation != null && saxonLocation.systemId != null) {
            val xloc = Location(URI(saxonLocation.systemId), saxonLocation.lineNumber, saxonLocation.columnNumber)
            return XProcError(code, variant, location, xloc, *details)
        }
        return this
    }

    fun at(node: XdmNode): XProcError {
        // The document node doesn't have a useful location; get the location of the first element if we can
        val locNode = if (node.nodeKind == XdmNodeKind.DOCUMENT) {
            var seek: XdmNode = node
            for (child in node.axisIterator(Axis.CHILD)) {
                if (child.nodeKind == XdmNodeKind.ELEMENT) {
                    seek = child;
                    break;
                }
            }
            seek
        } else {
            node
        }

        return XProcError(code, variant, location, Location(locNode), *details)
    }

    fun at(doc: XProcDocument): XProcError {
        return XProcError(code, variant, location, Location(doc.baseURI), *details)
    }

    fun exception(): XProcException {
        return XProcException(this)
    }

    fun exception(cause: Throwable): XProcException {
        _throwable = cause
        println(cause.message)
        return XProcException(this, cause)
    }

    override fun toString(): String {
        val sb = StringBuilder()
        sb.append(code.toString())
        when (details.size) {
            0 -> Unit
            1 -> sb.append(": ").append(details[0])
            else -> {
                sb.append(": [")
                for (index in details.indices) {
                    if (index > 0) {
                        sb.append(", ")
                    }
                    sb.append(details[index])
                }
                sb.append("]")
            }
        }
        return sb.toString()
    }
}
