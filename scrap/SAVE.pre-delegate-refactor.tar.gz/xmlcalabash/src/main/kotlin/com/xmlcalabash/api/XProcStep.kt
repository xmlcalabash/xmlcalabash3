package com.xmlcalabash.api

import com.xmlcalabash.documents.XProcDocument
import net.sf.saxon.s9api.QName

interface XProcStep {
    /*
    fun setup(context: StepConfiguration, receiver: Receiver, nodeId: NodeId,
              inputs: List<PortFlange>, outputs: List<PortFlange>, options: List<OptionFlange>)
     */
    fun extensionAttributes(attributes: Map<QName, String>)

    fun option(name: QName, doc: XProcDocument, defaulted: Boolean = false)
    fun inScopeBinding(name: QName, doc: XProcDocument)
    fun input(port: String, doc: XProcDocument)
    fun run()
    fun close(port: String)

    fun reset()
    fun teardown()
}