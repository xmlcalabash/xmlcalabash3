package com.xmlcalabash.datamodel

import com.xmlcalabash.namespace.NsP

class OtherwiseInstruction(parent: ChooseInstruction, name: String?): CompoundContainer(parent, NsP.otherwise, name) {
    override val contentModel = anySteps + mapOf(NsP.withInput to '0', NsP.output to '*')
}