package com.xmlcalabash.datamodel

import com.xmlcalabash.xprocparser.StepConfiguration
import net.sf.saxon.s9api.SequenceType
import net.sf.saxon.s9api.XdmAtomicValue
import net.sf.saxon.s9api.XdmValue

class XProcConstantExpression private constructor(stepConfig: StepConfiguration, val value: XdmValue, asType: SequenceType, values: List<XdmAtomicValue>): XProcExpression(stepConfig, asType, values) {
    companion object {
        fun newInstance(stepConfig: StepConfiguration, value: XdmValue, asType: SequenceType = SequenceType.ANY, values: List<XdmAtomicValue> = emptyList()): XProcConstantExpression {
            if (asType !== SequenceType.ANY || values.isNotEmpty()) {
                stepConfig.checkType(null, value, asType, values)
            }
            return XProcConstantExpression(stepConfig, value, asType, values)
        }
    }

    override fun cast(asType: SequenceType, values: List<XdmAtomicValue>): XProcExpression {
        return constant(stepConfig, value, asType, values)
    }

    override fun evaluate(): XdmValue {
        return value
    }

    override fun computeStaticValue(context: InstructionStaticContext): XdmValue {
        checkedStatic = true
        return value
    }
}