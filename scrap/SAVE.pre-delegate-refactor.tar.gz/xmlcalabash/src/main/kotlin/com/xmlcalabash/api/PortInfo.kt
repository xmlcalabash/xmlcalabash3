package com.xmlcalabash.api

abstract class PortInfo {
}