package com.xmlcalabash.datamodel

import com.xmlcalabash.namespace.NsP
import com.xmlcalabash.xprocparser.StepConfiguration

class IfInstruction(parent: XProcInstruction, name: String?): CompoundContainer(parent, NsP.`if`, name) {
    companion object {
        private val INVALID_TEST = "*** no test specified ***"
    }

    override val contentModel = anySteps + mapOf(NsP.withInput to '1', NsP.output to '*')

    var test: String = INVALID_TEST
        set(value) {
            checkOpen()
            field = value
        }

    var collection: Boolean? = null
        set(value) {
            checkOpen()
            field = value
        }
}