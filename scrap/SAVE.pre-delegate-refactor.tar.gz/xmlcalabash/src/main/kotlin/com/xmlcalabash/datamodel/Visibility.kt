package com.xmlcalabash.datamodel

enum class Visibility {
    PUBLIC, PRIVATE
}