package com.xmlcalabash.datamodel

import com.xmlcalabash.namespace.NsP

class ForEachInstruction(parent: XProcInstruction, name: String?): CompoundContainer(parent, NsP.forEach, name) {
    override val contentModel = anySteps + mapOf(NsP.withInput to '1', NsP.output to '*')
}