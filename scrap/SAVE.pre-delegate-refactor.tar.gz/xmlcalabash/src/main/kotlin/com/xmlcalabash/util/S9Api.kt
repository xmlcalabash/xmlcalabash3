package com.xmlcalabash.util

import net.sf.saxon.s9api.Axis
import net.sf.saxon.s9api.XdmNode
import net.sf.saxon.s9api.XdmNodeKind
import net.sf.saxon.s9api.XdmValue
import net.sf.saxon.str.UnicodeBuilder
import net.sf.saxon.str.UnicodeString

class S9Api {
    companion object {
        fun documentElement(node: XdmNode): XdmNode {
            var root: XdmNode? = null
            for (child in node.axisIterator(Axis.CHILD)) {
                if (child.nodeKind == XdmNodeKind.ELEMENT) {
                    if (root != null) {
                        throw RuntimeException("Multiple root nodes")
                    }
                    root = child
                }
            }

            if (root == null) {
                throw RuntimeException("No root")
            }

            return root
        }

        fun firstElement(document: XdmNode): XdmNode? {
            when (document.nodeKind) {
                XdmNodeKind.ELEMENT -> return document
                XdmNodeKind.DOCUMENT -> {
                    for (node in document.axisIterator(Axis.CHILD)) {
                        if (node.nodeKind == XdmNodeKind.ELEMENT) {
                            return node
                        }
                    }
                    return null
                }
                else -> return null
            }
        }

        fun isTextDocument(doc: XdmNode): Boolean {
            if (doc.nodeKind == XdmNodeKind.DOCUMENT) {
                for (child in doc.axisIterator(Axis.CHILD)) {
                    if (child.nodeKind != XdmNodeKind.TEXT) {
                        return false
                    }
                }
                return true
            }
            return doc.nodeKind == XdmNodeKind.TEXT
        }

        fun valuesToString(values: XdmValue): String {
            val sb = StringBuilder()
            var sep = ""
            for (pos in 1..values.size()) {
                sb.append(sep)
                sb.append(values.itemAt(pos - 1).stringValue)
                sep = " "
            }
            return sb.toString()
        }

        fun makeUnicodeString(text: String): UnicodeString {
            val buf = UnicodeBuilder()
            buf.append(text)
            return buf.toUnicodeString()
        }
    }
}