package com.xmlcalabash.xprocparser

import net.sf.saxon.s9api.QName
import net.sf.saxon.s9api.XdmNode

class XProcLibraryNode(parser: PipelineParser, stepConfig: StepConfiguration, node: XdmNode): XProcStepContainer(parser, stepConfig, node) {
    override val stepType: QName? = null
}