package com.xmlcalabash.datamodel

import com.xmlcalabash.exceptions.XProcError
import com.xmlcalabash.namespace.Ns
import net.sf.saxon.s9api.QName

open class PortBindingContainer(parent: XProcInstruction, instructionType: QName): BindingContainer(parent, instructionType) {
    companion object {
        val UNSPECIFIED_PORT_NAME = "*** unspecified port name ***"
    }

    private var _portDefined = false
    val portDefined: Boolean
        get() = _portDefined

    var port: String = UNSPECIFIED_PORT_NAME
        set(value) {
            checkOpen()
            _portDefined = true
            field = value
        }

    var sequence: Boolean? = null
        set(value) {
            checkOpen()
            field = value
        }

    var primary: Boolean? = null
        set(value) {
            checkOpen()
            field = value
        }

    var select: XProcExpression? = null
        set(value) {
            checkOpen()
            if (value == null) {
                field = null
            } else {
                field = value.cast(parent!!.stepConfig.parseSequenceType("item()*"))
            }
        }

    private val _contentTypes = mutableListOf<MediaType>()
    var contentTypes: List<MediaType>
        get() = _contentTypes
        set(value) {
            checkOpen()
            _contentTypes.clear()
            _contentTypes.addAll(value)
        }

    var href: XProcExpression? = null
        set(value) {
            checkOpen()
            if (value == null) {
                field = null
            } else {
                field = value.cast(stepConfig.parseSequenceType("xs:anyURI"))
            }
        }

    var pipe: String? = null
        set(value) {
            checkOpen()
            field = value
        }

    override fun elaborate() {
        if (!portDefined) {
            reportError(XProcError.xsMissingRequiredAttribute(Ns.port))
        }

        if (href != null && children.isNotEmpty()) {
            reportError(XProcError.xsHrefAndChildren())
        }

        if (pipe != null && children.isNotEmpty()) {
            reportError(XProcError.xsPipeAndChildren())
        }

        if (href != null && pipe != null) {
            reportError(XProcError.xsHrefAndPipe())
        }

        href?.let { promoteHref(it) }
        href = null

        pipe?.let { promotePipe(it) }
        pipe = null

        super.elaborate()
    }

    override fun staticAnalysis(context: InstructionStaticContext) {
        primary = primary == true
        sequence = sequence == true
        super.staticAnalysis(context)
    }

    override fun toString(): String {
        if (port != UNSPECIFIED_PORT_NAME) {
            return "${instructionType}/${id} port=${port}"
        }
        return "${instructionType}/${id}"
    }
}