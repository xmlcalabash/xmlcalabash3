package com.xmlcalabash.graph

import com.xmlcalabash.datamodel.XProcStepInstruction

abstract class Node(val step: XProcStepInstruction) {
    internal val outputs = mutableMapOf<String, MutableList<Edge>>()
    internal val inputs = mutableMapOf<String, MutableList<Edge>>()

    internal abstract fun addEdges()

    internal fun addInput(edge: Edge) {
        inputs[edge.inputPort] = inputs[edge.inputPort] ?: mutableListOf()
        inputs[edge.inputPort]!!.add(edge)
    }

    internal fun addOutput(edge: Edge) {
        outputs[edge.outputPort] = outputs[edge.outputPort] ?: mutableListOf()
        outputs[edge.outputPort]!!.add(edge)
    }
}

