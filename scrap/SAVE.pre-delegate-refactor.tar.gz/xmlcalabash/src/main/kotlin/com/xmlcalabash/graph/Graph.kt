package com.xmlcalabash.graph

import com.xmlcalabash.datamodel.DeclareStepInstruction
import com.xmlcalabash.datamodel.XProcInstruction
import com.xmlcalabash.exceptions.XProcError
import java.util.*

class Graph private constructor() {
    companion object {
        fun build(decl: DeclareStepInstruction): Graph {
            val graph = Graph()
            graph.build(decl)
            return graph
        }
    }

    internal val nodes = mutableMapOf<XProcInstruction, Node>()
    internal val edges = mutableListOf<Edge>()

    private fun build(pipeline: DeclareStepInstruction) {
        println(pipeline)
        val node = CompoundNode.build(this, pipeline.pipeline!!)
        val loop = loops()
        if (loop != null) {
            pipeline.stepConfig.reportError(XProcError.xsLoop(loop))
            return
        }
        println(node)
    }

    private fun loops(): String? {
        for (node in nodes.values) {
            val loop = loop(node)
            if (loop != null) {
                return loop
            }
        }
        return null
    }

    private fun loop(node: Node, visited: Stack<Node> = Stack()): String? {
        if (visited.contains(node)) {
            val sb = StringBuilder()
            var first = true
            var found = false
            for (snode in visited) {
                found = found || node == snode
                if (found) {
                    if (!first) {
                        sb.append(" -> ")
                    }
                    sb.append(snode)
                    first = false
                }
            }
            sb.append(" -> ")
            sb.append(node)
            return sb.toString()
        }
        visited.push(node)
        for (edge in edges.filter { it.from == node }) {
            val loop = loop(edge.to, visited)
            if (loop != null) {
                return loop
            }
        }
        visited.pop()
        return null
    }

    internal fun addEdge(from: Node, outputPort: String, to: Node, inputPort: String) {
        val edge = Edge(from, outputPort, to, inputPort)
        edges.add(edge)
        from.addOutput(edge)
        to.addInput(edge)
    }

}