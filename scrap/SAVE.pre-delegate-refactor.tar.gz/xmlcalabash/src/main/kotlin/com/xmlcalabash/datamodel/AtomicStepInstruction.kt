package com.xmlcalabash.datamodel

import com.xmlcalabash.exceptions.XProcError
import net.sf.saxon.s9api.QName

open class AtomicStepInstruction(parent: XProcInstruction, instructionType: QName, name: String?): XProcStepInstruction(parent, instructionType, name) {
    override fun elaborate() {
        val decl = stepConfig.stepDeclaration(instructionType)
        if (decl == null) {
            reportError(XProcError.xsMissingStepDeclaration(instructionType))
            return
        }

        val inputs = mutableMapOf<String, WithInputInstruction>()
        for (input in children.filterIsInstance<WithInputInstruction>()) {
            if (input.port.startsWith("Q{")) {
                continue
            }

            val dinput = if (!input.portDefined) {
                decl.getPrimaryInput()
            } else {
                decl.getInput(input.port)
            }
            if (dinput == null) {
                if (!input.portDefined) {
                    reportError(XProcError.xsNoPrimaryInput())
                } else {
                    reportError(XProcError.xsNoSuchPort(input.port))
                }
                continue
            }

            if (!input.portDefined) {
                input.port = dinput.port
            }

            if (inputs.containsKey(input.port)) {
                reportError(XProcError.xsDuplicatePortName(input.port))
                continue
            }
            inputs[input.port] = input
        }

        for (input in decl.getInputs()) {
            if (!inputs.containsKey(input.port)) {
                val wi = withInput()
                wi.port = input.port
            }
        }

        for (output in decl.getOutputs()) {
            val wo = withOutput()
            wo.port = output.port
            wo.primary = output.primary
            wo.sequence = output.sequence
            wo.contentTypes = output.contentTypes
        }

        val options = mutableMapOf<QName, WithOptionInstruction>()
        for (opt in children.filterIsInstance<WithOptionInstruction>()) {
            if (decl.getOption(opt.name) == null) {
                reportError(XProcError.xsNoSuchOption(opt.name))
            }
            if (options.containsKey(opt.name)) {
                reportError(XProcError.xsDuplicateOption(opt.name))
            }
            options[opt.name] = opt
        }

        for (opt in decl.children.filterIsInstance<OptionInstruction>()) {
            if (!options.containsKey(opt.name)) {
                if (opt.required == true) {
                    reportError(XProcError.xsMissingRequiredOption(opt.name))
                } else {
                    val wo = withOption(opt.name)
                    wo.select = opt.select
                    wo.optionValues = opt.values
                    wo.asType = opt.asType
                }
            }
        }

        super.elaborate()
    }

    override fun staticAnalysis(context: InstructionStaticContext) {
        val decl = stepConfig.stepDeclaration(instructionType)
        if (decl == null) {
            reportError(XProcError.xsMissingStepDeclaration(instructionType))
            return
        }

        super.staticAnalysis(context)

        val inputs = mutableMapOf<String, WithInputInstruction>()
        for (input in children.filterIsInstance<WithInputInstruction>()) {
            if (input.port.startsWith("Q{")) {
                continue
            }

            val dinput = if (!input.portDefined) {
                decl.getPrimaryInput()
            } else {
                decl.getInput(input.port)
            }
            if (dinput == null) {
                if (!input.portDefined) {
                    reportError(XProcError.xsNoPrimaryInput())
                } else {
                    reportError(XProcError.xsNoSuchPort(input.port))
                }
                continue
            }

            if (!input.portDefined) {
                input.port = dinput.port
            }

            if (inputs.containsKey(input.port)) {
                reportError(XProcError.xsDuplicatePortName(input.port))
                continue
            }
            inputs[input.port] = input

            input.staticAnalysis(context.copy())
        }

        for (opt in children.filterIsInstance<WithOptionInstruction>()) {
            opt.staticAnalysis(context)
        }

        println("atomic")
    }

    // ============================================================

    internal fun withInput(): WithInputInstruction {
        val withInput = WithInputInstruction(this)
        _children.add(withInput)
        return withInput
    }

    internal fun withOutput(): WithOutputInstruction {
        val withOutput = WithOutputInstruction(this)
        _children.add(withOutput)
        return withOutput
    }

    internal fun withOption(name: QName): WithOptionInstruction {
        val withOption = WithOptionInstruction(this, name)
        _children.add(withOption)
        return withOption
    }
}