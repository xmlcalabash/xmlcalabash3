package com.xmlcalabash.xprocparser

import com.xmlcalabash.namespace.Ns
import net.sf.saxon.s9api.XdmNode
import java.net.URI

class XProcImportNode(parser: PipelineParser, stepConfig: StepConfiguration, node: XdmNode): XProcNode(parser, stepConfig, node) {
    internal var error: Boolean = false
    internal var container: XProcStepContainer? = null

    private var _href: URI? = null
    val href: URI?
        get() {
            if (_href == null) {
                val href = attributes[Ns.href] ?: return null
                _href = stepConfig.resolve(href)
            }
            return _href
        }

    override fun resolveDisplay(indent: String): String {
        return "${indent}${nodeName} ${href}"
    }
}