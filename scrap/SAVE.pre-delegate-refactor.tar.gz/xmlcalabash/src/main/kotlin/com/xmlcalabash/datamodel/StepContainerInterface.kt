package com.xmlcalabash.datamodel

import com.xmlcalabash.xprocparser.StepConfiguration
import net.sf.saxon.s9api.QName

interface StepContainerInterface {
    fun getImported(): List<StepContainerInterface>
    fun getExports(): Map<QName, DeclareStepInstruction>
    fun directlyExported(visited: MutableSet<StepContainerInterface>)
    fun visibleInside(visited: MutableSet<StepContainerInterface>)
    fun resolveImportsAndExports()
    fun traverse(stepConfig: StepConfiguration, visited: Set<StepContainerInterface>, import: StepContainerInterface)
    fun addImportLibrary(stepConfig: StepConfiguration, container: StepContainerInterface)
}