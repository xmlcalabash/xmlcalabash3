package com.xmlcalabash.datamodel

import com.xmlcalabash.exceptions.XProcError
import com.xmlcalabash.namespace.Ns
import com.xmlcalabash.namespace.NsP
import com.xmlcalabash.xprocparser.StepConfiguration
import net.sf.saxon.s9api.QName
import net.sf.saxon.s9api.XdmAtomicValue
import java.net.URI

open class WithOptionInstruction(parent: XProcInstruction, name: QName): VariableBindingContainer(parent, name, NsP.withOption) {
    internal var optionValues: List<XdmAtomicValue> = emptyList()
    internal var wasShortcut = false

    override fun elaborate() {
        if (select == null) {
            reportError(XProcError.xsMissingRequiredAttribute(Ns.select))
        } else {
            asType = asType ?: stepConfig.parseSequenceType("item()*")
            select = select!!.cast(asType!!, optionValues)
            if (select!!.contextRef && children.isEmpty()) {
                pipe()
            }
        }

        super.elaborate()
    }
}