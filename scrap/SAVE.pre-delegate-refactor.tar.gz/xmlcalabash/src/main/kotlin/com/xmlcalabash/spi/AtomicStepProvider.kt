package com.xmlcalabash.spi

import com.xmlcalabash.config.PipelineConfiguration

interface AtomicStepProvider {
    fun create(config: PipelineConfiguration): AtomicStepManager
}