package com.xmlcalabash.datamodel

import com.xmlcalabash.exceptions.XProcError
import com.xmlcalabash.namespace.NsP
import net.sf.saxon.s9api.QName
import net.sf.saxon.s9api.XdmAtomicValue
import net.sf.saxon.s9api.XdmNode

open class OptionInstruction(parent: XProcInstruction, name: QName): VariableBindingContainer(parent, name, NsP.option) {
    private val _values = mutableListOf<XdmAtomicValue>()
    var values: List<XdmAtomicValue>
        get() = _values
        set(value) {
            checkOpen()
            _values.clear()
            _values.addAll(value)
        }

    var static: Boolean = false
        set(value) {
            checkOpen()
            field = value
        }

    var required: Boolean? = null
        set(value) {
            checkOpen()
            field = value
        }

    var visibility: Visibility? = null
        set(value) {
            checkOpen()
            field = value
        }

    override fun elaborate() {
        required = required == true
        visibility = visibility ?: Visibility.PUBLIC

        if (select != null) {
            asType = asType ?: stepConfig.parseSequenceType("item()*")
            select = select!!.cast(asType!!)
        }

        super.elaborate()
    }

    override fun empty(): EmptyInstruction {
        throw XProcError.xsInvalidElement(NsP.empty).exception()
    }

    override fun document(href: XProcExpression): DocumentInstruction {
        throw XProcError.xsInvalidElement(NsP.document).exception()
    }

    override fun pipe(): PipeInstruction {
        throw XProcError.xsInvalidElement(NsP.pipe).exception()
    }

    override fun inline(documentNode: XdmNode): InlineInstruction {
        throw XProcError.xsInvalidElement(NsP.inline).exception()
    }
}