package com.xmlcalabash.graph

import com.xmlcalabash.datamodel.*
import com.xmlcalabash.exceptions.XProcError

class CompoundNode private constructor(val graph: Graph, step: CompoundContainer): Node(step) {
    private lateinit var _head: Head
    val head: Head
        get() = _head

    private lateinit var _foot: Foot
    val foot: Foot
        get() = _foot

    private val _children = mutableListOf<Node>()
    val children: List<Node>
        get() = _children

    init {
        graph.nodes[step] = this
    }

    companion object {
        fun build(graph: Graph, step: CompoundContainer): CompoundNode {
            val node = CompoundNode(graph, step)
            node._head = Head(node)
            node._foot = Foot(node)
            for (child in step.children.filterIsInstance<XProcStepInstruction>()) {
                when (child) {
                    is CompoundContainer -> {
                        node._children.add(build(graph, child))
                    }
                    is AtomicStepInstruction -> {
                        node._children.add(AtomicNode.build(graph, child))
                    }
                    else -> TODO("Unexpected child: ${child}")
                }
            }

            node.addEdges()

            return node
        }
    }

    override fun addEdges() {
        for (child in step.children) {
            when (child) {
                is XProcStepInstruction -> {
                    val node = graph.nodes[child]!!
                    node.addEdges()
                }
                is WithInputInstruction -> {
                    for (conn in child.children) {
                        when (conn) {
                            is PipeInstruction -> {
                                val from = graph.nodes[conn.readablePort!!.parent]!!
                                val to = graph.nodes[step]!!
                                graph.addEdge(from, conn.port!!, to, child.port)
                            }
                            else -> {
                                throw XProcError.xiImpossible("Connection is not a pipe: ${conn}").exception()
                            }
                        }
                    }
                }
                is OutputInstruction -> {
                    for (conn in child.children) {
                        when (conn) {
                            is PipeInstruction -> {
                                val from = graph.nodes[conn.readablePort!!.parent]!!
                                graph.addEdge(from, child.port, foot, child.port)
                            }
                            else -> {
                                throw XProcError.xiImpossible("Connection is not a pipe: ${conn}").exception()
                            }
                        }
                    }
                }
                else -> TODO("Unexpected child: ${child}")
            }
        }
    }

    override fun toString(): String {
        return step.toString()
    }
}