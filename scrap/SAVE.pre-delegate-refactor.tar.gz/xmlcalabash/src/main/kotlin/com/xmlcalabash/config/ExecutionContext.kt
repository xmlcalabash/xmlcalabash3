package com.xmlcalabash.config

import com.xmlcalabash.documents.XProcDocument
import com.xmlcalabash.runtime.XProcExecutionContext

interface ExecutionContext {
    fun getExecutionContext(): XProcExecutionContext?
    fun setExecutionContext(dynamicContext: XProcExecutionContext)
    fun releaseExecutionContext()
    fun addProperties(doc: XProcDocument?)
    fun removeProperties(doc: XProcDocument?)
}