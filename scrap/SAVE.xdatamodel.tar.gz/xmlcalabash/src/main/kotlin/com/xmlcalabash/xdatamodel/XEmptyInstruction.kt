package com.xmlcalabash.xdatamodel

import com.xmlcalabash.namespace.NsP

open class XEmptyInstruction(parent: XXProcInstruction): XConnectionDeclaration(parent, parent.stepConfig.newInstance(), NsP.empty) {

}