package com.xmlcalabash.xdatamodel

import com.xmlcalabash.xprocparser.StepConfiguration
import net.sf.saxon.s9api.QName

class XLibraryInstruction(initialParent: XXProcInstruction?, stepConfig: StepConfiguration, instructionType: QName): XXProcInstruction(initialParent, stepConfig, instructionType), XStepContainerInterface {
    private val _imported = mutableListOf<XStepContainerInterface>()
    private val _importedFunctions = mutableListOf<XImportedFunctions>()

    override var psviRequired: Boolean? = null
        set(value) {
            checkOpen()
            field = value
        }

    override var xpathVersion: Double? = null
        set(value) {
            checkOpen()
            field = value
        }

    override var version: Double? = null
        set(value) {
            checkOpen()
            field = value
        }

    override fun imported(): List<XStepContainerInterface> {
        return _imported
    }

    override fun importedFunctions(): List<XImportedFunctions> {
        return _importedFunctions
    }

}