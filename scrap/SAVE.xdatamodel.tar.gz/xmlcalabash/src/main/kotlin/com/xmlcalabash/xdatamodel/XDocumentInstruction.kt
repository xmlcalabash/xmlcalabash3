package com.xmlcalabash.xdatamodel

import com.xmlcalabash.datamodel.MediaType
import com.xmlcalabash.datamodel.XProcExpression
import com.xmlcalabash.namespace.NsP

open class XDocumentInstruction(parent: XXProcInstruction, val href: XProcExpression): XConnectionDeclaration(parent, parent.stepConfig.newInstance(), NsP.document) {
    var contentType: MediaType? = null
        set(value) {
            checkOpen()
            field = value
        }

    private var _documentProperties: XProcExpression? = null
    var documentProperties: XProcExpression
        get() = _documentProperties!!
        set(value) {
            checkOpen()
            _documentProperties = value.cast(parent!!.stepConfig.parseSequenceType("map(xs:QName,item()*)"))
        }

    private var _parameters: XProcExpression? = null
    var parameters: XProcExpression
        get() = _parameters!!
        set(value) {
            checkOpen()
            _parameters = value.cast(parent!!.stepConfig.parseSequenceType("map(xs:QName,item()*)"))
        }
}