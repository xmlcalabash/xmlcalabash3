package com.xmlcalabash.xdatamodel

import com.xmlcalabash.xprocparser.StepConfiguration
import net.sf.saxon.s9api.QName

open class XOutputPortDeclaration(parent: XXProcInstruction, stepConfig: StepConfiguration, instructionType: QName): XPortBindingDeclaration(parent, stepConfig, instructionType) {
}