package com.xmlcalabash.xdatamodel

import com.xmlcalabash.datamodel.XProcExpression
import com.xmlcalabash.xprocparser.StepConfiguration
import net.sf.saxon.s9api.QName
import net.sf.saxon.s9api.SequenceType

open class XVariableDeclaration(parent: XXProcInstruction, stepConfig: StepConfiguration, val name: QName, instructionType: QName): XBindingDeclaration(parent, stepConfig, instructionType) {
    var asType: SequenceType? = null
        set(value) {
            checkOpen()
            field = value
        }

    open var select: XProcExpression? = null
        set(value) {
            checkOpen()
            field = value
        }

    var collection: Boolean? = null
        set(value) {
            checkOpen()
            field = value
        }
}
