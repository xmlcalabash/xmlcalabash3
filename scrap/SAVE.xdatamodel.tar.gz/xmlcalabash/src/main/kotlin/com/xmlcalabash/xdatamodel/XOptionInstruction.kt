package com.xmlcalabash.xdatamodel

import com.xmlcalabash.datamodel.Visibility
import com.xmlcalabash.xprocparser.StepConfiguration
import net.sf.saxon.s9api.QName
import net.sf.saxon.s9api.XdmAtomicValue

open class XOptionInstruction(parent: XXProcInstruction, stepConfig: StepConfiguration, name: QName, instructionType: QName): XVariableDeclaration(parent, stepConfig, name, instructionType) {
    private val _values = mutableListOf<XdmAtomicValue>()
    var values: List<XdmAtomicValue>
        get() = _values
        set(value) {
            checkOpen()
            _values.clear()
            _values.addAll(value)
        }

    var static: Boolean = false
        set(value) {
            checkOpen()
            field = value
        }

    var required: Boolean? = null
        set(value) {
            checkOpen()
            field = value
        }

    var visibility: Visibility? = null
        set(value) {
            checkOpen()
            field = value
        }

}