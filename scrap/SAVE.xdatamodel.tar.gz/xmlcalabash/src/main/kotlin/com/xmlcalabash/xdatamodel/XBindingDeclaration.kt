package com.xmlcalabash.xdatamodel

import com.xmlcalabash.datamodel.*
import com.xmlcalabash.xprocparser.StepConfiguration
import net.sf.saxon.s9api.QName
import net.sf.saxon.s9api.XdmNode

open class XBindingDeclaration(parent: XXProcInstruction, stepConfig: StepConfiguration, instructionType: QName): XXProcInstruction(parent, stepConfig, instructionType) {
    var href: XProcExpression? = null
        set(value) {
            checkOpen()
            if (value == null) {
                field = null
            } else {
                field = value.cast(stepConfig.parseSequenceType("xs:anyURI"))
            }
        }

    var pipe: String? = null
        set(value) {
            checkOpen()
            field = value
        }

    open fun empty(): XEmptyInstruction {
        val empty = XEmptyInstruction(this)
        _children.add(empty)
        return empty
    }

    open fun document(href: XProcExpression): XDocumentInstruction {
        val doc = XDocumentInstruction(this, href)
        _children.add(doc)
        return doc
    }

    open fun pipe(): XPipeInstruction {
        val pipe = XPipeInstruction(this)
        _children.add(pipe)
        return pipe
    }

    open fun inline(documentNode: XdmNode): XInlineInstruction {
        val inline = XInlineInstruction(this, documentNode)
        _children.add(inline)
        return inline
    }

}