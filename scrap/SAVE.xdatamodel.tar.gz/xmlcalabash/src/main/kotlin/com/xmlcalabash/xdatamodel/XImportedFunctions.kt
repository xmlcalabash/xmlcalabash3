package com.xmlcalabash.xdatamodel

import com.xmlcalabash.xprocparser.StepConfiguration
import net.sf.saxon.om.NamespaceUri
import net.sf.saxon.s9api.QName

class XImportedFunctions(parent: XXProcInstruction, stepConfig: StepConfiguration, instructionType: QName): XXProcInstruction(parent, stepConfig, instructionType) {

}