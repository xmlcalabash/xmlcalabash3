package com.xmlcalabash.xdatamodel

import com.xmlcalabash.exceptions.XProcError
import com.xmlcalabash.xprocparser.StepConfiguration
import net.sf.saxon.s9api.QName

open class XXProcInstruction internal constructor(initialParent: XXProcInstruction?, val stepConfig: StepConfiguration, val instructionType: QName) {
    internal var _parent = initialParent
    val parent: XXProcInstruction?
        get() = _parent

    val id = stepConfig.pipelineConfig.nextId
    var expandText: Boolean? = null

    internal val _children = mutableListOf<XXProcInstruction>()
    val children: List<XXProcInstruction>
        get() = _children

    protected val _extensionAttributes = mutableMapOf<QName, String>()
    var extensionAttributes: Map<QName, String>
        get() = _extensionAttributes
        set(value) {
            checkOpen()
            _extensionAttributes.clear()
            _extensionAttributes.putAll(value)
        }
    fun setExtensionAttribute(name: QName, value: String) {
        _extensionAttributes[name] = value
    }

    internal var open = true
    protected fun checkOpen() {
        if (!open) {
            throw IllegalArgumentException("${instructionType} cannot be changed")
        }
    }

    val errors: List<XProcError>
        get() = stepConfig.errors
    val hasErrors: Boolean
        get() {
            return stepConfig.hasErrors
        }
    fun reportError(error: XProcError) {
        stepConfig.reportError(error)
    }
}