package com.xmlcalabash.xdatamodel

import com.xmlcalabash.xprocparser.StepConfiguration
import net.sf.saxon.s9api.QName

open class XVariableInstruction(parent: XXProcInstruction, stepConfig: StepConfiguration, name: QName, instructionType: QName): XVariableDeclaration(parent, stepConfig, name, instructionType) {
}