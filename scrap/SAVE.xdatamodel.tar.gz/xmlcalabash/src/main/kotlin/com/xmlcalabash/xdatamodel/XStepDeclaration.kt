package com.xmlcalabash.xdatamodel

import com.xmlcalabash.xprocparser.StepConfiguration
import net.sf.saxon.s9api.QName

open class XStepDeclaration(parent: XXProcInstruction?, stepConfig: StepConfiguration, instructionType: QName, declaredName: String? = null): XXProcInstruction(parent, stepConfig, instructionType) {
    val name = declaredName ?: "!${instructionType.localName}_${id}"

    fun inputs(): List<XInputPortDeclaration> {
        return children.filterIsInstance<XInputPortDeclaration>()
    }

    fun primaryInput(): XInputPortDeclaration? {
        for (child in inputs()) {
            if (child.primary == true) {
                return child
            }
        }
        return null
    }

    fun namedInput(port: String): XInputPortDeclaration? {
        for (child in inputs()) {
            if (child.port == port) {
                return child
            }
        }
        return null
    }

    fun outputs(): List<XOutputPortDeclaration> {
        return children.filterIsInstance<XOutputPortDeclaration>()
    }

    fun primaryOutput(): XOutputPortDeclaration? {
        for (child in outputs()) {
            if (child.primary == true) {
                return child
            }
        }
        return null
    }

    fun namedOutput(port: String): XOutputPortDeclaration? {
        for (child in outputs()) {
            if (child.port == port) {
                return child
            }
        }
        return null
    }

    fun options(): List<XVariableDeclaration> {
        val opts = mutableListOf<XVariableDeclaration>()
        for (child in children.filter { it is XOptionInstruction || it is XWithOptionInstruction }) {
            opts.add(child as XVariableDeclaration)
        }
        return opts
    }

    fun namedOption(name: QName): XVariableDeclaration? {
        for (child in options()) {
            if (child.name == name) {
                return child as XVariableDeclaration
            }
        }
        return null
    }
}