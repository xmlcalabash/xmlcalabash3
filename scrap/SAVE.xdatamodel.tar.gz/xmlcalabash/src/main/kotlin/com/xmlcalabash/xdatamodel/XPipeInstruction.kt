package com.xmlcalabash.xdatamodel

import com.xmlcalabash.datamodel.XProcInstruction
import com.xmlcalabash.namespace.NsP

open class XPipeInstruction(parent: XXProcInstruction): XConnectionDeclaration(parent, parent.stepConfig.newInstance(), NsP.pipe) {
    private var _readablePort: XPortBindingDeclaration? = null
    val readablePort: XPortBindingDeclaration?
        get() = _readablePort

    constructor(parent: XXProcInstruction, step: String?, port: String?): this(parent) {
        this.step = step
        this.port = port
    }

    var step: String? = null
        set(value) {
            checkOpen()
            field = value
        }

    var port: String? = null
        set(value) {
            checkOpen()
            field = value
        }

}