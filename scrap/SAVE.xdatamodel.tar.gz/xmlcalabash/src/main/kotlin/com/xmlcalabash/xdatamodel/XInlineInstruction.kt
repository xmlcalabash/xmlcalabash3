package com.xmlcalabash.xdatamodel

import com.xmlcalabash.datamodel.MediaType
import com.xmlcalabash.datamodel.XProcExpression
import com.xmlcalabash.datamodel.XProcInstruction
import com.xmlcalabash.namespace.NsP
import com.xmlcalabash.util.ValueTemplateFilter
import com.xmlcalabash.xprocparser.StepConfiguration
import net.sf.saxon.s9api.QName
import net.sf.saxon.s9api.XdmNode

open class XInlineInstruction(parent: XXProcInstruction, xmlDocument: XdmNode): XConnectionDeclaration(parent, parent.stepConfig.newInstance(), NsP.inline) {
    var xml: XdmNode = xmlDocument
        set(value) {
            checkOpen()
            field = value
        }

    var contentType: MediaType? = null
        set(value) {
            checkOpen()
            field = value
        }

    private var _documentProperties: XProcExpression? = null
    var documentProperties: XProcExpression
        get() = _documentProperties!!
        set(value) {
            checkOpen()
            _documentProperties = value.cast(parent!!.stepConfig.parseSequenceType("map(xs:QName,item()*)"))
        }

    var encoding: String? = null
        set(value) {
            checkOpen()
            field = value
        }

    private lateinit var _valueTemplateFilter: ValueTemplateFilter
    val valueTemplateFilter: ValueTemplateFilter
        get() = _valueTemplateFilter

    init {
        var p: XXProcInstruction? = parent
        while (expandText == null && p != null) {
            if (p.expandText != null) {
                expandText = p.expandText
            }
            p = p.parent
        }
        expandText = expandText ?: true
    }

}