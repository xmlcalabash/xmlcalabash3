package com.xmlcalabash.xdatamodel

import com.xmlcalabash.xprocparser.StepConfiguration
import net.sf.saxon.s9api.QName

open class XConnectionDeclaration(parent: XXProcInstruction, stepConfig: StepConfiguration, instructionType: QName): XXProcInstruction(parent, stepConfig, instructionType) {

}