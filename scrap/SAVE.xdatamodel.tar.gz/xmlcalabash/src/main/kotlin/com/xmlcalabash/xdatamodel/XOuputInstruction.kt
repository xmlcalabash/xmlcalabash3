package com.xmlcalabash.xdatamodel

import com.xmlcalabash.datamodel.XProcExpression
import com.xmlcalabash.xprocparser.StepConfiguration
import net.sf.saxon.s9api.QName

open class XOuputInstruction(parent: XXProcInstruction, stepConfig: StepConfiguration, instructionType: QName): XOutputPortDeclaration(parent, stepConfig, instructionType) {
    private var _serialization: XProcExpression? = null
    var serialization: XProcExpression
        get() = _serialization!!
        set(value) {
            checkOpen()
            _serialization = value.cast(parent!!.stepConfig.parseSequenceType("map(xs:QName,item()*)"))
        }
}