package com.xmlcalabash.xdatamodel

import com.xmlcalabash.datamodel.MediaType
import com.xmlcalabash.datamodel.XProcExpression
import com.xmlcalabash.xprocparser.StepConfiguration
import net.sf.saxon.s9api.QName

open class XPortBindingDeclaration(parent: XXProcInstruction, stepConfig: StepConfiguration, instructionType: QName): XBindingDeclaration(parent, stepConfig, instructionType) {
    companion object {
        val UNSPECIFIED_PORT_NAME = "*** unspecified port name ***"
    }

    private var _portDefined = false
    val portDefined: Boolean
        get() = _portDefined

    var port: String = UNSPECIFIED_PORT_NAME
        set(value) {
            checkOpen()
            _portDefined = true
            field = value
        }

    var sequence: Boolean? = null
        set(value) {
            checkOpen()
            field = value
        }

    var primary: Boolean? = null
        set(value) {
            checkOpen()
            field = value
        }

    var select: XProcExpression? = null
        set(value) {
            checkOpen()
            if (value == null) {
                field = null
            } else {
                field = value.cast(parent!!.stepConfig.parseSequenceType("item()*"))
            }
        }

    private val _contentTypes = mutableListOf<MediaType>()
    var contentTypes: List<MediaType>
        get() = _contentTypes
        set(value) {
            checkOpen()
            _contentTypes.clear()
            _contentTypes.addAll(value)
        }

}