package com.xmlcalabash.xdatamodel

interface XStepContainerInterface {
    var psviRequired: Boolean?
    var xpathVersion: Double?
    var version: Double?
    fun imported(): List<XStepContainerInterface>
    fun importedFunctions(): List<XImportedFunctions>
}