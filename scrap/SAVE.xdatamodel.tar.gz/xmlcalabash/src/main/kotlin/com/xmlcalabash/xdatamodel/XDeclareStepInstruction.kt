package com.xmlcalabash.xdatamodel

import com.xmlcalabash.xprocparser.StepConfiguration
import net.sf.saxon.s9api.QName

class XDeclareStepInstruction(initialParent: XXProcInstruction?, stepConfig: StepConfiguration, instructionType: QName, declaredName: String): XCompoundStepDeclaration(initialParent, stepConfig, instructionType, declaredName), XStepContainerInterface {
    private val _imported = mutableListOf<XStepContainerInterface>()
    private val _importedFunctions = mutableListOf<XImportedFunctions>()

    override var psviRequired: Boolean? = null
        set(value) {
            checkOpen()
            field = value
        }

    override var xpathVersion: Double? = null
        set(value) {
            checkOpen()
            field = value
        }

    override var version: Double? = null
        set(value) {
            checkOpen()
            field = value
        }

    override fun imported(): List<XStepContainerInterface> {
        return _imported
    }

    override fun importedFunctions(): List<XImportedFunctions> {
        return _importedFunctions
    }

}